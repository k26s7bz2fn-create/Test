using System.Collections;
using NUnit.Framework;
using UnityEngine.TestTools;

namespace GuildGame.Tests
{
    public sealed class GuildHallFlowTests
    {
        [UnityTest]
        public IEnumerator Placeholder_PlayModeGateRequiresUnitySceneValidation()
        {
            // This fixture intentionally keeps a PlayMode gate in the project. Full scene wiring is generated/validated in Unity.
            yield return null;
            Assert.Pass();
        }
    }
}

using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class SafeAreaLayoutTests
    {
        [Test] public void AsymmetricLandscapeInsetsNormalize() { Assert.IsTrue(GuildHallSafeAreaPolicy.TryNormalize(1000,500,50,0,900,500,out var a)); Assert.AreEqual(.05f,a.MinX,.0001f); Assert.AreEqual(.95f,a.MaxX,.0001f); }
        [Test] public void InvalidDimensionsRejected() { Assert.IsFalse(GuildHallSafeAreaPolicy.TryNormalize(0,500,0,0,0,0,out _)); }
        [Test] public void ValuesClampToViewport() { Assert.IsTrue(GuildHallSafeAreaPolicy.TryNormalize(100,100,-10,-10,120,120,out var a)); Assert.AreEqual(0,a.MinX); Assert.AreEqual(1,a.MaxX); }
    }
}

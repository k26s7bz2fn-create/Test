using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class CameraPolicyTests
    {
        [Test] public void ClampYaw_StaysInsideBounds() { var p=new GuildHallCameraPolicy(-35,35,-15,18); Assert.AreEqual(35,p.ClampYaw(99)); Assert.AreEqual(-35,p.ClampYaw(-99)); }
        [Test] public void ClampPitch_StaysInsideBounds() { var p=new GuildHallCameraPolicy(-35,35,-15,18); Assert.AreEqual(18,p.ClampPitch(99)); Assert.AreEqual(-15,p.ClampPitch(-99)); }
        [Test] public void InvalidYawBounds_Throw() { Assert.Throws<System.ArgumentOutOfRangeException>(()=>new GuildHallCameraPolicy(2,1,-1,1)); }
    }
}

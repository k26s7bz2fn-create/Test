using NUnit.Framework;
using UnityEngine;

namespace GuildGame.Tests
{
    public sealed class NavigationTests
    {
        [Test] public void DestinationEnum_HasExactlySixValues() { Assert.AreEqual(6,System.Enum.GetValues(typeof(GuildHallDestination)).Length); }
        [Test] public void InteractionPoint_ConfigurationRequiresAnchorAndCollider()
        {
            var go=new GameObject("point"); var anchor=new GameObject("anchor").transform; var collider=go.AddComponent<BoxCollider>(); var point=go.AddComponent<GuildHallInteractionPoint>();
            point.Configure(GuildHallDestination.Recruitment,anchor,collider); Assert.IsTrue(point.IsConfigured);
            Object.DestroyImmediate(anchor.gameObject); Object.DestroyImmediate(go);
        }
    }
}

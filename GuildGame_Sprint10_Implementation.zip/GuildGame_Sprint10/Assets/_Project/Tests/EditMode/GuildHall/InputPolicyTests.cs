using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class InputPolicyTests
    {
        [Test] public void UiOwnsGesture() { var p=new GuildHallInputPolicy(.01f); Assert.AreEqual(GuildHallGestureKind.Ui,p.Classify(true,false,1f)); }
        [Test] public void DragDoesNotBecomeTap() { var p=new GuildHallInputPolicy(.01f); Assert.AreEqual(GuildHallGestureKind.WorldDrag,p.Classify(false,false,.02f)); }
        [Test] public void SmallWorldGestureIsTap() { var p=new GuildHallInputPolicy(.01f); Assert.AreEqual(GuildHallGestureKind.WorldTap,p.Classify(false,false,.001f)); }
        [Test] public void CancelProducesNoAction() { var p=new GuildHallInputPolicy(.01f); Assert.AreEqual(GuildHallGestureKind.None,p.Classify(false,true,0f)); }
    }
}

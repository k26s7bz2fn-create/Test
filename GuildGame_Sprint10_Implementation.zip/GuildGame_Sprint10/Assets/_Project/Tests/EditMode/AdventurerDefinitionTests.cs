using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace GuildGame.Tests
{
    public sealed class AdventurerDefinitionTests
    {
        [Test]
        public void Catalog_HasExactlyCanonicalClassesAndCopiedPools()
        {
            var gen = TestDefinitions.CreateGeneration();
            Assert.That(gen.TryBuildCatalog(out var catalog, out var error), Is.True, error);
            Assert.That(catalog.Classes.Count, Is.EqualTo(4));
            Assert.That(catalog.Classes[0].Id, Is.EqualTo("class.warrior"));
            Assert.That(catalog.Classes[3].Id, Is.EqualTo("class.priest"));
            Assert.That(catalog.Names.Count, Is.EqualTo(8));
            Assert.That(catalog.Appearances.Count, Is.EqualTo(3));
        }

        [Test]
        public void DuplicateNamePool_IsRejected()
        {
            var gen = TestDefinitions.CreateGeneration(names: new[] { "Arel", "Arel" });
            Assert.That(gen.TryBuildCatalog(out _, out _), Is.False);
        }

        [Test]
        public void MissingCanonicalClass_IsRejected()
        {
            var gen = TestDefinitions.CreateGeneration(replaceLastWithWarrior: true);
            Assert.That(gen.TryBuildCatalog(out _, out _), Is.False);
        }
    }

    internal static class TestDefinitions
    {
        internal static AdventurerGenerationDefinition CreateGeneration(string[] names = null, bool replaceLastWithWarrior = false)
        {
            var warrior = CreateClass("class.warrior", "Krieger", AdventurerRole.Tank | AdventurerRole.Damage);
            var rogue = CreateClass("class.rogue", "Schurke", AdventurerRole.Damage);
            var mage = CreateClass("class.mage", "Magier", AdventurerRole.Damage | AdventurerRole.SupportControl);
            var priest = replaceLastWithWarrior ? warrior : CreateClass("class.priest", "Priester", AdventurerRole.Healing | AdventurerRole.SupportControl);
            var gen = ScriptableObject.CreateInstance<AdventurerGenerationDefinition>();
            var so = new SerializedObject(gen);
            so.FindProperty("id").stringValue = AdventurerGenerationDefinition.RequiredId;
            so.FindProperty("displayName").stringValue = "Abenteurer-Platzhalter V0.1";
            SetObjects(so.FindProperty("classes"), warrior, rogue, mage, priest);
            SetStrings(so.FindProperty("names"), names ?? new[] { "Arel", "Bera", "Corin", "Daria", "Elian", "Fara", "Joren", "Mira" });
            SetStrings(so.FindProperty("appearanceIds"), new[] { "human.adult.placeholder.01", "human.adult.placeholder.02", "human.adult.placeholder.03" });
            so.ApplyModifiedPropertiesWithoutUndo();
            return gen;
        }

        private static AdventurerClassDefinition CreateClass(string id, string name, AdventurerRole roles)
        {
            var d = ScriptableObject.CreateInstance<AdventurerClassDefinition>();
            var so = new SerializedObject(d);
            so.FindProperty("id").stringValue = id;
            so.FindProperty("displayName").stringValue = name;
            so.FindProperty("roles").intValue = (int)roles;
            so.ApplyModifiedPropertiesWithoutUndo();
            return d;
        }

        private static void SetStrings(SerializedProperty p, string[] v) { p.arraySize = v.Length; for (var i = 0; i < v.Length; i++) p.GetArrayElementAtIndex(i).stringValue = v[i]; }
        private static void SetObjects(SerializedProperty p, params Object[] v) { p.arraySize = v.Length; for (var i = 0; i < v.Length; i++) p.GetArrayElementAtIndex(i).objectReferenceValue = v[i]; }
    }
}

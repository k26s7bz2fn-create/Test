using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class AdventurerGeneratorTests
    {
        [TestCase("class.warrior")]
        [TestCase("class.rogue")]
        [TestCase("class.mage")]
        [TestCase("class.priest")]
        public void RequestedClass_IsPreserved(string classId)
        {
            var catalog = Catalog();
            var generator = new AdventurerGenerator(catalog, new FixedRandom(0, 0), () => Guid.NewGuid().ToString("D"));
            var result = generator.Generate(classId);
            Assert.That(result.Success, Is.True);
            Assert.That(result.State.ClassId, Is.EqualTo(classId));
        }

        [Test]
        public void FirstAndLastPoolIndices_AreReachable()
        {
            var catalog = Catalog();
            var first = new AdventurerGenerator(catalog, new FixedRandom(0, 0, 0), () => "00000000-0000-0000-0000-000000000001").Generate();
            var last = new AdventurerGenerator(catalog, new FixedRandom(3, 7, 2), () => "00000000-0000-0000-0000-000000000002").Generate();
            Assert.That(first.State.ClassId, Is.EqualTo("class.warrior"));
            Assert.That(first.State.DisplayName, Is.EqualTo("Arel"));
            Assert.That(last.State.ClassId, Is.EqualTo("class.priest"));
            Assert.That(last.State.DisplayName, Is.EqualTo("Mira"));
            Assert.That(last.State.AppearanceId, Is.EqualTo("human.adult.placeholder.03"));
        }

        [Test]
        public void SameSeedAndIdFactory_GivesSameSelection()
        {
            var catalog = Catalog();
            var a = new AdventurerGenerator(catalog, new RandomGenerator(42), () => "00000000-0000-0000-0000-000000000001").Generate();
            var b = new AdventurerGenerator(catalog, new RandomGenerator(42), () => "00000000-0000-0000-0000-000000000001").Generate();
            Assert.That(a.State.ClassId, Is.EqualTo(b.State.ClassId));
            Assert.That(a.State.DisplayName, Is.EqualTo(b.State.DisplayName));
            Assert.That(a.State.AppearanceId, Is.EqualTo(b.State.AppearanceId));
        }

        [Test]
        public void EmptyRequestedClass_IsRejectedWithoutFallback()
        {
            var result = new AdventurerGenerator(Catalog(), new FixedRandom(0), () => Guid.NewGuid().ToString("D")).Generate(" ");
            Assert.That(result.Status, Is.EqualTo(AdventurerStatus.UnknownClass));
        }

        [Test]
        public void InvalidIdFactory_IsControlledGenerationFailure()
        {
            var result = new AdventurerGenerator(Catalog(), new FixedRandom(0, 0), () => "not-a-guid").Generate("class.warrior");
            Assert.That(result.Status, Is.EqualTo(AdventurerStatus.GenerationFailed));
        }

        private static AdventurerCatalog Catalog()
        {
            var gen = TestDefinitions.CreateGeneration();
            Assert.That(gen.TryBuildCatalog(out var catalog, out var error), Is.True, error);
            return catalog;
        }

        private sealed class FixedRandom : IRandomSource
        {
            private readonly Queue<int> values;
            public FixedRandom(params int[] values) { this.values = new Queue<int>(values); }
            public int NextIndex(int exclusiveMax) => values.Dequeue();
        }
    }
}

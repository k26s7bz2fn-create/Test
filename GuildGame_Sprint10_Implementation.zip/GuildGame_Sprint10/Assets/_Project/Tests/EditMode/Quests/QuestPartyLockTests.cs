using System;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class QuestPartyLockTests
    {
        [Test] public void WrongPolicyOrRosterIsRejectedAtCompositionRoot()
        {
            var c=new QuestTestContext();var registry=new QuestActivityRegistry();
            Assert.Throws<ArgumentException>(()=>new QuestManager(c.Adventurers,c.Parties,c.Catalog,registry,c.Clock));
            var wrongRoster=new AdventurerManager(c.AdventurerCatalog);
            var parties=new PartyManager(c.Adventurers,c.AdventurerCatalog,registry);
            Assert.Throws<ArgumentException>(()=>new QuestManager(wrongRoster,parties,c.Catalog,registry,c.Clock));
        }
        [Test] public void RegistryRejectsSecondAuthoritativeManager()
        {
            var c=new QuestTestContext();
            Assert.Throws<InvalidOperationException>(()=>new QuestManager(c.Adventurers,c.Parties,c.Catalog,c.Registry,c.Clock));
        }
        [Test] public void OverlappingParticipantGuardIsIndependentOfNormalPartyUniqueness()
        {
            var c=new QuestTestContext();
            Assert.IsTrue(c.Manager.TryStartQuest(QuestTestContext.Id(1,2),QuestTestContext.Id(1,1)).Success);
            // Deliberately malformed adapter input to exercise defense-in-depth; not published to PartyManager.
            var other=new PartyState(QuestTestContext.Id(9,1),new[]{QuestTestContext.Id(1)});
            Assert.AreEqual(QuestResultCode.MemberAlreadyCommitted,c.Registry.ValidateReservation(other));
            c.Clock.Now=11000;c.Manager.RefreshTime();
            Assert.AreEqual(QuestResultCode.MemberAlreadyCommitted,c.Registry.ValidateReservation(other));
        }
        [TestCase(0)] [TestCase(7)]
        public void MalformedGroupSizeCannotStart(int size)
        {
            var c=new QuestTestContext();var id=QuestTestContext.Id(1,1);var members=new List<string>();
            for(var i=1;i<=size;i++) members.Add(QuestTestContext.Id(i));
            // Fault injection only: public PartyManager API cannot produce this state.
            var field=typeof(PartyManager).GetField("parties",BindingFlags.NonPublic|BindingFlags.Instance);
            var map=(Dictionary<string,PartyState>)field.GetValue(c.Parties);
            map[id]=new PartyState(id,members);
            Assert.AreEqual(QuestResultCode.InvalidPartyComposition,c.Manager.TryStartQuest(QuestTestContext.Id(1,2),id).StatusCode);
            Assert.AreEqual(0,c.Registry.OccupiedSlotCount);
        }
        [Test] public void UnresolvedGroupMemberCannotStart()
        {
            var c=new QuestTestContext();var id=QuestTestContext.Id(1,1);
            var field=typeof(PartyManager).GetField("parties",BindingFlags.NonPublic|BindingFlags.Instance);
            var map=(Dictionary<string,PartyState>)field.GetValue(c.Parties);
            map[id]=new PartyState(id,new[]{QuestTestContext.Id(99)});
            Assert.AreEqual(QuestResultCode.InvalidPartyComposition,c.Manager.TryStartQuest(QuestTestContext.Id(1,2),id).StatusCode);
            Assert.AreEqual(0,c.Registry.OccupiedSlotCount);
        }
    }
}

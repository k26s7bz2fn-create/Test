using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GuildGame.Tests
{
    [Serializable] public sealed class QuestCaseGroup { public int[] members; }
    [Serializable] public sealed class QuestCaseAction
    {
        public string op; public string expected; public int quest; public int party;
        public int member; public int target; public long now;
    }
    [Serializable] public sealed class QuestCase
    {
        public string name; public QuestCaseGroup[] groups; public long duration;
        public QuestCaseAction[] actions; public string[] expectedStatuses; public int expectedOccupied;
    }
    [Serializable] public sealed class QuestCaseFile { public QuestCase[] cases; }

    internal sealed class QuestTestClock : IQuestClock
    {
        public long Now = 1000;
        public bool Broken;
        public int Reads;
        public long UtcNowMilliseconds { get { Reads++; if (Broken) throw new InvalidOperationException("clock test"); return Now; } }
    }

    internal sealed class QuestTestContext
    {
        public readonly AdventurerManager Adventurers;
        public readonly AdventurerCatalog AdventurerCatalog;
        public readonly QuestCatalog Catalog;
        public readonly PartyManager Parties;
        public readonly QuestActivityRegistry Registry = new QuestActivityRegistry();
        public readonly QuestTestClock Clock = new QuestTestClock();
        public readonly QuestManager Manager;
        public static string Id(int n, int kind = 0) => n < 0 ? "invalid" : kind.ToString()+"0000000-0000-0000-0000-"+n.ToString("D12");
        public static string[] Members(int[] ns)
        { var ids = new string[ns.Length]; for (var i=0;i<ns.Length;i++) ids[i]=Id(ns[i]); return ids; }
        public QuestTestContext(QuestCaseGroup[] groups = null, long duration = 10)
        {
            AdventurerCatalog = new AdventurerCatalog(new[] {
                new AdventurerCatalog.ClassData("class.mage", "Magier", AdventurerRole.Damage | AdventurerRole.SupportControl)
            }, new[] { "Test Member" }, new[] { "human.adult.placeholder.01" });
            Adventurers = new AdventurerManager(AdventurerCatalog);
            for (var i=1;i<=12;i++)
            {
                Assert.IsTrue(AdventurerState.TryCreate(Id(i), "class.mage", "Test Member", "human.adult.placeholder.01", out var member));
                Assert.IsTrue(Adventurers.TryAdd(member).Success);
            }
            Parties = new PartyManager(Adventurers, AdventurerCatalog, Registry);
            if (groups == null) groups = new[] { new QuestCaseGroup { members = new[] {1,2} }, new QuestCaseGroup { members = new[] {3,4} } };
            for (var i=0;i<groups.Length;i++)
            {
                Assert.IsTrue(Parties.TryCreateParty(Id(i+1,1),Members(groups[i].members)).Success);
                Assert.IsTrue(Parties.TrySetLeader(Id(i+1,1),Id(groups[i].members[0])).Success);
            }
            var definitions = new List<QuestDefinitionData>();
            for (var i=0;i<4;i++)
            {
                Assert.IsTrue(QuestDefinitionData.TryCreate("quest.test."+i,"TEST ONLY",(QuestType)i,"F",(QuestDistance)(i%3),
                    duration,6,"TEST ONLY",7,11,new[] {new QuestLootContract("test.item",0,2)},out var d,out var error),error);
                definitions.Add(d);
            }
            Assert.IsTrue(QuestCatalog.TryCreate(definitions,out var catalog,out var catalogError),catalogError); Catalog=catalog;
            Manager = new QuestManager(Adventurers,Parties,Catalog,Registry,Clock);
            for(var i=1;i<=4;i++) Assert.IsTrue(Manager.TryRegisterOffer(Id(i,2),"quest.test."+(i-1)).Success);
        }
    }

    public sealed class QuestManagerTests
    {
        public static IEnumerable<TestCaseData> Cases()
        {
            var path=Path.Combine(Application.dataPath,"_Project/Tests/Fixtures/quest_v01_cases.json");
            var data=JsonUtility.FromJson<QuestCaseFile>(File.ReadAllText(path));
            foreach(var item in data.cases) yield return new TestCaseData(item).SetName(item.name);
        }
        [Test] public void UnknownDefinitionDoesNotCreateOffer()
        {
            var c=new QuestTestContext();var before=c.Registry.GetSnapshot();
            Assert.AreEqual(QuestResultCode.UnknownDefinition,c.Manager.TryRegisterOffer(QuestTestContext.Id(9,2), "missing").StatusCode);
            Assert.AreEqual(before.Count,c.Registry.GetSnapshot().Count);
            Assert.AreEqual(0,c.Registry.OccupiedSlotCount);
        }
        [Test] public void EmptyGuidIsRejectedAndEquivalentGuidCannotRestart()
        {
            var c=new QuestTestContext();var q=QuestTestContext.Id(1,2);var p=QuestTestContext.Id(1,1);
            Assert.AreEqual(QuestResultCode.InvalidQuestInstanceId,c.Manager.TryStartQuest(Guid.Empty.ToString(),p).StatusCode);
            Assert.IsTrue(c.Manager.TryStartQuest(Guid.Parse(q).ToString("B"),Guid.Parse(p).ToString("N")).Success);
            Assert.AreEqual(QuestResultCode.QuestNotAvailable,c.Manager.TryStartQuest(q,p).StatusCode);
        }

        [TestCaseSource(nameof(Cases))]
        public void ContractCase(QuestCase item)
        {
            var c=new QuestTestContext(item.groups,item.duration);
            foreach(var a in item.actions)
            {
                var beforeParties=c.Parties.GetPartiesSnapshot();
                var beforeQuests=c.Registry.GetSnapshot();
                var observed=c.Registry.ObservedTimestamp; var reads=c.Clock.Reads;
                string actual;
                var q=QuestTestContext.Id(a.quest,2); var p=QuestTestContext.Id(a.party,1); var m=QuestTestContext.Id(a.member);
                switch(a.op)
                {
                    case "start": actual=c.Manager.TryStartQuest(q,p).StatusCode.ToString(); break;
                    case "refresh": actual=c.Manager.RefreshTime().StatusCode.ToString(); break;
                    case "register": actual=c.Manager.TryRegisterOffer(q,"quest.test.0").StatusCode.ToString(); break;
                    case "time": c.Clock.Now=a.now; actual="Success"; break;
                    case "clock_error": c.Clock.Broken=true; actual="Success"; break;
                    case "party_add": actual=c.Parties.TryAddMember(p,m).Status.ToString(); break;
                    case "party_remove": actual=c.Parties.TryRemoveMember(p,m).Status.ToString(); break;
                    case "party_set": actual=c.Parties.TrySetMembers(p,new[]{m}).Status.ToString(); break;
                    case "leader": actual=c.Parties.TrySetLeader(p,m).Status.ToString(); break;
                    case "clear": actual=c.Parties.TryClearLeader(p).Status.ToString(); break;
                    case "dissolve": actual=c.Parties.TryDissolveParty(p).Status.ToString(); break;
                    case "transfer": actual=c.Parties.TryTransferMember(p,QuestTestContext.Id(a.target,1),m).Status.ToString(); break;
                    case "read": c.Manager.GetBoardModel(); actual="Success"; break;
                    case "panel": c.Manager.GetPanelModel(q); actual="Success"; break;
                    default: throw new InvalidOperationException(a.op);
                }
                Assert.AreEqual(a.expected,actual,item.name+"/"+a.op);
                if(actual!="Success")
                {
                    var after=c.Parties.GetPartiesSnapshot(); Assert.AreEqual(beforeParties.Count,after.Count);
                    for(var i=0;i<after.Count;i++) Assert.AreSame(beforeParties[i],after[i],"Rejected action changed group");
                    // Failed starts may update elapsed time, but must never acquire new reservations.
                    for(var i=0;i<beforeQuests.Count;i++)
                    {
                        Assert.IsTrue(c.Registry.TryGet(beforeQuests[i].QuestInstanceId,out var current));
                        Assert.AreEqual(beforeQuests[i].AssignedPartyId,current.AssignedPartyId);
                        CollectionAssert.AreEqual(beforeQuests[i].MemberIdsAtStart,current.MemberIdsAtStart);
                    }
                }
                if(a.op=="read" || a.op=="panel")
                {
                    Assert.AreEqual(reads,c.Clock.Reads); Assert.AreEqual(observed,c.Registry.ObservedTimestamp);
                    var after=c.Registry.GetSnapshot();for(var i=0;i<after.Count;i++) Assert.AreSame(beforeQuests[i],after[i]);
                }
                Assert.AreEqual(12,c.Adventurers.Count);
            }
            Assert.AreEqual(item.expectedOccupied,c.Registry.OccupiedSlotCount);
            var bookedMembers=new HashSet<string>();var bookedGroups=new HashSet<string>();
            for(var i=1;i<=4;i++)
            {
                Assert.IsTrue(c.Manager.TryGetQuest(QuestTestContext.Id(i,2),out var q));
                Assert.AreEqual(item.expectedStatuses[i-1],q.Status.ToString());
                if(q.OccupiesActiveSlot)
                {
                    Assert.IsTrue(bookedGroups.Add(q.AssignedPartyId)); Assert.IsFalse(c.Registry.CanEdit(q.AssignedPartyId));
                    Assert.AreEqual(checked(item.duration*1000L),q.CompletionTimestamp.Value-q.StartTimestamp.Value);
                    Assert.IsTrue(c.Parties.TryGetParty(q.AssignedPartyId,out var party));
                    CollectionAssert.AreEqual(q.MemberIdsAtStart,party.MemberIds); Assert.AreEqual(q.LeaderIdAtStart,party.LeaderId);
                    foreach(var id in q.MemberIdsAtStart) { Assert.IsTrue(bookedMembers.Add(id)); Assert.IsTrue(c.Registry.IsMemberCommitted(id)); }
                }
                else { Assert.IsNull(q.StartTimestamp); Assert.IsNull(q.CompletionTimestamp); Assert.IsNull(q.AssignedPartyId); }
            }
            foreach(var party in c.Parties.GetPartiesSnapshot()) Assert.AreEqual(!bookedGroups.Contains(party.PartyId),c.Registry.CanEdit(party.PartyId));
            for(var i=1;i<=12;i++) Assert.AreEqual(bookedMembers.Contains(QuestTestContext.Id(i)),c.Registry.IsMemberCommitted(QuestTestContext.Id(i)));
        }
    }
}

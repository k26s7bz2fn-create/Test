using System;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;

namespace GuildGame.Tests
{
    public sealed class QuestDefinitionTests
    {
        [TestCase(-1,0,10,1,0,0)]
        [TestCase(4,0,10,1,0,0)]
        [TestCase(0,-1,10,1,0,0)]
        [TestCase(0,3,10,1,0,0)]
        [TestCase(0,0,0,1,0,0)]
        [TestCase(0,0,-1,1,0,0)]
        [TestCase(0,0,10,0,0,0)]
        [TestCase(0,0,10,7,0,0)]
        [TestCase(0,0,10,1,-1,0)]
        [TestCase(0,0,10,1,0,-1)]
        public void InvalidDefinitionRejected(int type,int distance,int duration,int size,int gold,int xp)
        {
            Assert.IsFalse(QuestDefinitionData.TryCreate("q","Name",(QuestType)type,"F",(QuestDistance)distance,
                duration,size,"Danger",gold,xp,Array.Empty<QuestLootContract>(),out var data,out var error));
            Assert.IsNull(data);Assert.IsNotEmpty(error);
        }
        [TestCase("", "Name", "F", "Danger")]
        [TestCase("q", "", "F", "Danger")]
        [TestCase("q", "Name", "", "Danger")]
        [TestCase("q", "Name", "F", "")]
        public void RequiredTextRejected(string id,string name,string rank,string danger)
        {
            Assert.IsFalse(QuestDefinitionData.TryCreate(id,name,QuestType.Gathering,rank,QuestDistance.Near,
                10,1,danger,0,0,Array.Empty<QuestLootContract>(),out _,out _));
        }
        [TestCase(-1,2)] [TestCase(3,2)]
        public void InvalidLootRangeRejected(int min,int max)
        { Assert.Throws<ArgumentOutOfRangeException>(()=>new QuestLootContract("item",min,max)); }

        [Test] public void MissingLootIdRejected()
        { Assert.Throws<ArgumentException>(()=>new QuestLootContract(" ",0,2)); }

        [Test] public void CatalogRejectsDuplicatesAndNulls()
        {
            var c=new QuestTestContext();var d=c.Catalog.Definitions[0];
            Assert.IsFalse(QuestCatalog.TryCreate(new[]{d,d},out _,out _));
            Assert.IsFalse(QuestCatalog.TryCreate(new QuestDefinitionData[]{null},out _,out _));
            Assert.IsFalse(QuestCatalog.TryCreate(null,out _,out _));
        }
        [Test] public void DefinitionCopiesLootAndAllowsZeroRewards()
        {
            var loot=new List<QuestLootContract>{new QuestLootContract("test.item",0,2)};
            Assert.IsTrue(QuestDefinitionData.TryCreate("q","Name",QuestType.Rescue,"F",QuestDistance.Far,10,1,
                "Test",0,0,loot,out var d,out _));
            loot.Clear();Assert.AreEqual(1,d.PossibleLoot.Count);
            Assert.Throws<NotSupportedException>(()=>((IList<QuestLootContract>)d.PossibleLoot).Clear());
        }
        [Test] public void NullLootEntriesRejected()
        {
            Assert.IsFalse(QuestDefinitionData.TryCreate("q","Name",QuestType.Rescue,"F",QuestDistance.Far,10,1,
                "Test",0,0,new QuestLootContract[]{null},out _,out _));
            Assert.IsFalse(QuestDefinitionData.TryCreate("q","Name",QuestType.Rescue,"F",QuestDistance.Far,10,1,
                "Test",0,0,null,out _,out _));
        }
        [Test] public void EmptyAuthorAssetFailsWithoutCreatingProductionData()
        {
            var asset=ScriptableObject.CreateInstance<QuestDefinition>();
            try {Assert.IsFalse(asset.TryBuildData(out _,out _));}
            finally {UnityEngine.Object.DestroyImmediate(asset);}
        }
    }
}

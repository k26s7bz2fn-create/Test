using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class QuestTimeTests
    {
        [Test] public void StartReadsClockOnceAndSetsExactTimestamps()
        {
            var c=new QuestTestContext();var before=c.Clock.Reads;
            var r=c.Manager.TryStartQuest(QuestTestContext.Id(1,2),QuestTestContext.Id(1,1));
            Assert.IsTrue(r.Success);Assert.AreEqual(before+1,c.Clock.Reads);
            Assert.AreEqual(1000L,r.State.StartTimestamp);Assert.AreEqual(11000L,r.State.CompletionTimestamp);
        }
        [Test] public void SameTimestampSequenceProducesSameState()
        {
            var a=new QuestTestContext();var b=new QuestTestContext();
            a.Manager.TryStartQuest(QuestTestContext.Id(1,2),QuestTestContext.Id(1,1));
            b.Manager.TryStartQuest(QuestTestContext.Id(1,2),QuestTestContext.Id(1,1));
            foreach(var now in new long[]{5000,10999,11000,999999,0})
            {
                a.Clock.Now=now;b.Clock.Now=now;a.Manager.RefreshTime();b.Manager.RefreshTime();
                a.Manager.TryGetQuest(QuestTestContext.Id(1,2),out var x);b.Manager.TryGetQuest(QuestTestContext.Id(1,2),out var y);
                Assert.AreEqual(x.Status,y.Status);Assert.AreEqual(x.CompletionTimestamp,y.CompletionTimestamp);
                Assert.AreEqual(a.Registry.OccupiedSlotCount,b.Registry.OccupiedSlotCount);
            }
        }
        [Test] public void PendingNeverResolvesOrReleasesThroughPublicTimeOperations()
        {
            var c=new QuestTestContext();var q=QuestTestContext.Id(1,2);var p=QuestTestContext.Id(1,1);
            var start=c.Manager.TryStartQuest(q,p).State;
            c.Clock.Now=long.MaxValue;
            for(var i=0;i<5;i++) {Assert.IsTrue(c.Manager.RefreshTime().Success);c.Manager.GetBoardModel();c.Manager.GetPanelModel(q);}
            c.Manager.TryGetQuest(q,out var pending);
            Assert.AreEqual(QuestStatus.CompletedPendingResolution,pending.Status);
            Assert.IsFalse(c.Registry.CanEdit(p));Assert.AreEqual(1,c.Registry.OccupiedSlotCount);
            Assert.AreSame(start.DefinitionSnapshot,pending.DefinitionSnapshot);
            CollectionAssert.AreEqual(start.MemberIdsAtStart,pending.MemberIdsAtStart);
            Assert.AreEqual(start.LeaderIdAtStart,pending.LeaderIdAtStart);
        }
    }
}

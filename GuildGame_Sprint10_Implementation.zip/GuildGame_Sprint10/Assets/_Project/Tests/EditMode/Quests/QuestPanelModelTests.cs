using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class QuestPanelModelTests
    {
        [Test] public void ModelsAreDetachedAndCollectionsReadOnly()
        {
            var c=new QuestTestContext();var q=QuestTestContext.Id(1,2);var p=QuestTestContext.Id(1,1);
            c.Manager.RefreshTime();var board=c.Manager.GetBoardModel();var panel=c.Manager.GetPanelModel(q);
            Assert.IsTrue(panel.Parties[0].CanStart);
            Assert.Throws<NotSupportedException>(()=>((IList<QuestRuntimeState>)board.Quests).Clear());
            Assert.Throws<NotSupportedException>(()=>((IList<QuestPanelModel.PartyOption>)panel.Parties).Clear());
            var started=c.Manager.TryStartQuest(q,p).State;
            Assert.Throws<NotSupportedException>(()=>((IList<string>)started.MemberIdsAtStart).Clear());
            Assert.AreEqual(QuestStatus.Available,board.Quests[0].Status);Assert.AreEqual(QuestStatus.Available,panel.Quest.Status);
            Assert.AreEqual(0,board.OccupiedSlotCount);
        }
        [Test] public void UnknownQuestModelIsExplicit()
        {
            var c=new QuestTestContext();
            Assert.AreEqual(QuestResultCode.UnknownQuest,c.Manager.GetPanelModel(QuestTestContext.Id(9,2)).SelectionStatus);
            Assert.AreEqual(QuestResultCode.InvalidQuestInstanceId,c.Manager.GetPanelModel("bad").SelectionStatus);
        }
        [Test] public void PanelTimeIsExplicitAndRemainingIsClamped()
        {
            var c=new QuestTestContext();var q=QuestTestContext.Id(1,2);
            Assert.IsNull(c.Manager.GetBoardModel().AsOfTimestamp);
            Assert.AreEqual(QuestResultCode.InvalidTimestamp,c.Manager.GetPanelModel(q).Parties[0].StartStatus);
            c.Manager.TryStartQuest(q,QuestTestContext.Id(1,1));
            c.Clock.Now=5000;c.Manager.RefreshTime();Assert.AreEqual(6000L,c.Manager.GetPanelModel(q).RemainingMilliseconds);
            c.Clock.Now=0;c.Manager.RefreshTime();Assert.AreEqual(10000L,c.Manager.GetPanelModel(q).RemainingMilliseconds);
            c.Clock.Now=11000;c.Manager.RefreshTime();Assert.AreEqual(0L,c.Manager.GetPanelModel(q).RemainingMilliseconds);
            Assert.IsTrue(c.Manager.GetPanelModel(q).AwaitingResolution);
        }
        [Test] public void ReadsNeitherCallClockNorPublishStatus()
        {
            var c=new QuestTestContext();var q=QuestTestContext.Id(1,2);
            c.Manager.TryStartQuest(q,QuestTestContext.Id(1,1));var reads=c.Clock.Reads;
            c.Clock.Now=11000;c.Clock.Broken=true;
            c.Manager.GetBoardModel();c.Manager.GetPanelModel(q);c.Registry.CanEdit(QuestTestContext.Id(1,1));
            Assert.AreEqual(reads,c.Clock.Reads);
            c.Manager.TryGetQuest(q,out var state);Assert.AreEqual(QuestStatus.Active,state.Status);
        }
    }
}

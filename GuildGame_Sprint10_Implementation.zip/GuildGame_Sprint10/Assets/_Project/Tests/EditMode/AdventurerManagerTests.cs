using System;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class AdventurerManagerTests
    {
        [Test]
        public void TwelveMembersSucceed_ThirteenthFailsWithoutMutation()
        {
            var catalog = Catalog();
            var manager = new AdventurerManager(catalog);
            for (var i = 1; i <= 12; i++) Assert.That(manager.TryAdd(State(i)).Success, Is.True);
            var before = manager.GetMembersSnapshot();
            var result = manager.TryAdd(State(13));
            Assert.That(result.Status, Is.EqualTo(AdventurerStatus.CapacityReached));
            Assert.That(manager.Count, Is.EqualTo(12));
            Assert.That(manager.GetMembersSnapshot()[0], Is.SameAs(before[0]));
        }

        [Test]
        public void DuplicateIdBeatsCapacityReached()
        {
            var manager = new AdventurerManager(Catalog());
            for (var i = 1; i <= 12; i++) manager.TryAdd(State(i));
            var duplicate = State(1, "Same name allowed");
            Assert.That(manager.TryAdd(duplicate).Status, Is.EqualTo(AdventurerStatus.DuplicateId));
            Assert.That(manager.Count, Is.EqualTo(12));
        }

        [Test]
        public void SameDisplayNamesAreAllowed()
        {
            var manager = new AdventurerManager(Catalog());
            Assert.That(manager.TryAdd(State(1, "Arel")).Success, Is.True);
            Assert.That(manager.TryAdd(State(2, "Arel")).Success, Is.True);
        }

        [Test]
        public void SnapshotCannotMutateManagerList()
        {
            var manager = new AdventurerManager(Catalog());
            manager.TryAdd(State(1));
            var snapshot = manager.GetMembersSnapshot();
            Assert.That(snapshot.Count, Is.EqualTo(1));
            Assert.That(manager.Count, Is.EqualTo(1));
            Assert.That(snapshot, Is.Not.InstanceOf<System.Collections.Generic.List<AdventurerState>>());
        }

        [Test]
        public void LookupMissReturnsFalseAndNull()
        {
            var manager = new AdventurerManager(Catalog());
            Assert.That(manager.TryGetById(Guid.NewGuid().ToString("D"), out var found), Is.False);
            Assert.That(found, Is.Null);
        }

        [Test]
        public void UnknownClassAndAppearanceAreRejectedBeforeCapacity()
        {
            var catalog = Catalog();
            var manager = new AdventurerManager(catalog);
            AdventurerState.TryCreate(Guid.NewGuid().ToString("D"), "class.unknown", "Arel", "human.adult.placeholder.01", out var badClass);
            AdventurerState.TryCreate(Guid.NewGuid().ToString("D"), "class.warrior", "Arel", "human.adult.placeholder.99", out var badLook);
            Assert.That(manager.TryAdd(badClass).Status, Is.EqualTo(AdventurerStatus.UnknownClass));
            Assert.That(manager.TryAdd(badLook).Status, Is.EqualTo(AdventurerStatus.UnknownAppearance));
            Assert.That(manager.Count, Is.Zero);
        }

        private static AdventurerCatalog Catalog()
        {
            var gen = TestDefinitions.CreateGeneration();
            Assert.That(gen.TryBuildCatalog(out var catalog, out var error), Is.True, error);
            return catalog;
        }

        private static AdventurerState State(int n, string name = "Arel")
        {
            var id = $"00000000-0000-0000-0000-{n:000000000000}";
            Assert.That(AdventurerState.TryCreate(id, "class.warrior", name, "human.adult.placeholder.01", out var state), Is.True);
            return state;
        }
    }
}

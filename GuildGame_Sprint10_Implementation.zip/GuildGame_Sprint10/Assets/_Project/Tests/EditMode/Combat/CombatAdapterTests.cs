using System;
using System.Collections.Generic;
using GuildGame.Combat;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class CombatAdapterTests
    {
        private static CombatOperationResult Adapt(RewardTestContext c,out CombatInput input,QuestActivityRegistry registry=null)
        {c.Parties.TryGetParty(c.P,out var p);return AdventurerCombatAdapter.TryCreate(c.Members,p,registry??c.Registry,new[]{new EnemyCombatant("enemy","enemy.goblin.melee")},1000,7,out input);}
        [Test] public void AdapterAndFullCombatNeverMutateGuild()
        {
            var c=new RewardTestContext();var before=c.Members.RuntimeStore.Current;var party=c.Parties.GetPartiesSnapshot()[0];
            Assert.IsTrue(Adapt(c,out var input).Success);var s=new CombatSession(input);
            for(int i=0;i<600&&s.State.Phase!=CombatPhase.Completed&&s.State.Phase!=CombatPhase.TechnicalAbort;i++)s.Step();
            Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.AreSame(party,c.Parties.GetPartiesSnapshot()[0]);
            Assert.AreEqual(60,input.Participants[0].StartHP);Assert.AreEqual(24,input.Participants[1].StartMana);
        }
        [TestCase(false)] [TestCase(true)] public void DeadOrInjuredRejected(bool dead)
        {var c=new RewardTestContext();c.SetHealth(c.A,dead,dead?(long?)null:90000);Assert.AreEqual(CombatCode.ParticipantUnavailable,Adapt(c,out _).Code);}
        [TestCase(false)] [TestCase(true)] public void ActivePendingRejected(bool pending)
        {var c=new RewardTestContext();c.Quests.TryStartQuest(c.Q,c.P);if(pending){c.Clock.Now=2000;c.Quests.RefreshTime();}Assert.AreEqual(CombatCode.ParticipantQuestBound,Adapt(c,out _).Code);}
        [Test] public void OtherRegistryCannotBypassActualRosterQuestLock()
        {var c=new RewardTestContext();c.Quests.TryStartQuest(c.Q,c.P);Assert.AreEqual(CombatCode.ParticipantQuestBound,Adapt(c,out _,new QuestActivityRegistry()).Code);}
        [Test] public void EquipmentAndPotionsRemainUnchanged()
        {
            var c=new RewardTestContext();c.Resolve();c.Rewards.TryApply(c.Q);var before=c.Members.RuntimeStore.Current;
            Assert.IsTrue(Adapt(c,out var input).Success);var s=new CombatSession(input);for(int i=0;i<600&&s.State.Result==null&&s.State.Phase!=CombatPhase.TechnicalAbort;i++)s.Step();
            Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.AreSame(before.Storage,c.Members.RuntimeStore.Current.Storage);
            foreach(var a in before.Members){c.Members.TryGetById(a.Id,out var after);Assert.AreSame(a.Equipment,after.Equipment);Assert.AreSame(a.Potions,after.Potions);Assert.AreSame(a.Progression,after.Progression);}
        }
        [Test] public void RecoveryBoundaryAllowsReadOnlyProjection()
        {var c=new RewardTestContext();c.SetHealth(c.A,false,1000);Assert.IsTrue(Adapt(c,out _).Success);}
    }
}

using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class CombatNUnitTests
    {
        public static IEnumerable<string> Cases=>CombatCoreCases.Names;
        [TestCaseSource(nameof(Cases))]
        public void ApprovedCombatContract(string name)=>CombatCoreCases.Run(name);
    }
}

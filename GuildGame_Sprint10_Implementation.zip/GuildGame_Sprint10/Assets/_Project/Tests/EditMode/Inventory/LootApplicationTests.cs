using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class LootApplicationTests
    {
        [Test] public void ApprovedCatalogHasSevenDefinitionsAndNoCombatValues()
        {
            var c=ItemCatalog.CreateV01();Assert.AreEqual(7,c.Definitions.Count);c.TryGet(RewardTestContext.Potion,out var p);
            Assert.IsNull(p.Rarity);Assert.IsNull(p.Slot);Assert.AreEqual(ItemStorageMode.Stack,p.StorageMode);
            c.TryGet(RewardTestContext.Sword,out var s);Assert.AreEqual(ItemRarity.Common,s.Rarity);Assert.AreEqual(EquipmentSlot.Weapon,s.Slot);
            CollectionAssert.AreEqual(new[]{"class.warrior"},s.AllowedClassIds);
        }
        [TestCase(ItemRarity.Common)]
        [TestCase(ItemRarity.Uncommon)]
        [TestCase(ItemRarity.Rare)]
        public void ContractSupportsApprovedEquipmentRarities(ItemRarity rarity)
        {var d=new ItemDefinitionData("test.item","Test",ItemType.ArmorLegs,rarity,new[]{"class.mage"});Assert.AreEqual(EquipmentSlot.Legs,d.Slot);}
        [Test] public void InvalidRarityAndPotionRarityRejected()
        {
            Assert.Throws<ArgumentException>(()=>new ItemDefinitionData("bad","Bad",ItemType.Weapon,(ItemRarity)99,new[]{"class.warrior"}));
            Assert.Throws<ArgumentException>(()=>new ItemDefinitionData("bad","Bad",ItemType.HealingPotion,ItemRarity.Rare,Array.Empty<string>()));
        }
        [Test] public void EquipmentQuantityCreatesDistinctStableInstances()
        {
            var service=new LootApplicationService();var outputs=new[]{new QuestLootOutput("q/loot/0",RewardTestContext.Sword,3)};
            var a=service.Prepare(GuildStorageState.Empty,outputs,ItemCatalog.CreateV01());var b=service.Prepare(GuildStorageState.Empty,outputs,ItemCatalog.CreateV01());
            Assert.AreEqual(3,a.After.Equipment.Count);CollectionAssert.AreEqual(a.CreatedInstanceIds,b.CreatedInstanceIds);
            foreach(var instance in a.After.Equipment.Values)Assert.AreEqual(1,instance.Quantity);
            Assert.Throws<RewardRejectedException>(()=>service.Prepare(a.After,outputs,ItemCatalog.CreateV01()));
        }
        [Test] public void PotionOutputsMergeWithoutGameplayStackCap()
        {
            var outputs=new[]{new QuestLootOutput("a",RewardTestContext.Potion,1000000),new QuestLootOutput("b",RewardTestContext.Potion,1000000)};
            var result=new LootApplicationService().Prepare(GuildStorageState.Empty,outputs,ItemCatalog.CreateV01());
            Assert.AreEqual(2000000,result.After.PotionStacks[RewardTestContext.Potion]);Assert.AreEqual(0,result.After.Equipment.Count);
        }
        [Test] public void PotionNumericOverflowDoesNotMutateInput()
        {
            var before=new GuildStorageState(new Dictionary<string,EquipmentInstance>(),new Dictionary<string,long>{{RewardTestContext.Potion,long.MaxValue}});
            Assert.Throws<OverflowException>(()=>new LootApplicationService().Prepare(before,new[]{new QuestLootOutput("x",RewardTestContext.Potion,1)},ItemCatalog.CreateV01()));
            Assert.AreEqual(long.MaxValue,before.PotionStacks[RewardTestContext.Potion]);
        }
        [TestCase(0)] [TestCase(-1)] public void NonPositiveQuantityRejected(int quantity)
        {Assert.Throws<RewardRejectedException>(()=>new LootApplicationService().Prepare(GuildStorageState.Empty,new[]{new QuestLootOutput("x",RewardTestContext.Potion,quantity)},ItemCatalog.CreateV01()));}
        [Test] public void StockSnapshotsReadOnly()
        {
            Assert.Throws<NotSupportedException>(()=>((IDictionary<string,long>)GuildStorageState.Empty.PotionStacks).Add("x",1));
        }
    }
}

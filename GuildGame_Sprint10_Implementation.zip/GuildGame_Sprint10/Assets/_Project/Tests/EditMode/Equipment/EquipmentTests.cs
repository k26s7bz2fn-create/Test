using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    // Prepared Unity EditMode tests; execution requires the external Unity test environment.
    public sealed class EquipmentTests
    {
        private static EquipmentInstance Item(string id,int score=4,ItemRarity rarity=ItemRarity.Common,string cls="class.warrior",ItemType type=ItemType.Weapon,string definition=null)
        {return new EquipmentInstance(id,new ItemDefinitionData(definition??"test."+id,id,type,rarity,new[]{cls},new EquipmentItemValues(score,0,score,0)),"output/"+id);}
        private static void Stock(RewardTestContext c,long potions,params EquipmentInstance[] items)
        {
            var b=c.Members.RuntimeStore.Current;var gear=new Dictionary<string,EquipmentInstance>();foreach(var i in items)gear.Add(i.InstanceId,i);
            Assert.IsTrue(c.Members.RuntimeStore.TryPublish(b,b.WithEquipment(b.Members,new GuildStorageState(gear,new Dictionary<string,long>{{RewardTestContext.Potion,potions}}))));
        }
        private static AdventurerState Member(RewardTestContext c,string id){c.Members.TryGetById(id,out var a);return a;}
        private static EquipmentManager Manager(RewardTestContext c)=>new EquipmentManager(c.Members);
        [Test] public void HigherSuitabilityWinsOverRare()
        {var c=new RewardTestContext();Stock(c,0,Item("a",2,ItemRarity.Rare),Item("b",4));Assert.IsTrue(Manager(c).TryReevaluateAll().Success);Assert.AreEqual("b",Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon).InstanceId);}
        [Test] public void RareWinsOnlyAtSameSuitability()
        {var c=new RewardTestContext();Stock(c,0,Item("a"),Item("b",4,ItemRarity.Rare));Manager(c).TryReevaluateAll();Assert.AreEqual("b",Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon).InstanceId);}
        [Test] public void EqualQualityKeepsCurrentEvenIfStockIdEarlier()
        {var c=new RewardTestContext();Stock(c,0,Item("z"));Manager(c).TryReevaluateAll();Stock(c,0,Item("a"));Assert.AreEqual(EquipmentCode.NoChange,Manager(c).TryReevaluateAll().Status);Assert.AreEqual("z",Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon).InstanceId);}
        [Test] public void StockDefinitionThenInstanceBreaksTie()
        {var c=new RewardTestContext();var d=Item("z").Definition;Stock(c,0,new EquipmentInstance("z",d,"z"),new EquipmentInstance("a",d,"a"));Manager(c).TryReevaluateAll();Assert.AreEqual("a",Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon).InstanceId);}
        [Test] public void FinalSumRuleHasNoOldComponentVeto()
        {var a=new EquipmentInstance("a",new ItemDefinitionData("a","a",ItemType.Weapon,ItemRarity.Common,new[]{"class.warrior"},new EquipmentItemValues(0,5,0,0)),"a");var b=Item("b",4);Assert.Greater(EquipmentEvaluationRules.CompareQuality(a,b,AdventurerRole.Tank|AdventurerRole.Damage),0);}
        [Test] public void AllThreeSlotsAndClassCompatibility()
        {var c=new RewardTestContext();Stock(c,0,Item("w"),Item("u",type:ItemType.ArmorUpper),Item("l",type:ItemType.ArmorLegs),Item("priest",cls:"class.priest"));Manager(c).TryReevaluateAll();Assert.AreEqual(3,Member(c,c.A).Equipment.Slots.Count);Assert.AreEqual("priest",Member(c,c.B).Equipment.Get(EquipmentSlot.Weapon).InstanceId);}
        [Test] public void ReplacementReturnsExactOldInstance()
        {var c=new RewardTestContext();var old=Item("old",1);Stock(c,0,old);Manager(c).TryReevaluateAll();var next=Item("new",4);Stock(c,0,next);var before=c.Members.RuntimeStore.Current;Manager(c).TryReevaluateAll();var after=c.Members.RuntimeStore.Current;Assert.AreSame(old,after.Storage.Equipment["old"]);Assert.AreSame(next,Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon));EquipmentConsistency.Conservation(before,after);}
        [Test] public void NoStealingFromOtherMember()
        {var c=new RewardTestContext();c.Add(3);Stock(c,0,Item("one"));Manager(c).TryReevaluate(QuestTestContext.Id(3));Manager(c).TryReevaluate(c.A);Assert.IsNull(Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon));}
        [Test] public void StablePassReusesItemReturnedByLaterMember()
        {var c=new RewardTestContext();c.Add(3);Stock(c,0,Item("old",1));Manager(c).TryReevaluate(QuestTestContext.Id(3));Stock(c,0,Item("new",4),Item("top",6));Manager(c).TryReevaluateAll();Assert.AreEqual("top",Member(c,c.A).Equipment.Get(EquipmentSlot.Weapon).InstanceId);Assert.AreEqual("new",Member(c,QuestTestContext.Id(3)).Equipment.Get(EquipmentSlot.Weapon).InstanceId);Assert.IsTrue(c.Members.RuntimeStore.Current.Storage.Equipment.ContainsKey("old"));}
        [Test] public void DeadExcludedInGuildPass()
        {var c=new RewardTestContext();c.SetHealth(c.A,true);Stock(c,0,Item("one"));Manager(c).TryReevaluateAll();Assert.AreEqual(0,Member(c,c.A).Equipment.Slots.Count);Assert.AreEqual(EquipmentCode.AdventurerDead,Manager(c).TryReevaluate(c.A).Status);}
        [Test] public void InjuredIdleCanEquipWithoutHealing()
        {var c=new RewardTestContext();c.SetHealth(c.A,false,90000);Stock(c,0,Item("one"));Manager(c).TryReevaluateAll();Assert.AreEqual(1,Member(c,c.A).Equipment.Slots.Count);Assert.AreEqual(90000,Member(c,c.A).RecoveryUntil);}
        [TestCase(false)] [TestCase(true)] public void ActiveAndPendingPreventAllManualTransfers(bool pending)
        {var c=new RewardTestContext();Stock(c,2,Item("one"));c.Quests.TryStartQuest(c.Q,c.P);if(pending){c.Clock.Now=2000;c.Quests.RefreshTime();}var before=c.Members.RuntimeStore.Current;var m=Manager(c);Assert.AreEqual(EquipmentCode.MemberQuestLocked,m.TryReevaluate(c.A).Status);Assert.AreEqual(EquipmentCode.MemberQuestLocked,m.TryReturnEquipment(c.A).Status);Assert.AreEqual(EquipmentCode.MemberQuestLocked,m.TryReturnPotions(c.A).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);}
        [Test] public void UnknownAndInvalidAreStructured()
        {var c=new RewardTestContext();Assert.AreEqual(EquipmentCode.InvalidAdventurerId,Manager(c).TryReevaluate("bad").Status);Assert.AreEqual(EquipmentCode.UnknownAdventurer,Manager(c).TryReturnEquipment(QuestTestContext.Id(99)).Status);}
        [Test] public void DuplicateLocationFailsWithoutPublication()
        {var c=new RewardTestContext();var item=Item("dup");Stock(c,0,item);Manager(c).TryReevaluateAll();Stock(c,0,item);var before=c.Members.RuntimeStore.Current;Assert.AreEqual(EquipmentCode.DuplicateInstanceLocation,Manager(c).TryReevaluateAll().Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);}
        [Test] public void MissingEvaluationFailsClosed()
        {var c=new RewardTestContext();Stock(c,0,new EquipmentInstance("x",new ItemDefinitionData("unknown","unknown",ItemType.Weapon,ItemRarity.Common,new[]{"class.warrior"}),"x"));Assert.AreEqual(EquipmentCode.MissingEvaluationData,Manager(c).TryReevaluateAll().Status);}
        [Test] public void ConflictingDefinitionsFailClosed()
        {var c=new RewardTestContext();Stock(c,0,Item("a",definition:"same"),Item("b",5,definition:"same"));Assert.AreEqual(EquipmentCode.DefinitionConflict,Manager(c).TryReevaluateAll().Status);}
        [Test] public void ThrowBeforePublishLeavesRootUnchanged()
        {var c=new RewardTestContext();Stock(c,0,Item("x"));var before=c.Members.RuntimeStore.Current;var m=Manager(c);m.BeforePublishForTests=()=>{throw new Exception();};Assert.AreEqual(EquipmentCode.PreparationFailed,m.TryReevaluateAll().Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);}
        [Test] public void ConflictPreservesExternalUpdate()
        {var c=new RewardTestContext();Stock(c,0,Item("x"));var m=Manager(c);m.BeforePublishForTests=()=>c.SetGold(7);Assert.AreEqual(EquipmentCode.StaleState,m.TryReevaluateAll().Status);Assert.AreEqual(7,c.Members.RuntimeStore.Current.Economy.Gold);Assert.AreEqual(0,Member(c,c.A).Equipment.Slots.Count);}
        [Test] public void RepeatedPassIsNoOp()
        {var c=new RewardTestContext();Stock(c,0,Item("x"));var m=Manager(c);m.TryReevaluateAll();var before=c.Members.RuntimeStore.Current;Assert.AreEqual(EquipmentCode.NoChange,m.TryReevaluateAll().Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);}
        [Test] public void ExplicitReturnPreservesQuantityAndHealth()
        {var c=new RewardTestContext();Stock(c,0,Item("x"));Manager(c).TryReevaluateAll();c.SetHealth(c.A,false,90000);Assert.IsTrue(Manager(c).TryReturnEquipment(c.A).Success);Assert.AreEqual(1,c.Members.RuntimeStore.Current.Storage.Equipment.Count);Assert.AreEqual(90000,Member(c,c.A).RecoveryUntil);}
        [Test] public void PanelReadIsImmutable()
        {var c=new RewardTestContext();Stock(c,0,Item("x"));Manager(c).TryReevaluateAll();var before=c.Members.RuntimeStore.Current;var panel=Manager(c).GetPanelModel(c.A,0);Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.Throws<NotSupportedException>(()=>((IDictionary<EquipmentSlot,EquipmentInstance>)panel.Member.Equipment.Slots).Clear());}
        [Test] public void HealerThenLeaderThenOrdinalPotionPriority()
        {var c=new RewardTestContext();c.Add(3);c.Parties.TrySetMembers(c.P,new[]{c.A,c.B,QuestTestContext.Id(3)});c.Parties.TrySetLeader(c.P,QuestTestContext.Id(3));Stock(c,2);var result=c.Quests.TryStartQuest(c.Q,c.P);Assert.IsTrue(result.Success);Assert.AreEqual(1,Member(c,c.B).Potions.Quantities[RewardTestContext.Potion]);Assert.AreEqual(1,Member(c,QuestTestContext.Id(3)).Potions.Quantities[RewardTestContext.Potion]);Assert.AreEqual(0,Member(c,c.A).Potions.Quantities.Count);CollectionAssert.AreEqual(new[]{c.A},result.PotionShortages);}
        [Test] public void HealerLeaderNotCountedTwice()
        {var c=new RewardTestContext();c.Parties.TrySetLeader(c.P,c.B);Stock(c,2);c.Quests.TryStartQuest(c.Q,c.P);Assert.AreEqual(1,Member(c,c.A).Potions.Quantities[RewardTestContext.Potion]);Assert.AreEqual(1,Member(c,c.B).Potions.Quantities[RewardTestContext.Potion]);}
        [Test] public void ShortageAndEmptySlotsAllowStart()
        {var c=new RewardTestContext();var r=c.Quests.TryStartQuest(c.Q,c.P);Assert.IsTrue(r.Success);Assert.AreEqual(2,r.PotionShortages.Count);Assert.AreEqual(1,c.Registry.OccupiedSlotCount);}
        [Test] public void OnlyTargetPartyPrepared()
        {var c=new RewardTestContext();c.Add(3);Stock(c,3,Item("a"),Item("b"));c.Quests.TryStartQuest(c.Q,c.P);Assert.AreEqual(0,Member(c,QuestTestContext.Id(3)).Equipment.Slots.Count);Assert.AreEqual(0,Member(c,QuestTestContext.Id(3)).Potions.Quantities.Count);}
        [Test] public void InjuredAndDeadCannotStartOrReceivePotions()
        {foreach(var dead in new[]{false,true}){var c=new RewardTestContext();Stock(c,2);c.SetHealth(c.A,dead,dead?(long?)null:90000);var before=c.Members.RuntimeStore.Current;Assert.IsFalse(c.Quests.TryStartQuest(c.Q,c.P).Success);Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.AreEqual(0,Member(c,c.A).Potions.Quantities.Count);}}
        [Test] public void InvalidGearStartHasNoTimeOrEquipmentPartialState()
        {var c=new RewardTestContext();Stock(c,2,new EquipmentInstance("x",null,"x"));var before=c.Members.RuntimeStore.Current;Assert.AreEqual(QuestResultCode.EquipmentPreparationFailed,c.Quests.TryStartQuest(c.Q,c.P).StatusCode);Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.AreEqual(0,c.Registry.OccupiedSlotCount);}
        [Test] public void ResolveReturnsUnusedPotionsAndRetainsSurvivorGear()
        {var c=new RewardTestContext();Stock(c,2,Item("one"));c.Pending();var before=c.Members.RuntimeStore.Current;var r=c.Quests.TryResolveQuest(c.Q);Assert.IsTrue(r.HasNewResult);var after=c.Members.RuntimeStore.Current;EquipmentConsistency.Conservation(before,after);Assert.AreEqual(2,after.Storage.PotionStacks[RewardTestContext.Potion]);foreach(var a in after.Members)Assert.AreEqual(0,a.Potions.Quantities.Count);Assert.AreEqual(0,c.Registry.OccupiedSlotCount);Assert.AreEqual(1,Member(c,c.A).Equipment.Slots.Count);}
        [Test] public void ReturnOverflowKeepsPendingAndAllLocks()
        {var c=new RewardTestContext();Stock(c,2);c.Pending();Stock(c,long.MaxValue);var before=c.Members.RuntimeStore.Current;Assert.AreEqual(QuestResolutionCode.NumericOverflow,c.Quests.TryResolveQuest(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.AreEqual(1,c.Registry.OccupiedSlotCount);Assert.IsFalse(c.Registry.CanEdit(c.P));}
        [Test] public void DeadReturnStagingIsConservativeAndDoesNotPublish()
        {var c=new RewardTestContext();Stock(c,1,Item("one"));c.Pending();var before=c.Members.RuntimeStore.Current;var list=new List<AdventurerState>();foreach(var a in before.Members)list.Add(a.Id==c.A?a.WithQuestConsequences(true,null):a);var staged=before.WithMembers(list);var returned=EquipmentManager.PrepareReturns(staged,new[]{c.A,c.B},true,true,true);Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.IsTrue(returned.Snapshot.Storage.Equipment.ContainsKey("one"));EquipmentConsistency.Conservation(before,returned.Snapshot);}
        [Test] public void ResolveRetryDoesNotReturnTwice()
        {var c=new RewardTestContext();Stock(c,2);c.Pending();c.Quests.TryResolveQuest(c.Q);var before=c.Members.RuntimeStore.Current;Assert.AreEqual(QuestResolutionCode.AlreadyResolved,c.Quests.TryResolveQuest(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);}
        [Test] public void RewardCommitSurvivesFailedEquipmentAndRetryDoesNotTrigger()
        {var c=new RewardTestContext();c.Resolve();var calls=0;c.Rewards.BeforeEquipmentForTests=()=>{calls++;throw new Exception();};var r=c.Rewards.TryApply(c.Q);Assert.IsTrue(r.HasNewApplication);Assert.AreEqual(EquipmentCode.PreparationFailed,r.EquipmentPostProcessing.Status);Assert.AreEqual(40,c.Rewards.Economy.Gold);Assert.AreEqual(1,c.Rewards.Ledger.Count);Assert.AreEqual(RewardApplicationCode.AlreadyApplied,c.Rewards.TryApply(c.Q).Status);Assert.AreEqual(1,calls);Assert.IsTrue(Manager(c).TryReevaluateAll().Success);}
        [Test] public void RewardPostPassIncludesInjuredButNotLocked()
        {var c=new RewardTestContext();c.Resolve();c.SetHealth(c.A,false,90000);var r=c.Rewards.TryApply(c.Q);Assert.IsTrue(r.EquipmentPostProcessing.Success);Assert.AreEqual(1,Member(c,c.A).Equipment.Slots.Count);Assert.AreEqual(90000,Member(c,c.A).RecoveryUntil);}
        [Test] public void ProgressionAndHealthCopiesPreserveLoadout()
        {var c=new RewardTestContext();Stock(c,0,Item("one"));Manager(c).TryReevaluateAll();var a=Member(c,c.A);Assert.AreSame(a.Equipment,a.WithQuestConsequences(true,null).Equipment);Assert.AreSame(a.Equipment,a.WithProgression(new ProgressionService().Prepare(a,30,"xp").After).Equipment);}
        [Test] public void LargeSuitabilitySumDoesNotOverflowInt()
        {Assert.AreEqual(4L*int.MaxValue,new EquipmentItemValues(int.MaxValue,int.MaxValue,int.MaxValue,int.MaxValue).Score(AdventurerRole.Tank|AdventurerRole.Damage|AdventurerRole.Healing|AdventurerRole.SupportControl));}
        [Test] public void ActualWipeResolveReturnsGearBeforeUnlock()
        {
            var source=new RewardTestContext();var roster=new AdventurerManager(source.Classes);
            AdventurerState.TryCreate(source.A,"class.warrior","Test","appearance.test",out var a);roster.TryAdd(a);
            var registry=new QuestActivityRegistry();var parties=new PartyManager(roster,source.Classes,registry);
            parties.TryCreateParty(source.P,new[]{source.A});
            QuestDefinitionData.TryCreate("quest.wipe","Wipe",QuestType.MonsterHunt,"F",QuestDistance.Near,1,6,"Hoch",0,0,Array.Empty<QuestLootContract>(),out var definition,out _);
            QuestCatalog.TryCreate(new[]{definition},out var catalog,out _);
            var draws=new SimulationDraws();draws.Values["retreat"]=.99m;draws.Values["incapacitation/"+source.A]=0m;draws.Values["death/"+source.A]=0m;
            var clock=new QuestTestClock();var quests=new QuestManager(roster,parties,catalog,registry,clock,new QuestSimulationService(new QuestSimulationRules(),0,draws));
            quests.TryRegisterOffer(source.Q,definition.DefinitionId);var b=roster.RuntimeStore.Current;
            roster.RuntimeStore.TryPublish(b,b.WithEquipment(b.Members,new GuildStorageState(new Dictionary<string,EquipmentInstance>{{"gear",Item("gear")}},new Dictionary<string,long>{{RewardTestContext.Potion,1}})));
            Assert.IsTrue(quests.TryStartQuest(source.Q,source.P).Success);clock.Now=2000;quests.RefreshTime();var before=roster.RuntimeStore.Current;
            var result=quests.TryResolveQuest(source.Q);Assert.IsTrue(result.HasNewResult);Assert.IsTrue(result.Result.IsWipe);
            roster.TryGetById(source.A,out var dead);Assert.IsTrue(dead.IsDead);Assert.AreEqual(0,dead.Equipment.Slots.Count);Assert.AreEqual(0,dead.Potions.Quantities.Count);
            Assert.IsTrue(roster.RuntimeStore.Current.Storage.Equipment.ContainsKey("gear"));Assert.AreEqual(1,roster.RuntimeStore.Current.Storage.PotionStacks[RewardTestContext.Potion]);
            Assert.AreEqual(0,registry.OccupiedSlotCount);EquipmentConsistency.Conservation(before,roster.RuntimeStore.Current);
        }
    }
}

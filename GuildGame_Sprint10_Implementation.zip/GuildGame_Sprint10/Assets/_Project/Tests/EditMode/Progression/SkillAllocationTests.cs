using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class SkillAllocationTests
    {
        [TestCase("class.warrior")]
        [TestCase("class.rogue")]
        [TestCase("class.mage")]
        [TestCase("class.priest")]
        public void TwentySevenPointsAndSamePathForBatchedLevels(string cls)
        {
            AdventurerState.TryCreate(QuestTestContext.Id(1),cls,"Test","appearance",out var initial);
            var service=new ProgressionService();var direct=service.Prepare(initial,630,"all");var stepped=initial;
            var rules=new ProgressionRules();var skills=new ClassSkillAllocationRules();skills.TryGetSkills(cls,out var catalog);
            for(var level=2;level<=10;level++)
            {
                var change=service.Prepare(stepped,rules.Thresholds[level-1]-rules.Thresholds[level-2],"step"+level);
                Assert.AreEqual(3,change.GrantedPoints);stepped=stepped.WithProgression(change.After);
                for(var i=0;i<9;i++)
                {
                    var expected=((level-1)*3)/9+(i<((level-1)*3)%9?1:0);
                    stepped.Progression.SkillAllocations.TryGetValue(catalog[i].Id,out var actual);Assert.AreEqual(expected,actual);
                }
            }
            Assert.AreEqual(27,direct.After.GrantedSkillPoints);Assert.AreEqual(9,direct.After.SkillAllocations.Count);
            foreach(var entry in direct.After.SkillAllocations){Assert.AreEqual(3,entry.Value);Assert.AreEqual(entry.Value,stepped.Progression.SkillAllocations[entry.Key]);}
        }
    }
}

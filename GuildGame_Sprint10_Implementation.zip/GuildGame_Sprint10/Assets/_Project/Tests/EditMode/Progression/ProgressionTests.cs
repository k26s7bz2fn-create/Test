using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class ProgressionTests
    {
        private static AdventurerState Initial(string cls="class.warrior")
        {AdventurerState.TryCreate(QuestTestContext.Id(1),cls,"Test","test.appearance",out var a);return a;}
        [TestCase(0L,1,0L,0L)]
        [TestCase(29L,1,29L,0L)]
        [TestCase(30L,2,30L,0L)]
        [TestCase(69L,2,69L,0L)]
        [TestCase(70L,3,70L,0L)]
        [TestCase(120L,4,120L,0L)]
        [TestCase(125L,4,125L,0L)]
        [TestCase(180L,5,180L,0L)]
        [TestCase(250L,6,250L,0L)]
        [TestCase(330L,7,330L,0L)]
        [TestCase(420L,8,420L,0L)]
        [TestCase(520L,9,520L,0L)]
        [TestCase(629L,9,629L,0L)]
        [TestCase(630L,10,630L,0L)]
        [TestCase(631L,10,630L,1L)]
        [TestCase(long.MaxValue,10,630L,long.MaxValue-630)]
        public void ApprovedThresholds(long xp,int level,long applied,long overflow)
        {
            var result=new ProgressionService().Prepare(Initial(),xp,"xp");
            Assert.AreEqual(level,result.After.Level);Assert.AreEqual(applied,result.AppliedXp);Assert.AreEqual(overflow,result.CapOverflow);
            Assert.AreEqual((level-1)*3,result.GrantedPoints);
        }
        [Test] public void ExcessAtCapIsNotBanked()
        {
            var service=new ProgressionService();var a=Initial();a=a.WithProgression(service.Prepare(a,600,"a").After);
            var b=service.Prepare(a,80,"b");Assert.AreEqual(30,b.AppliedXp);Assert.AreEqual(50,b.CapOverflow);Assert.AreEqual(3,b.GrantedPoints);
            a=a.WithProgression(b.After);var c=service.Prepare(a,900,"c");Assert.AreEqual(0,c.AppliedXp);Assert.AreEqual(900,c.CapOverflow);Assert.AreEqual(0,c.GrantedPoints);
        }
        [Test] public void NegativeXpRejected(){Assert.Throws<ArgumentException>(()=>new ProgressionService().Prepare(Initial(),-1,"xp"));}
        [Test] public void InvalidPriorSkillsRejected()
        {
            var a=Initial().WithProgression(new AdventurerProgressionState(30,2,new Dictionary<string,int>()));
            Assert.Throws<ArgumentException>(()=>new ProgressionService().Prepare(a,1,"xp"));
        }
        [Test] public void UnknownClassRejected(){Assert.Throws<ArgumentException>(()=>new ProgressionService().Prepare(Initial("class.unknown"),30,"xp"));}
        [Test] public void SnapshotSkillsAreReadOnly()
        {
            var p=new ProgressionService().Prepare(Initial(),630,"xp").After;
            Assert.Throws<NotSupportedException>(()=>((IDictionary<string,int>)p.SkillAllocations).Clear());
        }
    }
}

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GuildGame.Tests
{
    [Serializable] public sealed class SimulationDraw { public string domain; public string value; }
    [Serializable] public sealed class SimulationExpected
    {
        public string power, difficulty;
        public bool retreat, success;
        public int[] dead, recovery, xp;
        public int gold, loot;
    }
    [Serializable] public sealed class SimulationCase
    {
        public string name, danger, leader;
        public string[] roles;
        public int recommended, baseXp, baseGold, rank;
        public SimulationDraw[] draws;
        public SimulationExpected expected;
    }
    [Serializable] public sealed class SimulationCaseFile { public SimulationCase[] cases; }

    internal sealed class SimulationDraws : IQuestSimulationRandom
    {
        internal readonly Dictionary<string,decimal> Values = new Dictionary<string,decimal>();
        internal Action BeforeDraw;
        public decimal Unit(string domain)
        {
            BeforeDraw?.Invoke();
            if (Values.TryGetValue(domain, out var value)) return value;
            if (domain.StartsWith("loot/",StringComparison.Ordinal))
                return Values.TryGetValue(domain.EndsWith("/drop",StringComparison.Ordinal)?"lootDrop":"lootQuantity",out value)?value:.9m;
            return domain=="power" || domain=="objective" ? .5m : .9m;
        }
        internal static SimulationDraws From(SimulationCase c)
        {
            var r=new SimulationDraws();
            foreach(var draw in c.draws)
            {
                var key=draw.domain;
                for(var i=6;i>=1;i--) key=key.Replace("/"+i,"/"+QuestTestContext.Id(i));
                r.Values[key]=decimal.Parse(draw.value,CultureInfo.InvariantCulture);
            }
            return r;
        }
    }
    internal sealed class SimulationContext
    {
        internal readonly AdventurerManager Adventurers;
        internal readonly PartyManager Parties;
        internal readonly QuestManager Manager;
        internal readonly QuestActivityRegistry Registry=new QuestActivityRegistry();
        internal readonly QuestTestClock Clock=new QuestTestClock();
        internal readonly QuestSimulationService Service;
        internal readonly string QuestId=QuestTestContext.Id(1,2), PartyId=QuestTestContext.Id(1,1);
        internal SimulationContext(SimulationCase c, IQuestSimulationRandom draws=null,long seed=0,QuestSimulationRules rules=null)
        {
            var classes=new List<AdventurerCatalog.ClassData>();
            for(var i=0;i<c.roles.Length;i++)
            {
                var roles=AdventurerRole.None;
                if(c.roles[i].Contains("T"))roles|=AdventurerRole.Tank;
                if(c.roles[i].Contains("H"))roles|=AdventurerRole.Healing;
                if(c.roles[i].Contains("D"))roles|=AdventurerRole.Damage;
                classes.Add(new AdventurerCatalog.ClassData("test.class."+i,"Test",roles));
            }
            var catalog=new AdventurerCatalog(classes.ToArray(),new[]{"Test"},new[]{"test.appearance"});
            Adventurers=new AdventurerManager(catalog);
            var ids=new List<string>();
            for(var i=0;i<c.roles.Length;i++)
            {
                Assert.IsTrue(AdventurerState.TryCreate(QuestTestContext.Id(i+1),"test.class."+i,"Test","test.appearance",
                    decimal.Parse(c.leader,CultureInfo.InvariantCulture),0m,out var a));
                Assert.IsTrue(Adventurers.TryAdd(a).Success);ids.Add(a.Id);
            }
            Parties=new PartyManager(Adventurers,catalog,Registry);
            Assert.IsTrue(Parties.TryCreateParty(PartyId,ids).Success);
            Assert.IsTrue(Parties.TrySetLeader(PartyId,ids[0]).Success);
            Assert.IsTrue(QuestDefinitionData.TryCreate("quest.sim.test","Test",QuestType.Gathering,c.rank==0?"F":"TEST.R1",QuestDistance.Near,
                1,c.recommended,c.danger,c.baseGold,c.baseXp,new[]{new QuestLootContract("test.loot",1,2)},out var d,out var e),e);
            Assert.IsTrue(QuestCatalog.TryCreate(new[]{d},out var quests,out e),e);
            if(rules==null){rules=new QuestSimulationRules();rules.RankIndices["TEST.R1"]=1;}
            Service=draws==null?new QuestSimulationService(rules,seed):new QuestSimulationService(rules,seed,draws);
            Manager=new QuestManager(Adventurers,Parties,quests,Registry,Clock,Service);
            Assert.IsTrue(Manager.TryRegisterOffer(QuestId,d.DefinitionId).Success);
        }
        internal void Pending()
        {
            Assert.IsTrue(Manager.TryStartQuest(QuestId,PartyId).Success);
            Clock.Now=2000;Assert.IsTrue(Manager.RefreshTime().Success);
        }
        internal QuestSimulationInput Input(bool reverse=false)
        {
            Assert.IsTrue(Manager.TryGetQuest(QuestId,out var q));
            Assert.IsTrue(Parties.TryGetParty(PartyId,out var p));
            var list=new List<QuestSimulationMember>();
            foreach(var id in p.MemberIds)
            {Adventurers.TryGetById(id,out var a);Adventurers.TryGetClass(a.ClassId,out var c);list.Add(new QuestSimulationMember(a,c.Roles));}
            if(reverse)list.Reverse();
            return new QuestSimulationInput(q,p,list);
        }
    }
    public sealed class QuestSimulationTests
    {
        internal static SimulationCase[] Load() => JsonUtility.FromJson<SimulationCaseFile>(File.ReadAllText(
            Path.Combine(Application.dataPath,"_Project/Tests/Fixtures/simulation_v01_cases.json"))).cases;
        public static IEnumerable<TestCaseData> Examples()
        {foreach(var c in Load())yield return new TestCaseData(c).SetName(c.name);}
        [TestCaseSource(nameof(Examples))]
        public void ApprovedExample(SimulationCase c)
        {
            var ctx=new SimulationContext(c,SimulationDraws.From(c));ctx.Pending();
            var r=ctx.Service.Simulate(ctx.Input());var e=c.expected;
            Assert.AreEqual(decimal.Parse(e.power,CultureInfo.InvariantCulture),r.PartyPower);
            Assert.AreEqual(decimal.Parse(e.difficulty,CultureInfo.InvariantCulture),r.QuestDifficulty);
            Assert.AreEqual(e.retreat,r.RetreatOccurred);Assert.AreEqual(e.success,r.ObjectiveSucceeded);
            Assert.AreEqual(e.gold,r.GoldOutput);Assert.AreEqual(e.dead.Length==c.roles.Length,r.IsWipe);
            for(var i=0;i<c.roles.Length;i++)
            {
                var m=r.MemberResults[i];Assert.AreEqual(Array.IndexOf(e.dead,i+1)>=0,m.IsDead);
                Assert.AreEqual(e.recovery[i],m.RecoverySeconds);Assert.AreEqual(e.xp[i],m.Xp);
                Assert.AreEqual(e.recovery[i]==0?(long?)null:2000+e.recovery[i]*1000L,m.RecoveryUntil);
                if(m.Stabilized){Assert.IsTrue(m.Incapacitated);Assert.IsFalse(m.IsDead);}
            }
            Assert.AreEqual(e.loot==0?0:1,r.LootOutputs.Count);
            if(e.loot>0)Assert.AreEqual(e.loot,r.LootOutputs[0].Quantity);
        }
        [Test] public void SameSeedAndPermutedInputsHaveIdenticalReceipt()
        {
            var c=new SimulationContext(Load()[5],seed:8675309);c.Pending();
            var a=c.Service.Simulate(c.Input());var b=c.Service.Simulate(c.Input(true));
            Assert.AreEqual(a.ResolutionId,b.ResolutionId);Assert.AreEqual(a.Ratio,b.Ratio);
            for(var i=0;i<a.MemberResults.Count;i++)Assert.AreEqual(a.MemberResults[i].RecoveryUntil,b.MemberResults[i].RecoveryUntil);
        }
        [Test] public void DistinctSeedsChangePowerNoise()
        {
            var c=new SimulationContext(Load()[5]);c.Pending();var input=c.Input();
            Assert.AreNotEqual(new QuestSimulationService(seed:1).Simulate(input).Ratio,new QuestSimulationService(seed:2).Simulate(input).Ratio);
        }
        [Test] public void AllSeedsStayWithinApprovedBounds()
        {
            var c=new SimulationContext(Load()[5]);c.Pending();var input=c.Input();
            for(var seed=0;seed<256;seed++)
            {
                var r=new QuestSimulationService(seed:seed).Simulate(input);
                Assert.That(r.Ratio,Is.InRange(.57m,.63m));
                foreach(var m in r.MemberResults)
                {
                    if(m.IsInjured)Assert.That(m.RecoverySeconds,Is.InRange(60,300));
                    if(m.IsDead){Assert.AreEqual(0,m.Xp);Assert.IsNull(m.RecoveryUntil);}
                    Assert.IsFalse(m.Stabilized&&m.IsDead);
                }
            }
        }
        [Test] public void RulesAreCopiedAtServiceConstruction()
        {
            var rules=new QuestSimulationRules();var c=new SimulationContext(Load()[1],rules:rules);c.Pending();
            var a=c.Service.Simulate(c.Input());rules.BasePower=999;rules.DangerFactors["Niedrig"]=999;
            Assert.AreEqual(a.ResolutionId,c.Service.Simulate(c.Input()).ResolutionId);
        }
        [Test] public void InvalidSafetyBoundsRejected()
        {
            Assert.Throws<ArgumentException>(()=>new QuestSimulationService(new QuestSimulationRules{PersonalityRetreat=.031m}));
            Assert.Throws<ArgumentException>(()=>new QuestSimulationService(new QuestSimulationRules{RecoveryMax=301m}));
            Assert.Throws<ArgumentException>(()=>new QuestSimulationService(new QuestSimulationRules{PowerRandom=.051m}));
        }
        [Test] public void LeaderAndPersonalityChangeOnlyRetreatThreshold()
        {
            var ctx=new SimulationContext(Load()[5],new SimulationDraws());ctx.Pending();var input=ctx.Input();
            var versions=new List<QuestSimulationResult>();
            foreach(var bold in new[]{-1m,0m,1m})
            {
                var members=new List<QuestSimulationMember>();
                foreach(var m in input.Members)
                {var a=m.Adventurer;AdventurerState.TryCreate(a.Id,a.ClassId,a.DisplayName,a.AppearanceId,1m,bold,out var b);members.Add(new QuestSimulationMember(b,m.Roles));}
                versions.Add(ctx.Service.Simulate(new QuestSimulationInput(input.Quest,input.Party,members)));
            }
            Assert.AreEqual(versions[0].PartyPower,versions[2].PartyPower);
            Assert.AreEqual(.048m,versions[0].RetreatProbability-versions[2].RetreatProbability);
        }
        [Test] public void StabilizationBoundaryAndSingleAttempt()
        {
            var example=Load()[5];var rng=SimulationDraws.From(example);
            rng.Values["stabilization/"+QuestTestContext.Id(2)+"/"+QuestTestContext.Id(1)]=.65m;
            rng.Values["death/"+QuestTestContext.Id(1)]=0m;
            var c=new SimulationContext(example,rng);c.Pending();var r=c.Service.Simulate(c.Input());
            Assert.IsFalse(r.MemberResults[0].Stabilized);Assert.IsTrue(r.MemberResults[0].IsDead);
        }
        [Test] public void SecondTargetGetsNoSecondAttemptFromOneHealer()
        {
            var example=Load()[5];var rng=SimulationDraws.From(example);
            rng.Values["incapacitation/"+QuestTestContext.Id(3)]=0m;
            rng.Values["death/"+QuestTestContext.Id(3)]=0m;
            var c=new SimulationContext(example,rng);c.Pending();var r=c.Service.Simulate(c.Input());
            Assert.IsTrue(r.MemberResults[0].Stabilized);Assert.IsFalse(r.MemberResults[2].Stabilized);Assert.IsTrue(r.MemberResults[2].IsDead);
        }
        [TestCase(0L,"power",4839085320402873L)]
        [TestCase(1L,"retreat",8950813385244317L)]
        [TestCase(-7L,"injury/1",5704141441359355L)]
        [TestCase(9223372036854775807L,"power",6274983375353621L)]
        public void Sha256MatchesIndependentGoldenVector(long seed,string domain,long numerator)
        {Assert.AreEqual(numerator/9007199254740992m,new QuestSimulationRandom(seed,"test.quest","s7.v1").Unit(domain));}
        [Test] public void RolesDoNotStackAndSupportControlAddsNoPower()
        {
            var c=new SimulationContext(Load()[1],new SimulationDraws());c.Pending();var input=c.Input();
            var changed=new List<QuestSimulationMember>();
            foreach(var m in input.Members)changed.Add(new QuestSimulationMember(m.Adventurer,
                AdventurerRole.Tank|AdventurerRole.Healing|AdventurerRole.Damage|AdventurerRole.SupportControl));
            Assert.AreEqual(36m,c.Service.Simulate(new QuestSimulationInput(input.Quest,input.Party,changed)).PartyPower);
        }
    }
}

using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class QuestResolutionTests
    {
        private static SimulationContext Example(int index)
        {var c=QuestSimulationTests.Load()[index];return new SimulationContext(c,SimulationDraws.From(c));}
        [Test] public void AvailableAndActiveCannotResolve()
        {
            var c=Example(2);var before=c.Adventurers.RuntimeStore.Current;
            Assert.AreEqual(QuestResolutionCode.NotPending,c.Manager.TryResolveQuest(c.QuestId).Status);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);
            c.Manager.TryStartQuest(c.QuestId,c.PartyId);before=c.Adventurers.RuntimeStore.Current;
            Assert.AreEqual(QuestResolutionCode.NotPending,c.Manager.TryResolveQuest(c.QuestId).Status);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);
        }
        [Test] public void InvalidAndUnknownQuestAreStructuredErrors()
        {
            var c=Example(1);
            Assert.AreEqual(QuestResolutionCode.InvalidQuestId,c.Manager.TryResolveQuest("invalid").Status);
            Assert.AreEqual(QuestResolutionCode.UnknownQuest,c.Manager.TryResolveQuest(QuestTestContext.Id(99,2)).Status);
        }
        [Test] public void CommitPublishesHealthAndReceiptTogetherAndRetryIsReadOnly()
        {
            var c=Example(4);c.Pending();var before=c.Adventurers.RuntimeStore.Current;
            var oldMembers=c.Adventurers.GetMembersSnapshot();var r=c.Manager.TryResolveQuest(c.QuestId);
            Assert.AreEqual(QuestResolutionCode.Success,r.Status);Assert.IsTrue(r.HasNewResult);
            var after=c.Adventurers.RuntimeStore.Current;Assert.AreNotSame(before,after);
            Assert.AreEqual(QuestStatus.CompletedPendingResolution,before.Quests[c.QuestId].Status);
            Assert.IsFalse(before.Members[0].IsDead);Assert.IsFalse(oldMembers[0].IsDead);
            Assert.AreEqual(QuestStatus.Resolved,after.Quests[c.QuestId].Status);
            Assert.AreSame(r.Result,after.Quests[c.QuestId].SimulationResult);Assert.IsTrue(after.Members[0].IsDead);
            Assert.IsTrue(after.Members[1].IsInjuredAt(2000));Assert.AreEqual(0,c.Registry.OccupiedSlotCount);
            Assert.IsTrue(c.Registry.CanEdit(c.PartyId));
            foreach(var a in after.Members)Assert.IsFalse(c.Registry.IsMemberCommitted(a.Id));
            var retry=c.Manager.TryResolveQuest(c.QuestId);
            Assert.AreEqual(QuestResolutionCode.AlreadyResolved,retry.Status);Assert.IsFalse(retry.HasNewResult);
            Assert.AreSame(r.Result,retry.Result);Assert.AreSame(after,c.Adventurers.RuntimeStore.Current);
            Assert.AreEqual(oldMembers.Count,c.Adventurers.Count);
            foreach(var a in after.Members){Assert.AreEqual(1,a.Level);Assert.AreEqual("F",a.Rank);}
        }
        [Test] public void FailedSimulationRetainsEveryLockAndEveryState()
        {
            var rng=new SimulationDraws();var c=new SimulationContext(QuestSimulationTests.Load()[5],rng);c.Pending();
            var before=c.Adventurers.RuntimeStore.Current;var observedLocks=false;
            rng.BeforeDraw=()=>{
                observedLocks=ReferenceEquals(before,c.Adventurers.RuntimeStore.Current) &&
                    c.Registry.OccupiedSlotCount==1 && !c.Registry.CanEdit(c.PartyId);
                throw new InvalidOperationException("injected failure");};
            Assert.AreEqual(QuestResolutionCode.SimulationFailed,c.Manager.TryResolveQuest(c.QuestId).Status);
            Assert.IsTrue(observedLocks);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);Assert.AreEqual(1,c.Registry.OccupiedSlotCount);
            Assert.AreEqual(PartyStatus.PartyNotEditable,c.Parties.TryClearLeader(c.PartyId).Status);
        }
        [Test] public void LocksRemainDuringEntireSimulation()
        {
            var rng=new SimulationDraws();var c=new SimulationContext(QuestSimulationTests.Load()[5],rng);c.Pending();var calls=0;
            rng.BeforeDraw=()=>{
                calls++;Assert.AreEqual(1,c.Registry.OccupiedSlotCount);
                Assert.IsFalse(c.Registry.CanEdit(c.PartyId));
                Assert.AreEqual(PartyStatus.PartyNotEditable,c.Parties.TryRemoveMember(c.PartyId,QuestTestContext.Id(1)).Status);
                Assert.AreEqual(PartyStatus.PartyNotEditable,c.Parties.TryClearLeader(c.PartyId).Status);
                Assert.AreEqual(QuestResolutionCode.Busy,c.Manager.TryResolveQuest(c.QuestId).Status);
            };
            Assert.IsTrue(c.Manager.TryResolveQuest(c.QuestId).HasNewResult);Assert.Greater(calls,0);
            Assert.AreEqual(0,c.Registry.OccupiedSlotCount);
        }
        [Test] public void StaleSnapshotDoesNotOverwriteOtherChanges()
        {
            var rng=new SimulationDraws();var c=new SimulationContext(QuestSimulationTests.Load()[5],rng);c.Pending();
            rng.BeforeDraw=()=>{rng.BeforeDraw=null;c.Clock.Now=3000;c.Manager.RefreshTime();};
            var r=c.Manager.TryResolveQuest(c.QuestId);Assert.AreEqual(QuestResolutionCode.StaleState,r.Status);
            Assert.AreEqual(3000,c.Registry.ObservedTimestamp);Assert.AreEqual(1,c.Registry.OccupiedSlotCount);
            Assert.IsTrue(c.Manager.TryGetQuest(c.QuestId,out var q));Assert.IsNull(q.SimulationResult);
            foreach(var a in c.Adventurers.GetMembersSnapshot()){Assert.IsFalse(a.IsDead);Assert.IsNull(a.RecoveryUntil);}
        }
        [Test] public void DeadCannotBeReassignedOrLeadButCanBeRemoved()
        {
            var c=Example(4);c.Pending();c.Manager.TryResolveQuest(c.QuestId);var dead=QuestTestContext.Id(1);
            Assert.AreEqual(PartyStatus.AdventurerDead,c.Parties.TrySetLeader(c.PartyId,dead).Status);
            Assert.IsTrue(c.Parties.TryRemoveMember(c.PartyId,dead).Success);
            Assert.AreEqual(PartyStatus.AdventurerDead,c.Parties.TryAddMember(c.PartyId,dead).Status);
            Assert.AreEqual(PartyStatus.AdventurerDead,c.Parties.TryCreateParty(QuestTestContext.Id(2,1),new[]{dead}).Status);
            Assert.IsTrue(c.Parties.TryGetParty(c.PartyId,out var p));Assert.IsNull(p.LeaderId);
        }
        [Test] public void InjuryBlocksUntilInclusiveRecoveryBoundary()
        {
            var c=Example(2);c.Pending();var result=c.Manager.TryResolveQuest(c.QuestId).Result;
            var until=result.MemberResults[1].RecoveryUntil.Value;var q=QuestTestContext.Id(2,2);
            Assert.IsTrue(c.Manager.TryRegisterOffer(q,"quest.sim.test").Success);
            c.Clock.Now=until-1;Assert.AreEqual(QuestResultCode.AdventurerUnavailable,c.Manager.TryStartQuest(q,c.PartyId).StatusCode);
            c.Clock.Now=until;Assert.IsTrue(c.Manager.TryStartQuest(q,c.PartyId).Success);
        }
        [Test] public void DelayedResolutionUsesCompletionAndDoesNotExtendRecovery()
        {
            var c=Example(2);c.Pending();c.Clock.Now=999999;c.Manager.RefreshTime();
            var result=c.Manager.TryResolveQuest(c.QuestId).Result;
            Assert.AreEqual(62000,result.MemberResults[1].RecoveryUntil);
            c.Adventurers.TryGetById(QuestTestContext.Id(2),out var member);Assert.IsTrue(member.CanDeployAt(c.Clock.Now));
        }
        [Test] public void WipeKeepsRosterAndDeadGroupButReleasesReservation()
        {
            var c=Example(7);c.Pending();var r=c.Manager.TryResolveQuest(c.QuestId);
            Assert.IsTrue(r.Result.IsWipe);Assert.AreEqual(0,r.Result.GoldOutput);Assert.AreEqual(0,r.Result.LootOutputs.Count);
            Assert.AreEqual(1,c.Adventurers.Count);Assert.AreEqual(1,c.Parties.Count);Assert.AreEqual(0,c.Registry.OccupiedSlotCount);
            Assert.IsTrue(c.Manager.TryRegisterOffer(QuestTestContext.Id(2,2),"quest.sim.test").Success);
            Assert.IsFalse(c.Manager.TryStartQuest(QuestTestContext.Id(2,2),c.PartyId).Success);
            Assert.IsTrue(c.Parties.TryDissolveParty(c.PartyId).Success);
        }
        [Test] public void PanelReadsDoNotHealMutateOrResolve()
        {
            var c=Example(2);c.Pending();c.Manager.TryResolveQuest(c.QuestId);var before=c.Adventurers.RuntimeStore.Current;var reads=c.Clock.Reads;
            c.Manager.GetPanelModel(c.QuestId);c.Manager.GetBoardModel();c.Parties.GetPanelModel(c.PartyId);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);Assert.AreEqual(reads,c.Clock.Reads);
        }
        [Test] public void UnmappedRulesFailClosed()
        {
            var example=QuestSimulationTests.Load()[5];example.danger="UNMAPPED";
            var c=new SimulationContext(example);c.Pending();var before=c.Adventurers.RuntimeStore.Current;
            Assert.AreEqual(QuestResolutionCode.InvalidInputOrRules,c.Manager.TryResolveQuest(c.QuestId).Status);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);
        }
        [Test] public void InvalidRandomDrawFailsWithoutCommit()
        {
            var rng=new SimulationDraws();rng.Values["power"]=1m;
            var c=new SimulationContext(QuestSimulationTests.Load()[5],rng);c.Pending();var before=c.Adventurers.RuntimeStore.Current;
            Assert.AreEqual(QuestResolutionCode.InvalidInputOrRules,c.Manager.TryResolveQuest(c.QuestId).Status);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);
        }
        [Test] public void RecoveryOverflowDoesNotCommit()
        {
            var c=Example(2);c.Clock.Now=long.MaxValue-1000;
            Assert.IsTrue(c.Manager.TryStartQuest(c.QuestId,c.PartyId).Success);
            c.Clock.Now=long.MaxValue;c.Manager.RefreshTime();var before=c.Adventurers.RuntimeStore.Current;
            Assert.AreEqual(QuestResolutionCode.NumericOverflow,c.Manager.TryResolveQuest(c.QuestId).Status);
            Assert.AreSame(before,c.Adventurers.RuntimeStore.Current);
        }
        [Test] public void PendingStillBlocksFourthSlotAndFailedResolveKeepsAllThree()
        {
            var old=new QuestTestContext(new[]{new QuestCaseGroup{members=new[]{1}},new QuestCaseGroup{members=new[]{2}},
                new QuestCaseGroup{members=new[]{3}},new QuestCaseGroup{members=new[]{4}}});
            // This fixture has intentionally unmapped danger: the failed resolve MUST NOT release slot 3.
            for(var i=1;i<=3;i++)Assert.IsTrue(old.Manager.TryStartQuest(QuestTestContext.Id(i,2),QuestTestContext.Id(i,1)).Success);
            old.Clock.Now=11000;old.Manager.RefreshTime();
            Assert.AreEqual(QuestResultCode.ActiveQuestLimitReached,old.Manager.TryStartQuest(QuestTestContext.Id(4,2),QuestTestContext.Id(4,1)).StatusCode);
            Assert.AreEqual(QuestResolutionCode.InvalidInputOrRules,old.Manager.TryResolveQuest(QuestTestContext.Id(1,2)).Status);
            Assert.AreEqual(3,old.Registry.OccupiedSlotCount);
        }
        [Test] public void SuccessfulCommitReleasesExactlyOneOfThreeSlots()
        {
            var c=Example(0);Assert.IsTrue(c.Parties.TrySetMembers(c.PartyId,new[]{QuestTestContext.Id(1)}).Success);
            for(var i=2;i<=4;i++)
            {
                Assert.IsTrue(c.Parties.TryCreateParty(QuestTestContext.Id(i,1),new[]{QuestTestContext.Id(i)}).Success);
                Assert.IsTrue(c.Manager.TryRegisterOffer(QuestTestContext.Id(i,2),"quest.sim.test").Success);
            }
            for(var i=1;i<=3;i++)Assert.IsTrue(c.Manager.TryStartQuest(QuestTestContext.Id(i,2),QuestTestContext.Id(i,1)).Success);
            c.Clock.Now=2000;c.Manager.RefreshTime();
            Assert.AreEqual(QuestResultCode.ActiveQuestLimitReached,c.Manager.TryStartQuest(QuestTestContext.Id(4,2),QuestTestContext.Id(4,1)).StatusCode);
            Assert.IsTrue(c.Manager.TryResolveQuest(c.QuestId).HasNewResult);Assert.AreEqual(2,c.Registry.OccupiedSlotCount);
            Assert.IsTrue(c.Manager.TryStartQuest(QuestTestContext.Id(4,2),QuestTestContext.Id(4,1)).Success);
            Assert.AreEqual(3,c.Registry.OccupiedSlotCount);
        }
    }
}

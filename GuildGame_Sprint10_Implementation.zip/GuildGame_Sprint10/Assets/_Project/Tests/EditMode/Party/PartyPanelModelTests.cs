using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class PartyPanelModelTests
    {
        [Test] public void EmptyManagerDoesNotCreateGroupsOnRead()
        {
            var c = new PartyTestContext();
            for (var i = 0; i < 3; i++) Assert.AreEqual(0, c.Manager.GetPanelModel().Parties.Count);
            Assert.AreEqual(0, c.Manager.Count); Assert.AreEqual(12, c.Adventurers.Count);
        }

        [Test] public void InputAndSnapshotsAreDetachedAndReadOnly()
        {
            var c = new PartyTestContext(); var id = PartyTestContext.Group("a");
            var input = new List<string>(PartyTestContext.Members(new[] {1,2}));
            c.Manager.TryCreateParty(id, input);
            var panel = c.Manager.GetPanelModel(id);
            input.Clear();
            Assert.AreEqual(2, panel.SelectedParty.MemberCount);
            Assert.Throws<NotSupportedException>(() => ((IList<string>)panel.SelectedParty.MemberIds).Clear());
            Assert.Throws<NotSupportedException>(() => ((IList<PartyPanelModel.MemberView>)panel.Members).Clear());
            Assert.Throws<NotSupportedException>(() => ((IList<PartyPanelModel.PartyView>)panel.Parties).Clear());
            Assert.Throws<NotSupportedException>(() => ((IList<PartyState>)c.Manager.GetPartiesSnapshot()).Clear());
            c.Manager.TryAddMember(id, PartyTestContext.Member(3));
            Assert.AreEqual(2, panel.SelectedParty.MemberCount);
            Assert.AreEqual(3, c.Manager.GetPanelModel(id).SelectedParty.MemberCount);
        }

        [Test] public void PanelProjectsOwnershipLeaderAndExistingProfile()
        {
            var c = new PartyTestContext(); var id = PartyTestContext.Group("a");
            c.Manager.TryCreateParty(id, PartyTestContext.Members(new[] {1,2}));
            c.Manager.TrySetLeader(id, PartyTestContext.Member(1));
            var model = c.Manager.GetPanelModel(id);
            Assert.IsTrue(model.Members[0].IsLeader);
            Assert.IsTrue(model.Members[0].CanRemove);
            Assert.IsFalse(model.Members[0].CanAdd);
            Assert.IsTrue(model.Members[2].CanAdd);
            Assert.AreEqual("Krieger", model.Members[0].ClassName);
            Assert.AreEqual(AdventurerRole.Tank | AdventurerRole.Damage, model.Members[0].Roles);
            Assert.AreEqual("F", model.Members[0].Rank); Assert.AreEqual(1, model.Members[0].Level);
            Assert.AreEqual(PartyStatus.Success, model.CompositionStatus);
        }

        [Test] public void PolicyChangesRefreshActionsWithoutMutatingGroup()
        {
            var c = new PartyTestContext(); var id = PartyTestContext.Group("a");
            c.Manager.TryCreateParty(id, PartyTestContext.Members(new[] {1,2}));
            var before = c.Manager.GetPanelModel(id);
            c.Policy.Blocked.Add(id);
            var after = c.Manager.GetPanelModel(id);
            Assert.IsTrue(before.CanDissolve); Assert.IsFalse(after.CanDissolve);
            Assert.IsFalse(after.Members[0].CanRemove); Assert.IsFalse(after.Members[2].CanAdd);
            Assert.AreSame(before.SelectedParty, after.SelectedParty);
            c.Policy.Blocked.Clear(); c.Policy.Broken = true;
            Assert.AreEqual(PartyStatus.PolicyUnavailable, c.Manager.GetPanelModel(id).Parties[0].EditStatus);
        }

        [Test] public void UnknownSelectionReturnsExplicitStatus()
        {
            var c = new PartyTestContext();
            var model = c.Manager.GetPanelModel(PartyTestContext.Group("z"));
            Assert.AreEqual(PartyStatus.UnknownParty, model.SelectionStatus);
            Assert.IsNull(model.SelectedParty); Assert.IsFalse(model.CanDissolve);
        }
    }
}

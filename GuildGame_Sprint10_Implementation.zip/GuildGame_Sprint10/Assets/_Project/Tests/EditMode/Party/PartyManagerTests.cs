using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GuildGame.Tests
{
    [Serializable] public sealed class PartyCaseGroup { public string id; public int[] members; public int leader; }
    [Serializable] public sealed class PartyCase
    {
        public string name;
        public PartyCaseGroup[] initial;
        public string[] blocked;
        public bool brokenPolicy;
        public string operation;
        public string[] args;
        public string expectedStatus;
        public PartyCaseGroup[] expected;
    }
    [Serializable] public sealed class PartyCaseFile { public PartyCase[] cases; }

    internal sealed class PartyTestPolicy : IPartyEditPolicy
    {
        public readonly HashSet<string> Blocked = new HashSet<string>();
        public bool Broken;
        public bool CanEdit(string id)
        {
            if (Broken) throw new InvalidOperationException("Test policy failure");
            return !Blocked.Contains(id);
        }
    }

    internal sealed class PartyTestContext
    {
        public readonly AdventurerManager Adventurers;
        public readonly PartyManager Manager;
        public readonly PartyTestPolicy Policy = new PartyTestPolicy();
        public PartyTestContext()
        {
            // Pure runtime catalog; no production ScriptableObject assets are assumed.
            var catalog = new AdventurerCatalog(new[] {
                new AdventurerCatalog.ClassData("class.warrior", "Krieger", AdventurerRole.Tank | AdventurerRole.Damage),
                new AdventurerCatalog.ClassData("class.mage", "Magier", AdventurerRole.Damage | AdventurerRole.SupportControl)
            }, new[] { "Same Name" }, new[] { "human.adult.placeholder.01" });
            Adventurers = new AdventurerManager(catalog);
            for (var i = 1; i <= 12; i++)
            {
                Assert.IsTrue(AdventurerState.TryCreate(Member(i), i == 12 ? "class.mage" : "class.warrior",
                    "Same Name", "human.adult.placeholder.01", out var state));
                Assert.IsTrue(Adventurers.TryAdd(state).Success);
            }
            Manager = new PartyManager(Adventurers, catalog, Policy);
        }
        public static string Member(int i) => i < 0 ? "invalid" : "00000000-0000-0000-0000-" + i.ToString("D12");
        public static string Group(string id) => id == "invalid" ? id : "10000000-0000-0000-0000-" + ((int)id[0]).ToString("D12");
        public static string[] Members(int[] values)
        {
            var result = new string[values.Length];
            for (var i = 0; i < values.Length; i++) result[i] = Member(values[i]);
            return result;
        }
    }

    public sealed class PartyManagerTests
    {
        public static IEnumerable<TestCaseData> Cases()
        {
            var path = Path.Combine(Application.dataPath, "_Project/Tests/Fixtures/party_v01_cases.json");
            var data = JsonUtility.FromJson<PartyCaseFile>(File.ReadAllText(path));
            foreach (var item in data.cases) yield return new TestCaseData(item).SetName(item.name);
        }

        [TestCaseSource(nameof(Cases))]
        public void ContractCase(PartyCase item)
        {
            var context = new PartyTestContext();
            var manager = context.Manager;
            foreach (var group in item.initial)
            {
                Assert.IsTrue(manager.TryCreateParty(PartyTestContext.Group(group.id), PartyTestContext.Members(group.members)).Success);
                if (group.leader != 0) Assert.IsTrue(manager.TrySetLeader(PartyTestContext.Group(group.id), PartyTestContext.Member(group.leader)).Success);
            }
            var before = manager.GetPartiesSnapshot();
            foreach (var id in item.blocked) context.Policy.Blocked.Add(PartyTestContext.Group(id));
            context.Policy.Broken = item.brokenPolicy;
            var a = item.args;
            var groupId = PartyTestContext.Group(a[0]);
            var memberIds = new List<string>();
            if (item.operation == "create" || item.operation == "set")
                for (var i = 1; i < a.Length; i++) memberIds.Add(PartyTestContext.Member(int.Parse(a[i])));
            PartyResult result;
            switch (item.operation)
            {
                case "create": result = manager.TryCreateParty(groupId, memberIds); break;
                case "create_null": result = manager.TryCreateParty(groupId, null); break;
                case "add": result = manager.TryAddMember(groupId, PartyTestContext.Member(int.Parse(a[1]))); break;
                case "add_alias": result = manager.TryAddMember(groupId, Guid.Parse(PartyTestContext.Member(int.Parse(a[1]))).ToString("B").ToUpperInvariant()); break;
                case "remove": result = manager.TryRemoveMember(groupId, PartyTestContext.Member(int.Parse(a[1]))); break;
                case "transfer": result = manager.TryTransferMember(groupId, PartyTestContext.Group(a[1]), PartyTestContext.Member(int.Parse(a[2]))); break;
                case "set": result = manager.TrySetMembers(groupId, memberIds); break;
                case "set_null": result = manager.TrySetMembers(groupId, null); break;
                case "leader": result = manager.TrySetLeader(groupId, PartyTestContext.Member(int.Parse(a[1]))); break;
                case "clear": result = manager.TryClearLeader(groupId); break;
                case "dissolve": result = manager.TryDissolveParty(groupId); break;
                case "validate": result = manager.ValidateComposition(groupId); break;
                default: throw new InvalidOperationException(item.operation);
            }
            Assert.AreEqual(item.expectedStatus, result.Status.ToString());
            Assert.AreEqual(12, context.Adventurers.Count);
            if (!result.Success)
            {
                var after = manager.GetPartiesSnapshot();
                Assert.AreEqual(before.Count, after.Count);
                for (var i = 0; i < before.Count; i++) Assert.AreSame(before[i], after[i], "Failure must publish nothing");
            }
            else
            {
                Assert.AreEqual(item.expected.Length, manager.Count);
                foreach (var expected in item.expected)
                {
                    Assert.IsTrue(manager.TryGetParty(PartyTestContext.Group(expected.id), out var actual));
                    CollectionAssert.AreEqual(PartyTestContext.Members(expected.members), actual.MemberIds);
                    Assert.AreEqual(expected.leader == 0 ? null : PartyTestContext.Member(expected.leader), actual.LeaderId);
                }
            }
            var all = new HashSet<string>();
            foreach (var party in manager.GetPartiesSnapshot())
            {
                Assert.That(party.MemberCount, Is.InRange(1, 6));
                Assert.IsTrue(manager.ValidateComposition(party.PartyId).Success);
                foreach (var id in party.MemberIds)
                {
                    Assert.IsTrue(all.Add(id));
                    Assert.AreEqual(party.PartyId, manager.GetAssignedPartyId(id));
                }
            }
        }

        [Test] public void DissolvedMemberCanJoinAnotherGroup()
        {
            var c = new PartyTestContext(); var a = PartyTestContext.Group("a"); var b = PartyTestContext.Group("b");
            c.Manager.TryCreateParty(a, PartyTestContext.Members(new[] {1}));
            c.Manager.TryCreateParty(b, PartyTestContext.Members(new[] {2}));
            Assert.IsTrue(c.Manager.TryDissolveParty(a).Success);
            Assert.IsNull(c.Manager.GetAssignedPartyId(PartyTestContext.Member(1)));
            Assert.IsTrue(c.Manager.TryAddMember(b, PartyTestContext.Member(1)).Success);
        }

        [Test] public void OneMageIsValidWithoutRoleQuota()
        {
            var c = new PartyTestContext(); var id = PartyTestContext.Group("a");
            Assert.IsTrue(c.Manager.TryCreateParty(id, PartyTestContext.Members(new[] {12})).Success);
            Assert.IsTrue(c.Manager.ValidateComposition(id).Success);
        }
    }
}

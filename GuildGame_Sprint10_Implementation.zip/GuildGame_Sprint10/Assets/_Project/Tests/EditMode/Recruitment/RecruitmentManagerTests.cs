using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class RecruitmentManagerTests
    {
        [Test]
        public void Initialize_TwiceKeepsCandidates()
        {
            var manager = Manager(out _);
            Assert.That(manager.Initialize("session", 12).Success, Is.True);
            var before = manager.GetPanelModel();
            Assert.That(manager.Initialize("other", 999).Success, Is.True);
            var after = manager.GetPanelModel();
            Assert.That(after.SessionId, Is.EqualTo(before.SessionId));
            for (var i = 0; i < 5; i++) Assert.That(after.Candidates[i].CandidateId, Is.EqualTo(before.Candidates[i].CandidateId));
        }

        [Test]
        public void Generate_WrongCountRejected()
        {
            var catalog = Catalog();
            var manager = new RecruitmentManager(new AdventurerManager(catalog), new StubGenerator(FourCandidates(catalog)));
            Assert.That(manager.Initialize("session", 1).Status, Is.EqualTo(RecruitmentStatus.InvalidCandidateCount));
            Assert.That(manager.Session, Is.Null);
        }

        [Test]
        public void Generate_DuplicateIdsRejected()
        {
            var catalog = Catalog();
            var candidates = FourCandidates(catalog);
            var first = candidates[0];
            candidates.Add(first);
            var manager = new RecruitmentManager(new AdventurerManager(catalog), new StubGenerator(candidates));
            Assert.That(manager.Initialize("session", 1).Status, Is.EqualTo(RecruitmentStatus.DuplicateCandidateId));
        }


        [Test]
        public void Select_BeforeInitializeIsSessionNotReady()
        {
            var manager = Manager(out _);
            Assert.That(manager.SelectCandidate(Guid.NewGuid().ToString("D")).Status, Is.EqualTo(RecruitmentStatus.SessionNotReady));
        }

        [Test]
        public void Deselect_NotSelectedRejected()
        {
            var manager = Ready(out _);
            Assert.That(manager.DeselectCandidate(manager.Session.Candidates[0].CandidateId).Status, Is.EqualTo(RecruitmentStatus.CandidateNotSelected));
        }

        [Test]
        public void Initialize_EmptySessionIdRejected()
        {
            var manager = Manager(out _);
            Assert.That(manager.Initialize(" ", 1).Status, Is.EqualTo(RecruitmentStatus.InvalidCandidateData));
            Assert.That(manager.Session, Is.Null);
        }

        [Test]
        public void Select_UnknownIdRejected()
        {
            var manager = Ready(out _);
            Assert.That(manager.SelectCandidate(Guid.NewGuid().ToString("D")).Status, Is.EqualTo(RecruitmentStatus.InvalidCandidateId));
        }

        [Test]
        public void Select_DuplicateRejected()
        {
            var manager = Ready(out _);
            var id = manager.Session.Candidates[0].CandidateId;
            Assert.That(manager.SelectCandidate(id).Success, Is.True);
            Assert.That(manager.SelectCandidate(id).Status, Is.EqualTo(RecruitmentStatus.CandidateAlreadySelected));
            Assert.That(manager.Session.SelectedCount, Is.EqualTo(1));
        }

        [Test]
        public void Select_FourthRejected()
        {
            var manager = Ready(out _);
            SelectFirstThree(manager);
            Assert.That(manager.SelectCandidate(manager.Session.Candidates[3].CandidateId).Status, Is.EqualTo(RecruitmentStatus.SelectionLimitReached));
            Assert.That(manager.Session.SelectedCount, Is.EqualTo(3));
        }

        [Test]
        public void Deselect_AllowsReplacement()
        {
            var manager = Ready(out _);
            SelectFirstThree(manager);
            var removed = manager.Session.Candidates[1].CandidateId;
            Assert.That(manager.DeselectCandidate(removed).Success, Is.True);
            Assert.That(manager.SelectCandidate(manager.Session.Candidates[3].CandidateId).Success, Is.True);
            Assert.That(manager.Session.SelectedCount, Is.EqualTo(3));
            Assert.That(manager.GetPanelModel().Candidates[1].IsSelected, Is.False);
        }

        [Test]
        public void Confirm_WrongCountRejected()
        {
            var manager = Ready(out _);
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.InvalidSelectionCount));
            manager.SelectCandidate(manager.Session.Candidates[0].CandidateId);
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.InvalidSelectionCount));
            manager.SelectCandidate(manager.Session.Candidates[1].CandidateId);
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.InvalidSelectionCount));
        }

        [Test]
        public void Confirm_ExactlyThreeAccepted()
        {
            var manager = Ready(out var roster);
            SelectFirstThree(manager);
            var result = manager.ConfirmSelection();
            Assert.That(result.Success, Is.True);
            Assert.That(roster.Count, Is.EqualTo(3));
            Assert.That(manager.Session.State, Is.EqualTo(RecruitmentState.Committed));
            Assert.That(result.AdventurerIds.Count, Is.EqualTo(3));
        }

        [Test]
        public void Confirm_NineMembersAllowsTwelve()
        {
            var manager = Ready(out var roster, initialMembers: 9);
            SelectFirstThree(manager);
            Assert.That(manager.ConfirmSelection().Success, Is.True);
            Assert.That(roster.Count, Is.EqualTo(12));
        }

        [TestCase(10)]
        [TestCase(11)]
        [TestCase(12)]
        public void Confirm_TenOrMoreRejected(int count)
        {
            var manager = Ready(out var roster, initialMembers: count);
            SelectFirstThree(manager);
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.GuildCapacityExceeded));
            Assert.That(roster.Count, Is.EqualTo(count));
            Assert.That(manager.Session.State, Is.EqualTo(RecruitmentState.Selecting));
        }

        [Test]
        public void Confirm_RechecksCapacity()
        {
            var manager = Ready(out var roster, initialMembers: 9);
            SelectFirstThree(manager);
            Assert.That(manager.GetPanelModel().CanCommit, Is.True);
            Assert.That(roster.TryAdd(State(Catalog(), "class.warrior", 99)).Success, Is.True);
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.GuildCapacityExceeded));
        }

        [Test]
        public void Confirm_IsAtomicOnFailure()
        {
            var catalog = Catalog();
            var roster = new AdventurerManager(catalog);
            var manager = new RecruitmentManager(roster, new StartCandidateGenerator(catalog));
            manager.Initialize("session", 7);
            SelectFirstThree(manager);
            var duplicate = manager.Session.Candidates[0].AdventurerData;
            Assert.That(roster.TryAdd(duplicate).Success, Is.True);
            var before = roster.Count;
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.CommitFailed));
            Assert.That(roster.Count, Is.EqualTo(before));
            Assert.That(manager.Session.State, Is.EqualTo(RecruitmentState.Selecting));
        }

        [Test]
        public void Confirm_SecondCallDoesNotDuplicate()
        {
            var manager = Ready(out var roster);
            SelectFirstThree(manager);
            Assert.That(manager.ConfirmSelection().Success, Is.True);
            var count = roster.Count;
            Assert.That(manager.ConfirmSelection().Status, Is.EqualTo(RecruitmentStatus.SessionAlreadyCommitted));
            Assert.That(roster.Count, Is.EqualTo(count));
        }

        [Test]
        public void Committed_SelectionLocked()
        {
            var manager = Ready(out _);
            SelectFirstThree(manager);
            manager.ConfirmSelection();
            Assert.That(manager.DeselectCandidate(manager.Session.Candidates[0].CandidateId).Status, Is.EqualTo(RecruitmentStatus.SessionAlreadyCommitted));
        }

        [Test]
        public void Preview_DoesNotRegisterMembers()
        {
            var manager = Ready(out var roster);
            Assert.That(roster.Count, Is.Zero);
            Assert.That(manager.GetPanelModel().Candidates.Count, Is.EqualTo(5));
            Assert.That(roster.Count, Is.Zero);
        }

        private static RecruitmentManager Ready(out AdventurerManager roster, int initialMembers = 0)
        {
            var manager = Manager(out roster);
            var catalog = Catalog();
            for (var i = 1; i <= initialMembers; i++) Assert.That(roster.TryAdd(State(catalog, "class.warrior", 100 + i)).Success, Is.True);
            Assert.That(manager.Initialize("session", 42).Success, Is.True);
            return manager;
        }

        private static RecruitmentManager Manager(out AdventurerManager roster)
        {
            var catalog = Catalog();
            roster = new AdventurerManager(catalog);
            return new RecruitmentManager(roster, new StartCandidateGenerator(catalog));
        }

        private static void SelectFirstThree(RecruitmentManager manager)
        {
            for (var i = 0; i < 3; i++) Assert.That(manager.SelectCandidate(manager.Session.Candidates[i].CandidateId).Success, Is.True);
        }

        private static AdventurerCatalog Catalog()
        {
            var gen = TestDefinitions.CreateGeneration();
            Assert.That(gen.TryBuildCatalog(out var catalog, out var error), Is.True, error);
            return catalog;
        }

        private static AdventurerState State(AdventurerCatalog catalog, string classId, int n)
        {
            var id = $"00000000-0000-0000-0000-{n:000000000000}";
            Assert.That(AdventurerState.TryCreate(id, classId, "Arel", "human.adult.placeholder.01", out var state), Is.True);
            return state;
        }

        private static List<RecruitmentCandidate> FourCandidates(AdventurerCatalog catalog)
        {
            var list = new List<RecruitmentCandidate>();
            for (var i = 1; i <= 4; i++)
            {
                var state = State(catalog, "class.warrior", i);
                list.Add(new RecruitmentCandidate(state.Id, "session", state));
            }
            return list;
        }

        private sealed class StubGenerator : IStartCandidateGenerator
        {
            private readonly IReadOnlyList<RecruitmentCandidate> candidates;
            public StubGenerator(IReadOnlyList<RecruitmentCandidate> candidates) { this.candidates = candidates; }
            public RecruitmentResult Generate(string sessionId, int seed, out IReadOnlyList<RecruitmentCandidate> result)
            {
                result = candidates;
                return RecruitmentResult.Ok();
            }
        }
    }
}

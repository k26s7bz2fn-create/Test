using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class RecruitmentPanelModelTests
    {
        [Test]
        public void Panel_ReflectsSelectionAndCapacity()
        {
            var catalog = Catalog();
            var roster = new AdventurerManager(catalog);
            var manager = new RecruitmentManager(roster, new StartCandidateGenerator(catalog));
            manager.Initialize("session", 42);
            manager.SelectCandidate(manager.Session.Candidates[0].CandidateId);
            var panel = manager.GetPanelModel();
            Assert.That(panel.Candidates.Count, Is.EqualTo(5));
            Assert.That(panel.SelectedCount, Is.EqualTo(1));
            Assert.That(panel.GuildMemberCount, Is.EqualTo(0));
            Assert.That(panel.GuildCapacity, Is.EqualTo(12));
            Assert.That(panel.CanCommit, Is.False);
            Assert.That(panel.Candidates[0].IsSelected, Is.True);
        }

        [Test]
        public void Panel_ReadDoesNotChangeState()
        {
            var catalog = Catalog();
            var roster = new AdventurerManager(catalog);
            var manager = new RecruitmentManager(roster, new StartCandidateGenerator(catalog));
            manager.Initialize("session", 42);
            var before = manager.Session.Candidates[0].CandidateId;
            var state = manager.Session.State;
            for (var i = 0; i < 5; i++) manager.GetPanelModel();
            Assert.That(manager.Session.Candidates[0].CandidateId, Is.EqualTo(before));
            Assert.That(manager.Session.State, Is.EqualTo(state));
            Assert.That(roster.Count, Is.Zero);
        }

        [Test]
        public void Contract_UsesExistingAdventurerData()
        {
            var catalog = Catalog();
            var roster = new AdventurerManager(catalog);
            var manager = new RecruitmentManager(roster, new StartCandidateGenerator(catalog));
            manager.Initialize("session", 42);
            var candidate = manager.Session.Candidates[0];
            var panel = manager.GetPanelModel().Candidates[0];
            Assert.That(panel.DisplayName, Is.EqualTo(candidate.AdventurerData.DisplayName));
            Assert.That(panel.ClassId, Is.EqualTo(candidate.AdventurerData.ClassId));
            Assert.That(panel.Rank, Is.EqualTo(candidate.AdventurerData.Rank));
            Assert.That(panel.Level, Is.EqualTo(candidate.AdventurerData.Level));
            Assert.That(panel.AppearanceId, Is.EqualTo(candidate.AdventurerData.AppearanceId));
        }

        private static AdventurerCatalog Catalog()
        {
            var gen = TestDefinitions.CreateGeneration();
            Assert.That(gen.TryBuildCatalog(out var catalog, out var error), Is.True, error);
            return catalog;
        }
    }
}

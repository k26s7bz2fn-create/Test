using System;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;

namespace GuildGame.Tests
{
    public sealed class StartCandidateGeneratorTests
    {
        [Test]
        public void Generate_ExactlyFiveCandidates()
        {
            var result = Generator().Generate("start-session", 42, out var candidates);
            Assert.That(result.Success, Is.True, result.Message);
            Assert.That(candidates.Count, Is.EqualTo(5));
        }

        [Test]
        public void Generate_AllCandidatesAreF1()
        {
            Generator().Generate("start-session", 42, out var candidates);
            foreach (var c in candidates)
            {
                Assert.That(c.AdventurerData.Rank, Is.EqualTo("F"));
                Assert.That(c.AdventurerData.Level, Is.EqualTo(1));
            }
        }

        [Test]
        public void Generate_OnlyBasicClasses()
        {
            var allowed = new HashSet<string>(StringComparer.Ordinal)
            { "class.warrior", "class.rogue", "class.mage", "class.priest" };
            Generator().Generate("start-session", 42, out var candidates);
            foreach (var c in candidates) Assert.That(allowed.Contains(c.AdventurerData.ClassId), Is.True);
        }

        [Test]
        public void Generate_RequiredRolesAvailable()
        {
            var catalog = Catalog();
            new StartCandidateGenerator(catalog).Generate("start-session", 42, out var candidates);
            var front = false;
            var healing = false;
            var damage = false;
            var frontId = string.Empty;
            var healingId = string.Empty;
            var damageId = string.Empty;
            foreach (var c in candidates)
            {
                Assert.That(catalog.TryGetClass(c.AdventurerData.ClassId, out var data), Is.True);
                if (!front && (data.Roles & AdventurerRole.Tank) != 0) { front = true; frontId = c.CandidateId; continue; }
                if (!healing && (data.Roles & AdventurerRole.Healing) != 0) { healing = true; healingId = c.CandidateId; continue; }
                if (!damage && (data.Roles & AdventurerRole.Damage) != 0) { damage = true; damageId = c.CandidateId; }
            }
            Assert.That(front && healing && damage, Is.True);
            Assert.That(new HashSet<string> { frontId, healingId, damageId }.Count, Is.EqualTo(3));
        }


        [Test]
        public void Generate_ImpossibleCoverageFails()
        {
            var catalog = MalformedCatalog(
                new[] { "class.warrior", "class.rogue", "class.mage", "class.priest" },
                new[] { AdventurerRole.Damage, AdventurerRole.Damage, AdventurerRole.Damage, AdventurerRole.Damage });
            var result = new StartCandidateGenerator(catalog).Generate("session", 1, out var candidates);
            Assert.That(result.Status, Is.EqualTo(RecruitmentStatus.InsufficientRoleCoverage));
            Assert.That(candidates.Count, Is.Zero);
        }

        [Test]
        public void Generate_InvalidDefinitionFails()
        {
            var catalog = MalformedCatalog(
                new[] { "class.warrior", "class.rogue", "class.mage", "class.invalid" },
                new[] { AdventurerRole.Tank | AdventurerRole.Damage, AdventurerRole.Damage, AdventurerRole.Damage | AdventurerRole.SupportControl, AdventurerRole.Healing });
            var result = new StartCandidateGenerator(catalog).Generate("session", 1, out var candidates);
            Assert.That(result.Status, Is.EqualTo(RecruitmentStatus.InvalidClassDefinition));
            Assert.That(candidates.Count, Is.Zero);
        }

        [Test]
        public void Generate_SameInputsSameOutput()
        {
            var a = Generator();
            var b = Generator();
            a.Generate("same-session", 12345, out var left);
            b.Generate("same-session", 12345, out var right);
            Assert.That(right.Count, Is.EqualTo(left.Count));
            for (var i = 0; i < left.Count; i++)
            {
                Assert.That(right[i].CandidateId, Is.EqualTo(left[i].CandidateId));
                Assert.That(right[i].AdventurerData.ClassId, Is.EqualTo(left[i].AdventurerData.ClassId));
                Assert.That(right[i].AdventurerData.DisplayName, Is.EqualTo(left[i].AdventurerData.DisplayName));
                Assert.That(right[i].AdventurerData.AppearanceId, Is.EqualTo(left[i].AdventurerData.AppearanceId));
            }
        }

        [Test]
        public void Generate_DifferentSessionsUniqueIds()
        {
            Generator().Generate("session-a", 77, out var a);
            Generator().Generate("session-b", 77, out var b);
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in a) Assert.That(ids.Add(c.CandidateId), Is.True);
            foreach (var c in b) Assert.That(ids.Add(c.CandidateId), Is.True);
        }


        private static AdventurerCatalog MalformedCatalog(string[] ids, AdventurerRole[] roles)
        {
            var classCtor = typeof(AdventurerCatalog.ClassData).GetConstructor(
                BindingFlags.Instance | BindingFlags.NonPublic, null,
                new[] { typeof(string), typeof(string), typeof(AdventurerRole) }, null);
            Assert.That(classCtor, Is.Not.Null);
            var data = new AdventurerCatalog.ClassData[ids.Length];
            for (var i = 0; i < ids.Length; i++)
                data[i] = (AdventurerCatalog.ClassData)classCtor.Invoke(new object[] { ids[i], ids[i], roles[i] });

            var catalogCtor = typeof(AdventurerCatalog).GetConstructor(
                BindingFlags.Instance | BindingFlags.NonPublic, null,
                new[] { typeof(AdventurerCatalog.ClassData[]), typeof(string[]), typeof(string[]) }, null);
            Assert.That(catalogCtor, Is.Not.Null);
            return (AdventurerCatalog)catalogCtor.Invoke(new object[]
            {
                data,
                new[] { "Arel", "Mira" },
                new[] { "human.adult.placeholder.01" }
            });
        }

        private static StartCandidateGenerator Generator() => new StartCandidateGenerator(Catalog());

        private static AdventurerCatalog Catalog()
        {
            var gen = TestDefinitions.CreateGeneration();
            Assert.That(gen.TryBuildCatalog(out var catalog, out var error), Is.True, error);
            return catalog;
        }
    }
}

using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class RewardApplicationTests
    {
        [Test] public void ApplyAllThenRetryHasNoMutation()
        {
            var c=new RewardTestContext();var source=c.Resolve();var result=c.Rewards.TryApply(c.Q);
            Assert.AreEqual(RewardApplicationCode.Applied,result.Status);Assert.IsTrue(result.HasNewApplication);
            Assert.AreSame(source,result.Receipt.Source);Assert.AreEqual(40,c.Rewards.Economy.Gold);
            Assert.AreEqual(2,c.Rewards.Storage.PotionStacks[RewardTestContext.Potion]);Assert.AreEqual(1,c.Rewards.Storage.Equipment.Count);Assert.AreEqual(1,c.Members.GetMembersSnapshot()[0].Equipment.Slots.Count);
            foreach(var a in c.Members.GetMembersSnapshot()){Assert.AreEqual(2,a.Level);Assert.AreEqual(3,a.Progression.GrantedSkillPoints);}
            var after=c.Members.RuntimeStore.Current;var retry=c.Rewards.TryApply(c.Q);
            Assert.AreEqual(RewardApplicationCode.AlreadyApplied,retry.Status);Assert.AreSame(result.Receipt,retry.Receipt);Assert.AreSame(after,c.Members.RuntimeStore.Current);
        }
        [Test] public void AvailableActiveAndPendingAreRejected()
        {
            var c=new RewardTestContext();Assert.AreEqual(RewardApplicationCode.QuestNotResolved,c.Rewards.TryApply(c.Q).Status);
            c.Quests.TryStartQuest(c.Q,c.P);Assert.AreEqual(RewardApplicationCode.QuestNotResolved,c.Rewards.TryApply(c.Q).Status);
            c.Clock.Now=2000;c.Quests.RefreshTime();Assert.AreEqual(RewardApplicationCode.QuestNotResolved,c.Rewards.TryApply(c.Q).Status);
        }
        [Test] public void UnknownIdsAreStructured()
        {
            var c=new RewardTestContext();Assert.AreEqual(RewardApplicationCode.InvalidQuestId,c.Rewards.TryApply("bad").Status);
            Assert.AreEqual(RewardApplicationCode.UnknownQuest,c.Rewards.TryApply(QuestTestContext.Id(99,2)).Status);
        }
        [Test] public void LaterDeathStillGetsEarlierXpWithoutResurrection()
        {
            var c=new RewardTestContext();c.Resolve(125);c.SetHealth(c.A,true);c.SetHealth(c.B,false,90000);
            Assert.IsTrue(c.Rewards.TryApply(c.Q).HasNewApplication);
            c.Members.TryGetById(c.A,out var a);c.Members.TryGetById(c.B,out var b);
            Assert.IsTrue(a.IsDead);Assert.IsNull(a.RecoveryUntil);Assert.AreEqual(4,a.Level);Assert.AreEqual(9,a.Progression.GrantedSkillPoints);
            Assert.AreEqual(90000,b.RecoveryUntil);Assert.AreEqual(4,b.Level);
        }
        [Test] public void OriginalDeadReceivesZero()
        {
            var c=new RewardTestContext();c.Resolve(originalDead:true);c.SetHealth(c.A,true);c.Rewards.TryApply(c.Q);
            c.Members.TryGetById(c.A,out var a);Assert.AreEqual(1,a.Level);Assert.AreEqual(0,a.Progression.TotalAppliedXp);Assert.IsTrue(a.IsDead);
        }
        [Test] public void CurrentPartyIsNotRewardRecipientSource()
        {
            var c=new RewardTestContext();c.Resolve();Assert.IsTrue(c.Parties.TryDissolveParty(c.P).Success);
            Assert.IsTrue(c.Rewards.TryApply(c.Q).HasNewApplication);Assert.AreEqual(2,c.Members.GetMembersSnapshot()[0].Level);
        }
        [Test] public void UnknownLootRejectsEntireReward()
        {
            var c=new RewardTestContext();c.Resolve(loot:new[]{new QuestLootOutput("loot","unknown",1)});var before=c.Members.RuntimeStore.Current;
            Assert.AreEqual(RewardApplicationCode.UnknownItemDefinition,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void DuplicateOutputRejected()
        {
            var c=new RewardTestContext();c.Resolve(loot:new[]{new QuestLootOutput("same",RewardTestContext.Potion,1),new QuestLootOutput("same",RewardTestContext.Sword,1)});
            var before=c.Members.RuntimeStore.Current;Assert.AreEqual(RewardApplicationCode.RewardIdentityConflict,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void ZeroRewardsStillRecordedOnce()
        {
            var c=new RewardTestContext();c.Resolve(0,0,Array.Empty<QuestLootOutput>());
            Assert.IsTrue(c.Rewards.TryApply(c.Q).HasNewApplication);Assert.AreEqual(1,c.Rewards.Ledger.Count);
            Assert.AreEqual(RewardApplicationCode.AlreadyApplied,c.Rewards.TryApply(c.Q).Status);
        }
        [Test] public void NegativeGoldAndOverflowRejectWithoutPartialXp()
        {
            var c=new RewardTestContext();c.Resolve(gold:-1);var before=c.Members.RuntimeStore.Current;
            Assert.AreEqual(RewardApplicationCode.InvalidRewardAmount,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
            c=new RewardTestContext();c.Resolve();c.SetGold(long.MaxValue);before=c.Members.RuntimeStore.Current;
            Assert.AreEqual(RewardApplicationCode.NumericOverflow,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void RealSprintSevenResolveIsConsumedWithoutRecomputation()
        {
            var c=new RewardTestContext();c.Pending();var resolution=c.Quests.TryResolveQuest(c.Q);Assert.IsTrue(resolution.HasNewResult);
            Assert.IsTrue(c.Rewards.TryApply(c.Q).HasNewApplication);Assert.AreEqual(resolution.Result.GoldOutput,c.Rewards.Economy.Gold);
            foreach(var m in resolution.Result.MemberResults){c.Members.TryGetById(m.AdventurerId,out var a);Assert.AreEqual(m.Xp,a.Progression.TotalAppliedXp);}
        }
        [Test] public void MissingRecipientFailsClosed()
        {
            var c=new RewardTestContext();c.Resolve();c.Members.TryGetById(c.A,out var a);c.Members.RuntimeStore.ReplaceMembers(new[]{a});
            var before=c.Members.RuntimeStore.Current;Assert.AreEqual(RewardApplicationCode.UnknownRecipient,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void DeadInOriginalResultCannotHavePositiveXp()
        {
            var c=new RewardTestContext();c.Resolve();
            c.ReplaceResultForTest(rows=>{var m=rows[0];rows[0]=new QuestMemberOutcome(m.AdventurerId,true,false,true,0,null,30,m.XpOutputId);return rows;});
            var before=c.Members.RuntimeStore.Current;Assert.AreEqual(RewardApplicationCode.InvalidRecipientContract,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void DuplicateRecipientAbortsAll()
        {
            var c=new RewardTestContext();c.Resolve();c.ReplaceResultForTest(rows=>{rows[1]=rows[0];return rows;});
            var before=c.Members.RuntimeStore.Current;Assert.AreEqual(RewardApplicationCode.InvalidRecipientContract,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void ChangedStoredReceiptAfterApplyIsIdentityConflict()
        {
            var c=new RewardTestContext();c.Resolve();c.Rewards.TryApply(c.Q);c.ReplaceResultForTest(rows=>rows);
            var before=c.Members.RuntimeStore.Current;Assert.AreEqual(RewardApplicationCode.RewardIdentityConflict,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void NegativeXpRejected()
        {
            var c=new RewardTestContext();c.Resolve(-1);var before=c.Members.RuntimeStore.Current;
            Assert.AreEqual(RewardApplicationCode.InvalidRewardAmount,c.Rewards.TryApply(c.Q).Status);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
    }
}

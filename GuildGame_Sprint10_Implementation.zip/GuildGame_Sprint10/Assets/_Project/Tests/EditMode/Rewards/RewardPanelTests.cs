using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class RewardPanelTests
    {
        [Test] public void ReadingPreviewDoesNotApplyOrReadClock()
        {
            var c=new RewardTestContext();var source=c.Resolve();var before=c.Members.RuntimeStore.Current;var reads=c.Clock.Reads;
            var view=c.Rewards.GetPanelModel(c.Q);Assert.IsTrue(view.CanApply);Assert.IsTrue(view.IsPreview);Assert.IsFalse(view.IsApplied);
            Assert.AreSame(source,view.Result);Assert.AreSame(before,c.Members.RuntimeStore.Current);Assert.AreEqual(reads,c.Clock.Reads);
            Assert.AreEqual(0,c.Rewards.Ledger.Count);
            Assert.Throws<NotSupportedException>(()=>((IList<ProgressionChange>)view.Receipt.Members).Clear());
        }
        [Test] public void AppliedPanelShowsStoredReceipt()
        {
            var c=new RewardTestContext();c.Resolve();var result=c.Rewards.TryApply(c.Q);var before=c.Members.RuntimeStore.Current;
            var view=c.Rewards.GetPanelModel(c.Q);Assert.IsTrue(view.IsApplied);Assert.IsFalse(view.CanApply);Assert.IsFalse(view.IsPreview);
            Assert.AreSame(result.Receipt,view.Receipt);Assert.AreSame(before,c.Members.RuntimeStore.Current);
        }
        [Test] public void BlockedPanelContainsReasonAndNoReceipt()
        {
            var c=new RewardTestContext();c.Resolve(loot:new[]{new QuestLootOutput("x","unknown",1)});
            var view=c.Rewards.GetPanelModel(c.Q);Assert.IsFalse(view.CanApply);Assert.AreEqual(RewardApplicationCode.UnknownItemDefinition,view.Validation);Assert.IsNull(view.Receipt);
        }
    }
}

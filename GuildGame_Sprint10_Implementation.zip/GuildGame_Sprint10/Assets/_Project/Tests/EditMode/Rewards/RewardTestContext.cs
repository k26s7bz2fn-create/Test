using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    internal sealed class RewardTestContext
    {
        internal const string Potion="item.potion.healing.basic", Sword="item.weapon.training_sword.common";
        internal readonly AdventurerCatalog Classes;
        internal readonly AdventurerManager Members;
        internal readonly PartyManager Parties;
        internal readonly QuestActivityRegistry Registry=new QuestActivityRegistry();
        internal readonly QuestTestClock Clock=new QuestTestClock();
        internal readonly QuestManager Quests;
        internal readonly RewardApplicationManager Rewards;
        internal string Q=>QuestTestContext.Id(1,2);
        internal string P=>QuestTestContext.Id(1,1);
        internal string A=>QuestTestContext.Id(1);
        internal string B=>QuestTestContext.Id(2);
        internal RewardTestContext()
        {
            Classes=new AdventurerCatalog(new[]{new AdventurerCatalog.ClassData("class.warrior","Krieger",AdventurerRole.Tank|AdventurerRole.Damage),
                new AdventurerCatalog.ClassData("class.priest","Priester",AdventurerRole.Healing|AdventurerRole.SupportControl)},new[]{"Test"},new[]{"appearance.test"});
            Members=new AdventurerManager(Classes);
            Add(1,"class.warrior");Add(2,"class.priest");
            Parties=new PartyManager(Members,Classes,Registry);
            Assert.IsTrue(Parties.TryCreateParty(P,new[]{A,B}).Success);
            Assert.IsTrue(QuestDefinitionData.TryCreate("quest.reward.test","Test",QuestType.Gathering,"F",QuestDistance.Near,1,2,"Normal",40,60,
                new[]{new QuestLootContract(Potion,2,2)},out var def,out var error),error);
            QuestCatalog.TryCreate(new[]{def},out var catalog,out _);
            Quests=new QuestManager(Members,Parties,catalog,Registry,Clock,new QuestSimulationService(new QuestSimulationRules(),0,new SimulationDraws()));
            Quests.TryRegisterOffer(Q,def.DefinitionId);Rewards=new RewardApplicationManager(Members);
        }
        internal void Add(int n,string cls="class.warrior")
        {AdventurerState.TryCreate(QuestTestContext.Id(n),cls,"Test","appearance.test",out var a);Assert.IsTrue(Members.TryAdd(a).Success);}
        internal QuestRuntimeState Pending()
        {
            Assert.IsTrue(Quests.TryStartQuest(Q,P).Success);Clock.Now=2000;Quests.RefreshTime();Quests.TryGetQuest(Q,out var q);return q;
        }
        internal QuestSimulationResult Resolve(long xp=30,long gold=40,QuestLootOutput[] loot=null,bool originalDead=false)
        {
            var q=Pending();Parties.TryGetParty(P,out var p);var inputs=new List<QuestSimulationMember>();
            foreach(var id in p.MemberIds){Members.TryGetById(id,out var a);Members.TryGetClass(a.ClassId,out var d);inputs.Add(new QuestSimulationMember(a,d.Roles));}
            var input=new QuestSimulationInput(q,p,inputs);var rid="test.resolution.1";
            var outcomes=new List<QuestMemberOutcome>{new QuestMemberOutcome(A,originalDead,false,originalDead,0,null,originalDead?0:xp,rid+"/xp/"+A),
                new QuestMemberOutcome(B,false,false,false,0,null,xp,rid+"/xp/"+B)};
            var result=new QuestSimulationResult(input,rid,"s7.v1","test.rules",0,24,20,1.2m,0,0,.98m,true,false,false,gold,outcomes,
                new List<QuestLootOutput>(loot??new[]{new QuestLootOutput(rid+"/loot/0",Potion,2),new QuestLootOutput(rid+"/loot/1",Sword,2)}));
            PublishResolved(q,result);return result;
        }
        internal void PublishResolved(QuestRuntimeState q,QuestSimulationResult result)
        {
            var before=Members.RuntimeStore.Current;var states=new Dictionary<string,QuestRuntimeState>(before.Quests);states[q.QuestInstanceId]=q.Resolve(result);
            Assert.IsTrue(Members.RuntimeStore.TryPublish(before,before.WithQuests(before.Members,states,before.ObservedTimestamp)));
        }
        internal void ReplaceResultForTest(Func<List<QuestMemberOutcome>,List<QuestMemberOutcome>> replaceMembers)
        {
            Quests.TryGetQuest(Q,out var current);Parties.TryGetParty(P,out var party);
            var pending=QuestRuntimeState.Available(Q,current.DefinitionSnapshot).Start(party,1000,2000).MarkPending();
            var inputs=new List<QuestSimulationMember>();
            foreach(var id in party.MemberIds){Members.TryGetById(id,out var a);Members.TryGetClass(a.ClassId,out var d);inputs.Add(new QuestSimulationMember(a,d.Roles));}
            var original=current.SimulationResult;
            var changed=new QuestSimulationResult(new QuestSimulationInput(pending,party,inputs),original.ResolutionId,"s7.v1","test.rules",0,24,20,1.2m,0,0,.98m,true,false,false,
                original.GoldOutput,replaceMembers(new List<QuestMemberOutcome>(original.MemberResults)),new List<QuestLootOutput>(original.LootOutputs));
            PublishResolved(pending,changed);
        }
        internal void SetHealth(string id,bool dead,long? recovery=null)
        {
            var before=Members.RuntimeStore.Current;var list=new List<AdventurerState>();
            foreach(var a in before.Members)list.Add(a.Id==id?a.WithQuestConsequences(dead,recovery):a);
            Members.RuntimeStore.ReplaceMembers(list);
        }
        internal void SetGold(long gold)
        {var b=Members.RuntimeStore.Current;Members.RuntimeStore.TryPublish(b,b.WithRewards(b.Members,new GuildEconomyState(gold),b.Storage,b.RewardLedger));}
    }
}

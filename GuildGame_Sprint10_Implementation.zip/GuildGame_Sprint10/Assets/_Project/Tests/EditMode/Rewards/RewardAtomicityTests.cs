using System;
using System.Collections.Generic;
using NUnit.Framework;
namespace GuildGame.Tests
{
    public sealed class RewardAtomicityTests
    {
        [Test] public void FaultAfterPreparationPublishesNothing()
        {
            var c=new RewardTestContext();c.Resolve();var before=c.Members.RuntimeStore.Current;var observed=false;
            c.Rewards.BeforePublishForTests=()=>{observed=ReferenceEquals(before,c.Members.RuntimeStore.Current);throw new InvalidOperationException("fault");};
            Assert.AreEqual(RewardApplicationCode.PreparationFailed,c.Rewards.TryApply(c.Q).Status);
            Assert.IsTrue(observed);Assert.AreSame(before,c.Members.RuntimeStore.Current);
            c.Rewards.BeforePublishForTests=null;Assert.IsTrue(c.Rewards.TryApply(c.Q).HasNewApplication);
        }
        [Test] public void RecursiveApplyIsBusyAndRewardThenEquipmentAreComplete()
        {
            var c=new RewardTestContext();c.Resolve();var before=c.Members.RuntimeStore.Current;RewardApplicationCode inner=RewardApplicationCode.Applied;
            c.Rewards.BeforePublishForTests=()=>{Assert.AreSame(before,c.Members.RuntimeStore.Current);inner=c.Rewards.TryApply(c.Q).Status;};
            var result=c.Rewards.TryApply(c.Q);Assert.IsTrue(result.HasNewApplication);Assert.AreEqual(RewardApplicationCode.Busy,inner);
            var after=c.Members.RuntimeStore.Current;Assert.AreNotSame(before,after);Assert.AreEqual(40,after.Economy.Gold);
            Assert.AreEqual(1,after.RewardLedger.Count);Assert.AreEqual(1,after.Storage.Equipment.Count);Assert.AreEqual(1,after.Members[0].Equipment.Slots.Count);Assert.AreEqual(2,after.Members[0].Level);
            Assert.AreEqual(0,before.Economy.Gold);Assert.AreEqual(0,before.RewardLedger.Count);Assert.AreEqual(1,before.Members[0].Level);
        }
        [Test] public void SnapshotConflictPreservesOtherUpdate()
        {
            var c=new RewardTestContext();c.Resolve();c.Rewards.BeforePublishForTests=()=>{c.Clock.Now=3000;c.Quests.RefreshTime();};
            Assert.AreEqual(RewardApplicationCode.StaleState,c.Rewards.TryApply(c.Q).Status);
            Assert.AreEqual(3000,c.Registry.ObservedTimestamp);Assert.AreEqual(0,c.Rewards.Ledger.Count);Assert.AreEqual(0,c.Rewards.Economy.Gold);
        }
        [Test] public void SecondManagerCannotDoubleApplyDuringConflict()
        {
            var c=new RewardTestContext();c.Resolve();var other=new RewardApplicationManager(c.Members);RewardApplicationResult nested=null;
            c.Rewards.BeforePublishForTests=()=>nested=other.TryApply(c.Q);
            Assert.AreEqual(RewardApplicationCode.StaleState,c.Rewards.TryApply(c.Q).Status);Assert.IsTrue(nested.HasNewApplication);
            Assert.AreEqual(40,c.Rewards.Economy.Gold);Assert.AreEqual(1,c.Rewards.Ledger.Count);
        }
        [Test] public void RosterTimeAndNewQuestPublicationsPreserveRewards()
        {
            var c=new RewardTestContext();c.Resolve();c.Rewards.TryApply(c.Q);var before=c.Members.RuntimeStore.Current;
            c.Add(3);c.Clock.Now=3000;c.Quests.RefreshTime();c.Quests.TryRegisterOffer(QuestTestContext.Id(2,2),"quest.reward.test");
            var after=c.Members.RuntimeStore.Current;
            Assert.AreSame(before.Economy,after.Economy);Assert.AreSame(before.Storage,after.Storage);Assert.AreSame(before.RewardLedger,after.RewardLedger);
            Assert.AreEqual(3,c.Members.Count);Assert.AreEqual(2,after.Members[0].Level);
        }
        [Test] public void ActualResolutionRetainsRewardsAndUsesCurrentLevel()
        {
            var c=new RewardTestContext();c.Resolve();var q2=QuestTestContext.Id(2,2);
            c.Quests.TryRegisterOffer(q2,"quest.reward.test");Assert.IsTrue(c.Quests.TryStartQuest(q2,c.P).Success);
            // Apply older reward AFTER quest 2 starts, per approved P8-11.
            c.Rewards.TryApply(c.Q);var before=c.Members.RuntimeStore.Current;
            c.Clock.Now=3000;c.Quests.RefreshTime();var resolution=c.Quests.TryResolveQuest(q2);
            Assert.IsTrue(resolution.HasNewResult);Assert.AreEqual(26.4m,resolution.Result.PartyPower);
            var after=c.Members.RuntimeStore.Current;Assert.AreSame(before.Economy,after.Economy);Assert.AreSame(before.Storage,after.Storage);Assert.AreSame(before.RewardLedger,after.RewardLedger);
            Assert.AreEqual(2,after.Members[0].Level);Assert.AreEqual(30,after.Members[0].Progression.TotalAppliedXp);
        }
        [Test] public void HealthCopyPreservesProgressionAndProgressionCopyPreservesHealth()
        {
            var c=new RewardTestContext();c.Resolve();c.Rewards.TryApply(c.Q);c.Members.TryGetById(c.A,out var a);
            var health=a.WithQuestConsequences(true,null);Assert.AreSame(a.Progression,health.Progression);
            var updated=health.WithProgression(new ProgressionService().Prepare(health,95,"older").After);
            Assert.IsTrue(updated.IsDead);Assert.AreEqual(4,updated.Level);Assert.IsNull(updated.RecoveryUntil);
        }
    }
}

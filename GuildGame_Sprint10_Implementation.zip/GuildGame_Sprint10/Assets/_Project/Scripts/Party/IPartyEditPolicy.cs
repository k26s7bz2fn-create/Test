namespace GuildGame
{
    /// <summary>
    /// Read-only boundary for a future authoritative mission system. No quest activation here.
    /// Called synchronously on the owning game thread. Implementations must be side-effect free.
    /// </summary>
    public interface IPartyEditPolicy
    {
        bool CanEdit(string partyId);
    }

    /// <summary>Until a mission system is bound, all registered groups are inactive/editable.</summary>
    public sealed class InactivePartyEditPolicy : IPartyEditPolicy
    {
        public bool CanEdit(string partyId) => true;
    }
}

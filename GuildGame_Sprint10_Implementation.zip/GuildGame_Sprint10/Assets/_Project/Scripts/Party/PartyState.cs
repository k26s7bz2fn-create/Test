using System;
using System.Collections.Generic;

namespace GuildGame
{
    /// <summary>Immutable party snapshot. Ordering is display order, never combat formation.</summary>
    public sealed class PartyState
    {
        public const int MinimumMembers = 1;
        public const int MaximumMembers = 6;
        public string PartyId { get; }
        public IReadOnlyList<string> MemberIds { get; }
        public string LeaderId { get; }
        public int MemberCount => MemberIds.Count;

        internal PartyState(string partyId, IEnumerable<string> members, string leaderId = null)
        {
            PartyId = partyId;
            MemberIds = Array.AsReadOnly(new List<string>(members).ToArray());
            LeaderId = leaderId;
        }
    }
}

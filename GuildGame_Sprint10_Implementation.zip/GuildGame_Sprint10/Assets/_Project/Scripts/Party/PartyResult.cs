namespace GuildGame
{
    public enum PartyStatus
    {
        Success = 0,
        InvalidPartyId,
        UnknownParty,
        PartyAlreadyExists,
        InvalidMemberId,
        UnknownAdventurer,
        MemberAlreadyAssigned,
        MemberAssignedElsewhere,
        MemberNotAssigned,
        PartyCapacityReached,
        InvalidMemberCount,
        DuplicateMemberId,
        InvalidInput,
        SameParty,
        PartyNotEditable,
        PolicyUnavailable,
        UnresolvedMemberReference,
        AdventurerDead
    }

    public sealed class PartyResult
    {
        public PartyStatus Status { get; }
        public bool Success => Status == PartyStatus.Success;
        public string Message { get; }
        public PartyState State { get; }
        public PartyState SourceState { get; }

        internal PartyResult(PartyStatus status, PartyState state = null, PartyState sourceState = null)
        {
            Status = status;
            Message = status == PartyStatus.Success ? string.Empty : status.ToString();
            State = state;
            SourceState = sourceState;
        }
    }
}

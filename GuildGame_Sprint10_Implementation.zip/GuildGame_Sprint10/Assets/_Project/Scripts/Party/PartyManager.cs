using System;
using System.Collections.Generic;

namespace GuildGame
{
    /// <summary>
    /// Owns party memberships, not adventurers. Use on the owning game thread only.
    /// Each mutation stages a new registry and publishes it in one reference assignment.
    /// No callbacks occur between validation and publication.
    /// </summary>
    public sealed class PartyManager
    {
        private readonly AdventurerManager adventurers;
        private readonly IPartyEditPolicy editPolicy;
        private readonly AdventurerCatalog catalog;
        private Dictionary<string, PartyState> parties = new Dictionary<string, PartyState>(StringComparer.Ordinal);
        public int Count => parties.Count;

        // Sprint 6: reject mismatched quest/party composition roots; no gameplay mutation.
        internal bool UsesDependencies(AdventurerManager members, IPartyEditPolicy policy) =>
            ReferenceEquals(adventurers, members) && ReferenceEquals(editPolicy, policy);

        public PartyManager(AdventurerManager adventurers, AdventurerCatalog catalog, IPartyEditPolicy editPolicy = null)
        {
            this.adventurers = adventurers ?? throw new ArgumentNullException(nameof(adventurers));
            this.catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
            this.editPolicy = editPolicy ?? new InactivePartyEditPolicy();
        }

        internal static bool NormalizeId(string input, out string id)
        {
            id = null;
            if (!Guid.TryParse(input, out var value) || value == Guid.Empty) return false;
            id = value.ToString("D");
            return true;
        }

        public bool TryGetParty(string partyId, out PartyState state)
        {
            state = null;
            return NormalizeId(partyId, out var id) && parties.TryGetValue(id, out state);
        }

        public IReadOnlyList<PartyState> GetPartiesSnapshot()
        {
            var states = new List<PartyState>(parties.Values);
            states.Sort((a, b) => string.CompareOrdinal(a.PartyId, b.PartyId));
            return Array.AsReadOnly(states.ToArray());
        }

        public string GetAssignedPartyId(string adventurerId)
        {
            return NormalizeId(adventurerId, out var id) ? FindOwner(id) : null;
        }

        private string FindOwner(string id)
        {
            foreach (var party in parties.Values)
                if (Contains(party, id)) return party.PartyId;
            return null;
        }

        private static bool Contains(PartyState party, string id)
        {
            for (var i = 0; i < party.MemberIds.Count; i++)
                if (party.MemberIds[i] == id) return true;
            return false;
        }

        private PartyStatus ResolveParty(string input, out PartyState party)
        {
            party = null;
            if (!NormalizeId(input, out var id)) return PartyStatus.InvalidPartyId;
            return parties.TryGetValue(id, out party) ? PartyStatus.Success : PartyStatus.UnknownParty;
        }

        internal PartyStatus CheckEditable(string partyId)
        {
            try { return editPolicy.CanEdit(partyId) ? PartyStatus.Success : PartyStatus.PartyNotEditable; }
            catch { return PartyStatus.PolicyUnavailable; } // Fail closed; never silently unlock a party.
        }

        private PartyStatus ResolveMember(string input, out string id)
        {
            if (!NormalizeId(input, out id)) return PartyStatus.InvalidMemberId;
            return adventurers.TryGetById(id, out _) ? PartyStatus.Success : PartyStatus.UnknownAdventurer;
        }

        private PartyStatus ValidateMembers(IReadOnlyList<string> input, string allowedOwner, out List<string> members)
        {
            members = null;
            if (input == null) return PartyStatus.InvalidInput;
            // Copy before validation so later caller changes cannot change the published snapshot.
            var copy = new List<string>(input);
            if (copy.Count < PartyState.MinimumMembers || copy.Count > PartyState.MaximumMembers)
                return PartyStatus.InvalidMemberCount;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            for (var i = 0; i < copy.Count; i++)
            {
                var status = ResolveMember(copy[i], out var id);
                if (status != PartyStatus.Success) return status;
                if (adventurers.TryGetById(id, out var member) && member.IsDead) return PartyStatus.AdventurerDead;
                if (!seen.Add(id)) return PartyStatus.DuplicateMemberId;
                var owner = FindOwner(id);
                if (owner != null && owner != allowedOwner) return PartyStatus.MemberAssignedElsewhere;
                copy[i] = id;
            }
            members = copy;
            return PartyStatus.Success;
        }

        private void Publish(PartyState state)
        {
            var next = new Dictionary<string, PartyState>(parties, StringComparer.Ordinal);
            next[state.PartyId] = state;
            parties = next;
        }

        public PartyResult TryCreateParty(string partyId, IReadOnlyList<string> memberIds)
        {
            if (!NormalizeId(partyId, out var id)) return new PartyResult(PartyStatus.InvalidPartyId);
            if (parties.ContainsKey(id)) return new PartyResult(PartyStatus.PartyAlreadyExists);
            var status = ValidateMembers(memberIds, null, out var members);
            if (status != PartyStatus.Success) return new PartyResult(status);
            var state = new PartyState(id, members);
            Publish(state);
            return new PartyResult(PartyStatus.Success, state);
        }

        public PartyResult TryDissolveParty(string partyId)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(party.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            var next = new Dictionary<string, PartyState>(parties, StringComparer.Ordinal);
            next.Remove(party.PartyId);
            parties = next;
            return new PartyResult(PartyStatus.Success);
        }

        public PartyResult TryAddMember(string partyId, string memberId)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(party.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ResolveMember(memberId, out var id);
            if (status != PartyStatus.Success) return new PartyResult(status);
            if (adventurers.TryGetById(id, out var member) && member.IsDead) return new PartyResult(PartyStatus.AdventurerDead);
            var owner = FindOwner(id);
            if (owner != null) return new PartyResult(owner == party.PartyId ? PartyStatus.MemberAlreadyAssigned : PartyStatus.MemberAssignedElsewhere);
            if (party.MemberCount >= PartyState.MaximumMembers) return new PartyResult(PartyStatus.PartyCapacityReached);
            var members = new List<string>(party.MemberIds) { id };
            var state = new PartyState(party.PartyId, members, party.LeaderId);
            Publish(state);
            return new PartyResult(PartyStatus.Success, state);
        }

        public PartyResult TryRemoveMember(string partyId, string memberId)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(party.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ResolveMember(memberId, out var id);
            if (status != PartyStatus.Success) return new PartyResult(status);
            if (!Contains(party, id)) return new PartyResult(PartyStatus.MemberNotAssigned);
            if (party.MemberCount <= PartyState.MinimumMembers) return new PartyResult(PartyStatus.InvalidMemberCount);
            var members = new List<string>(party.MemberIds);
            members.Remove(id);
            var state = new PartyState(party.PartyId, members, party.LeaderId == id ? null : party.LeaderId);
            Publish(state);
            return new PartyResult(PartyStatus.Success, state);
        }

        public PartyResult TrySetMembers(string partyId, IReadOnlyList<string> memberIds)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(party.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ValidateMembers(memberIds, party.PartyId, out var members);
            if (status != PartyStatus.Success) return new PartyResult(status);
            var leader = party.LeaderId != null && members.Contains(party.LeaderId) ? party.LeaderId : null;
            var state = new PartyState(party.PartyId, members, leader);
            Publish(state);
            return new PartyResult(PartyStatus.Success, state);
        }

        public PartyResult TryTransferMember(string sourcePartyId, string targetPartyId, string memberId)
        {
            var status = ResolveParty(sourcePartyId, out var source);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ResolveParty(targetPartyId, out var target);
            if (status != PartyStatus.Success) return new PartyResult(status);
            if (source.PartyId == target.PartyId) return new PartyResult(PartyStatus.SameParty);
            status = CheckEditable(source.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(target.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ResolveMember(memberId, out var id);
            if (status != PartyStatus.Success) return new PartyResult(status);
            if (adventurers.TryGetById(id, out var member) && member.IsDead) return new PartyResult(PartyStatus.AdventurerDead);
            if (!Contains(source, id)) return new PartyResult(PartyStatus.MemberNotAssigned);
            if (target.MemberCount >= PartyState.MaximumMembers) return new PartyResult(PartyStatus.PartyCapacityReached);
            if (source.MemberCount <= PartyState.MinimumMembers) return new PartyResult(PartyStatus.InvalidMemberCount);

            // Stage removal FIRST; neither staged list is observable. Publish both states together.
            var sourceMembers = new List<string>(source.MemberIds);
            sourceMembers.Remove(id);
            var targetMembers = new List<string>(target.MemberIds) { id };
            var sourceState = new PartyState(source.PartyId, sourceMembers, source.LeaderId == id ? null : source.LeaderId);
            var targetState = new PartyState(target.PartyId, targetMembers, target.LeaderId);
            var next = new Dictionary<string, PartyState>(parties, StringComparer.Ordinal);
            next[source.PartyId] = sourceState;
            next[target.PartyId] = targetState;
            parties = next;
            return new PartyResult(PartyStatus.Success, targetState, sourceState);
        }

        public PartyResult TrySetLeader(string partyId, string memberId)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(party.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ResolveMember(memberId, out var id);
            if (status != PartyStatus.Success) return new PartyResult(status);
            if (adventurers.TryGetById(id, out var member) && member.IsDead) return new PartyResult(PartyStatus.AdventurerDead);
            if (!Contains(party, id)) return new PartyResult(PartyStatus.MemberNotAssigned);
            var state = new PartyState(party.PartyId, party.MemberIds, id);
            Publish(state);
            return new PartyResult(PartyStatus.Success, state);
        }

        public PartyResult TryClearLeader(string partyId)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = CheckEditable(party.PartyId);
            if (status != PartyStatus.Success) return new PartyResult(status);
            var state = new PartyState(party.PartyId, party.MemberIds);
            Publish(state);
            return new PartyResult(PartyStatus.Success, state);
        }

        public PartyResult ValidateComposition(string partyId)
        {
            var status = ResolveParty(partyId, out var party);
            if (status != PartyStatus.Success) return new PartyResult(status);
            status = ValidateMembers(party.MemberIds, party.PartyId, out _);
            if (status == PartyStatus.UnknownAdventurer) status = PartyStatus.UnresolvedMemberReference;
            if (status == PartyStatus.Success && party.LeaderId != null && !Contains(party, party.LeaderId))
                status = PartyStatus.MemberNotAssigned;
            return new PartyResult(status, status == PartyStatus.Success ? party : null);
        }

        public PartyPanelModel GetPanelModel(string selectedPartyId = null)
        {
            PartyState selected = null;
            var status = selectedPartyId == null ? PartyStatus.Success : ResolveParty(selectedPartyId, out selected);
            var views = new List<PartyPanelModel.PartyView>();
            foreach (var party in GetPartiesSnapshot())
                views.Add(new PartyPanelModel.PartyView(party, CheckEditable(party.PartyId)));
            return new PartyPanelModel(views, adventurers.GetMembersSnapshot(), this, catalog, selected, status);
        }
    }
}

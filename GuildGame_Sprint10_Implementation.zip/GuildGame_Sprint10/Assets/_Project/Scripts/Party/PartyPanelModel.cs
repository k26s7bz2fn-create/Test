using System;
using System.Collections.Generic;

namespace GuildGame
{
    /// <summary>Detached UI snapshot. No manager references escape into the model.</summary>
    public sealed class PartyPanelModel
    {
        public sealed class PartyView
        {
            public PartyState State { get; }
            public PartyStatus EditStatus { get; }
            public bool CanEdit => EditStatus == PartyStatus.Success;
            internal PartyView(PartyState state, PartyStatus editStatus)
            { State = state; EditStatus = editStatus; }
        }

        public sealed class MemberView
        {
            public string Id { get; }
            public string DisplayName { get; }
            public string ClassId { get; }
            public string ClassName { get; }
            public AdventurerRole Roles { get; }
            public string Rank { get; }
            public int Level { get; }
            public string AppearanceId { get; }
            public string AssignedPartyId { get; }
            public bool IsDead { get; }
            public long? RecoveryUntil { get; }
            public bool IsAvailable => !IsDead && AssignedPartyId == null;
            public bool IsSelectedPartyMember { get; }
            public bool IsLeader { get; }
            public bool CanAdd { get; }
            public bool CanRemove { get; }
            public bool CanSetLeader { get; }

            internal MemberView(AdventurerState member, AdventurerCatalog catalog, string owner, PartyState selected, bool editable)
            {
                IsDead=member.IsDead; RecoveryUntil=member.RecoveryUntil;
                Id = member.Id; DisplayName = member.DisplayName; ClassId = member.ClassId;
                ClassName = catalog.TryGetClass(ClassId, out var data) ? data.DisplayName : ClassId;
                Roles = data == null ? AdventurerRole.None : data.Roles;
                Rank = member.Rank; Level = member.Level; AppearanceId = member.AppearanceId;
                AssignedPartyId = owner;
                IsSelectedPartyMember = selected != null && owner == selected.PartyId;
                IsLeader = IsSelectedPartyMember && selected.LeaderId == Id;
                CanAdd = selected != null && editable && IsAvailable && selected.MemberCount < PartyState.MaximumMembers;
                CanRemove = editable && IsSelectedPartyMember && selected.MemberCount > PartyState.MinimumMembers;
                CanSetLeader = editable && IsSelectedPartyMember && !IsDead;
            }
        }

        public IReadOnlyList<PartyView> Parties { get; }
        public IReadOnlyList<MemberView> Members { get; }
        public PartyState SelectedParty { get; }
        public PartyStatus SelectionStatus { get; }
        public PartyStatus CompositionStatus { get; }
        public int GuildMemberCount => Members.Count;
        public int MaximumMembers => PartyState.MaximumMembers;
        public bool CanDissolve { get; }
        public bool CanClearLeader { get; }

        internal PartyPanelModel(List<PartyView> parties, IReadOnlyList<AdventurerState> members,
            PartyManager manager, AdventurerCatalog catalog, PartyState selected, PartyStatus selectionStatus)
        {
            Parties = Array.AsReadOnly(parties.ToArray());
            SelectedParty = selected; SelectionStatus = selectionStatus;
            CompositionStatus = selected == null ? PartyStatus.UnknownParty : manager.ValidateComposition(selected.PartyId).Status;
            var editable = false;
            foreach (var party in parties)
                if (selected != null && party.State.PartyId == selected.PartyId) editable = party.CanEdit;
            CanDissolve = selected != null && editable;
            CanClearLeader = CanDissolve && selected.LeaderId != null;
            var views = new List<MemberView>();
            foreach (var member in members)
                views.Add(new MemberView(member, catalog, manager.GetAssignedPartyId(member.Id), selected, editable));
            Members = Array.AsReadOnly(views.ToArray());
        }
    }
}

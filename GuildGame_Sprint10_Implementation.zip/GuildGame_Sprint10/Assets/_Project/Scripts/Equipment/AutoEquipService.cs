using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class AutoEquipService
    {
        internal EquipmentPreparation Prepare(GuildRuntimeSnapshot before,IReadOnlyList<string> targets,AdventurerManager owner)
        {
            EquipmentConsistency.Validate(before);
            var members=new Dictionary<string,AdventurerState>(StringComparer.Ordinal);foreach(var a in before.Members)members.Add(a.Id,a);
            var ids=new List<string>(new HashSet<string>(targets,StringComparer.Ordinal));ids.Sort(StringComparer.Ordinal);
            foreach(var id in ids)
            {
                if(!members.TryGetValue(id,out var a))throw new EquipmentRejected(EquipmentCode.UnknownAdventurer);
                if(a.IsDead)throw new EquipmentRejected(EquipmentCode.AdventurerDead);
                if(EquipmentConsistency.Locked(before,id))throw new EquipmentRejected(EquipmentCode.MemberQuestLocked);
            }
            var stock=new Dictionary<string,EquipmentInstance>(StringComparer.Ordinal);foreach(var e in before.Storage.Equipment)stock.Add(e.Key,e.Value);
            var changed=new HashSet<string>(StringComparer.Ordinal);bool passChanged;
            do
            {
                passChanged=false;
                foreach(var id in ids)
                {
                    var member=members[id];if(!owner.TryGetClass(member.ClassId,out var cls))throw new EquipmentRejected(EquipmentCode.ClassIncompatible);
                    foreach(var slot in new[]{EquipmentSlot.Weapon,EquipmentSlot.UpperBody,EquipmentSlot.Legs})
                    {
                        var current=member.Equipment.Get(slot);EquipmentInstance best=null;
                        foreach(var candidate in stock.Values)
                        {
                            if(!EquipmentEvaluationRules.Compatible(candidate,member,slot)||EquipmentEvaluationRules.CompareQuality(candidate,current,cls.Roles)<=0)continue;
                            var comparison=best==null?1:EquipmentEvaluationRules.CompareQuality(candidate,best,cls.Roles);
                            if(comparison>0||comparison==0&&EquipmentEvaluationRules.CandidateOrder(candidate,best)<0)best=candidate;
                        }
                        if(best==null)continue;
                        stock.Remove(best.InstanceId);if(current!=null)stock.Add(current.InstanceId,current);
                        member=member.WithLoadout(member.Equipment.With(slot,best),member.Potions);members[id]=member;
                        changed.Add(id);passChanged=true;
                    }
                }
            }while(passChanged);
            var ordered=new List<AdventurerState>();foreach(var a in before.Members)ordered.Add(members[a.Id]);
            var potions=new Dictionary<string,long>(StringComparer.Ordinal);foreach(var p in before.Storage.PotionStacks)potions.Add(p.Key,p.Value);
            var after=before.WithEquipment(ordered,new GuildStorageState(stock,potions));
            EquipmentConsistency.Validate(after);EquipmentConsistency.Conservation(before,after);
            return new EquipmentPreparation{Snapshot=after,Changes=new EquipmentChangeSet(changed,Array.Empty<string>())};
        }
    }
}

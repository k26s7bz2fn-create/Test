using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace GuildGame
{
    public sealed class HealingPotionAssignmentState
    {
        public const string HealingPotionId="item.potion.healing.basic";
        public const int MaximumPerMember=1;
        public static HealingPotionAssignmentState Empty { get; }=new HealingPotionAssignmentState(new Dictionary<string,long>());
        public IReadOnlyDictionary<string,long> Quantities { get; }
        internal HealingPotionAssignmentState(IDictionary<string,long> quantities)
        {Quantities=new ReadOnlyDictionary<string,long>(new Dictionary<string,long>(quantities,System.StringComparer.Ordinal));}
    }
}

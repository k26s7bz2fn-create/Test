using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class HealingPotionAssignmentService
    {
        internal EquipmentPreparation Prepare(GuildRuntimeSnapshot before,PartyState party,long now,AdventurerManager owner)
        {
            EquipmentConsistency.Validate(before);
            var members=new Dictionary<string,AdventurerState>(StringComparer.Ordinal);foreach(var a in before.Members)members.Add(a.Id,a);
            var candidates=new List<AdventurerState>();
            foreach(var id in party.MemberIds)
            {
                if(!members.TryGetValue(id,out var a))throw new EquipmentRejected(EquipmentCode.UnknownAdventurer);
                if(EquipmentConsistency.Locked(before,id))throw new EquipmentRejected(EquipmentCode.MemberQuestLocked);
                if(a.CanDeployAt(now))candidates.Add(a);
            }
            Func<AdventurerState,int> priority=a=>{
                if(!owner.TryGetClass(a.ClassId,out var cls))throw new EquipmentRejected(EquipmentCode.ClassIncompatible);
                return (cls.Roles&AdventurerRole.Healing)!=0?0:a.Id==party.LeaderId?1:2;
            };
            candidates.Sort((a,b)=>{var c=priority(a).CompareTo(priority(b));return c!=0?c:string.CompareOrdinal(a.Id,b.Id);});
            var potions=new Dictionary<string,long>(StringComparer.Ordinal);foreach(var p in before.Storage.PotionStacks)potions.Add(p.Key,p.Value);
            var key=HealingPotionAssignmentState.HealingPotionId;potions.TryGetValue(key,out var count);
            var changed=new List<string>();var missing=new List<string>();
            foreach(var a in candidates)
            {
                a.Potions.Quantities.TryGetValue(key,out var held);if(held>=1)continue;
                if(count==0){missing.Add(a.Id);continue;}
                count--;members[a.Id]=a.WithLoadout(a.Equipment,new HealingPotionAssignmentState(new Dictionary<string,long>{{key,1}}));changed.Add(a.Id);
            }
            if(potions.ContainsKey(key)||changed.Count>0)potions[key]=count;
            var ordered=new List<AdventurerState>();foreach(var a in before.Members)ordered.Add(members[a.Id]);
            var equipment=new Dictionary<string,EquipmentInstance>();foreach(var e in before.Storage.Equipment)equipment.Add(e.Key,e.Value);
            var after=before.WithEquipment(ordered,new GuildStorageState(equipment,potions));
            EquipmentConsistency.Validate(after);EquipmentConsistency.Conservation(before,after);
            return new EquipmentPreparation{Snapshot=after,Changes=new EquipmentChangeSet(changed,missing)};
        }
    }
}

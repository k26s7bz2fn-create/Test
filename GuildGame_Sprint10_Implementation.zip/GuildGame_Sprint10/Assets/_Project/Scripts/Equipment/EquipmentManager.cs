using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class EquipmentManager
    {
        private readonly AdventurerManager owner;
        private bool busy;
        internal Action BeforePublishForTests;
        public EquipmentManager(AdventurerManager owner){this.owner=owner??throw new ArgumentNullException(nameof(owner));}
        internal static List<string> Eligible(GuildRuntimeSnapshot snapshot)
        {
            var ids=new List<string>();foreach(var a in snapshot.Members)if(!a.IsDead&&!EquipmentConsistency.Locked(snapshot,a.Id))ids.Add(a.Id);
            return ids;
        }
        public EquipmentResult TryReevaluateAll()=>Run(before=>new AutoEquipService().Prepare(before,Eligible(before),owner));
        public EquipmentResult TryReevaluate(string memberId)=>Run(before=>{
            if(!PartyManager.NormalizeId(memberId,out var id))throw new EquipmentRejected(EquipmentCode.InvalidAdventurerId);
            return new AutoEquipService().Prepare(before,new[]{id},owner);
        });
        public EquipmentResult TryReturnEquipment(string memberId)=>Return(memberId,true,false);
        public EquipmentResult TryReturnPotions(string memberId)=>Return(memberId,false,true);
        private EquipmentResult Return(string memberId,bool equipment,bool potions)=>Run(before=>{
            if(!PartyManager.NormalizeId(memberId,out var id))throw new EquipmentRejected(EquipmentCode.InvalidAdventurerId);
            if(EquipmentConsistency.Locked(before,id))throw new EquipmentRejected(EquipmentCode.MemberQuestLocked);
            return PrepareReturns(before,new[]{id},equipment,potions,false);
        });
        private EquipmentResult Run(Func<GuildRuntimeSnapshot,EquipmentPreparation> prepare)
        {
            if(busy)return new EquipmentResult(EquipmentCode.Busy);busy=true;
            try
            {
                var before=owner.RuntimeStore.Current;var next=prepare(before);
                if(!next.Changed)return new EquipmentResult(EquipmentCode.NoChange,next.Changes);
                BeforePublishForTests?.Invoke();
                if(!owner.RuntimeStore.TryPublish(before,next.Snapshot))return new EquipmentResult(EquipmentCode.StaleState);
                return new EquipmentResult(EquipmentCode.Applied,next.Changes);
            }
            catch(EquipmentRejected ex){return new EquipmentResult(ex.Code);}
            catch(OverflowException){return new EquipmentResult(EquipmentCode.NumericOverflow);}
            catch(Exception){return new EquipmentResult(EquipmentCode.PreparationFailed);}
            finally{busy=false;}
        }
        // Only the owning QuestManager calls this on staged successful resolve consequences.
        internal static EquipmentPreparation PrepareReturns(GuildRuntimeSnapshot before,IReadOnlyList<string> ids,bool equipment,bool potions,bool deadOnly)
        {
            EquipmentConsistency.Validate(before);
            var targets=new HashSet<string>(ids,StringComparer.Ordinal);
            var stock=new Dictionary<string,EquipmentInstance>();foreach(var e in before.Storage.Equipment)stock.Add(e.Key,e.Value);
            var stacks=new Dictionary<string,long>();foreach(var p in before.Storage.PotionStacks)stacks.Add(p.Key,p.Value);
            var members=new List<AdventurerState>();var changed=new List<string>();
            foreach(var a in before.Members)
            {
                if(!targets.Remove(a.Id)){members.Add(a);continue;}
                var gear=a.Equipment;var assigned=a.Potions;var touched=false;
                if(equipment&&(!deadOnly||a.IsDead)&&gear.Slots.Count>0)
                {foreach(var e in gear.Slots)stock.Add(e.Value.InstanceId,e.Value);gear=EquipmentState.Empty;touched=true;}
                if(potions&&assigned.Quantities.Count>0)
                {
                    foreach(var p in assigned.Quantities){stacks.TryGetValue(p.Key,out var n);stacks[p.Key]=checked(n+p.Value);}
                    assigned=HealingPotionAssignmentState.Empty;touched=true;
                }
                members.Add(touched?a.WithLoadout(gear,assigned):a);if(touched)changed.Add(a.Id);
            }
            if(targets.Count>0)throw new EquipmentRejected(EquipmentCode.UnknownAdventurer);
            var after=changed.Count==0?before:before.WithEquipment(members,new GuildStorageState(stock,stacks));
            EquipmentConsistency.Validate(after);EquipmentConsistency.Conservation(before,after);
            return new EquipmentPreparation{Snapshot=after,Changes=new EquipmentChangeSet(changed,Array.Empty<string>())};
        }
        public EquipmentPanelModel GetPanelModel(string memberId,long asOfTimestamp)
        {
            var snapshot=owner.RuntimeStore.Current;
            if(!PartyManager.NormalizeId(memberId,out var id))return new EquipmentPanelModel(null,asOfTimestamp,false,EquipmentCode.InvalidAdventurerId,snapshot.Storage);
            AdventurerState member=null;foreach(var a in snapshot.Members)if(a.Id==id)member=a;
            if(member==null)return new EquipmentPanelModel(null,asOfTimestamp,false,EquipmentCode.UnknownAdventurer,snapshot.Storage);
            var locked=EquipmentConsistency.Locked(snapshot,id);var code=locked?EquipmentCode.MemberQuestLocked:member.IsDead?EquipmentCode.AdventurerDead:EquipmentCode.NoChange;
            try{EquipmentConsistency.Validate(snapshot);}catch(EquipmentRejected ex){code=ex.Code;}catch(Exception){code=EquipmentCode.PreparationFailed;}
            return new EquipmentPanelModel(member,asOfTimestamp,locked,code,snapshot.Storage);
        }
    }
}

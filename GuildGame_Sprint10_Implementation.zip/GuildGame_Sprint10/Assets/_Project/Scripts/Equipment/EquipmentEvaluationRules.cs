using System;
namespace GuildGame
{
    public static class EquipmentEvaluationRules
    {
        public static bool Compatible(EquipmentInstance item,AdventurerState member,EquipmentSlot slot)
        {
            if(item==null||item.Definition==null||item.Definition.Slot!=slot)return false;
            foreach(var id in item.Definition.AllowedClassIds)if(id==member.ClassId)return true;
            return false;
        }
        // FINAL R9-02: suitability, THEN rarity. No earlier component-wise veto remains.
        public static int CompareQuality(EquipmentInstance a,EquipmentInstance b,AdventurerRole roles)
        {
            var left=a==null?0:a.Definition.EquipmentValues.Score(roles);
            var right=b==null?0:b.Definition.EquipmentValues.Score(roles);
            var c=left.CompareTo(right);if(c!=0)return c;
            return (a==null?-1:(int)a.Definition.Rarity.Value).CompareTo(b==null?-1:(int)b.Definition.Rarity.Value);
        }
        internal static int CandidateOrder(EquipmentInstance a,EquipmentInstance b)
        {var c=string.CompareOrdinal(a.Definition.ItemDefinitionId,b.Definition.ItemDefinitionId);return c!=0?c:string.CompareOrdinal(a.InstanceId,b.InstanceId);}
    }
}

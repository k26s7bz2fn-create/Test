using System;
using System.Collections.Generic;
namespace GuildGame
{
    internal static class EquipmentConsistency
    {
        internal static bool Locked(GuildRuntimeSnapshot state,string id)
        {foreach(var q in state.Quests.Values)if(q.OccupiesActiveSlot)foreach(var member in q.MemberIdsAtStart)if(member==id)return true;return false;}
        internal static void Validate(GuildRuntimeSnapshot state,bool requireValues=true)
        {
            var ids=new HashSet<string>(StringComparer.Ordinal);var definitions=new Dictionary<string,ItemDefinitionData>(StringComparer.Ordinal);
            Action<EquipmentInstance> validate=item=>{
                if(item==null||string.IsNullOrWhiteSpace(item.InstanceId)||string.IsNullOrWhiteSpace(item.SourceOutputId)||item.Definition==null)
                    throw new EquipmentRejected(EquipmentCode.InvalidInstance);
                if(!ids.Add(item.InstanceId))throw new EquipmentRejected(EquipmentCode.DuplicateInstanceLocation);
                var d=item.Definition;
                if(d.StorageMode!=ItemStorageMode.Instance||!d.Slot.HasValue||!d.Rarity.HasValue)throw new EquipmentRejected(EquipmentCode.InvalidInstance);
                if(requireValues&&d.EquipmentValues==null)throw new EquipmentRejected(EquipmentCode.MissingEvaluationData);
                if(definitions.TryGetValue(d.ItemDefinitionId,out var prior)&&!SameDefinition(prior,d))throw new EquipmentRejected(EquipmentCode.DefinitionConflict);
                definitions[d.ItemDefinitionId]=d;
            };
            foreach(var entry in state.Storage.Equipment)
            {if(entry.Value==null||entry.Key!=entry.Value.InstanceId)throw new EquipmentRejected(EquipmentCode.InvalidInstance);validate(entry.Value);}
            var members=new HashSet<string>(StringComparer.Ordinal);
            foreach(var a in state.Members)
            {
                if(!members.Add(a.Id))throw new EquipmentRejected(EquipmentCode.DuplicateInstanceLocation);
                foreach(var entry in a.Equipment.Slots)
                {
                    validate(entry.Value);
                    if(!Enum.IsDefined(typeof(EquipmentSlot),entry.Key)||entry.Value.Definition.Slot!=entry.Key)throw new EquipmentRejected(EquipmentCode.SlotIncompatible);
                    if(!EquipmentEvaluationRules.Compatible(entry.Value,a,entry.Key))throw new EquipmentRejected(EquipmentCode.ClassIncompatible);
                }
                long assigned=0;
                foreach(var p in a.Potions.Quantities)
                {if(p.Key!=HealingPotionAssignmentState.HealingPotionId||p.Value<0)throw new EquipmentRejected(EquipmentCode.InvalidPotionAssignment);assigned=checked(assigned+p.Value);}
                if(assigned>HealingPotionAssignmentState.MaximumPerMember)throw new EquipmentRejected(EquipmentCode.InvalidPotionAssignment);
            }
            foreach(var p in state.Storage.PotionStacks)if(p.Value<0)throw new EquipmentRejected(EquipmentCode.InvalidPotionAssignment);
        }
        private static bool SameDefinition(ItemDefinitionData a,ItemDefinitionData b)
        {
            if(a.ItemType!=b.ItemType||a.Rarity!=b.Rarity||a.Slot!=b.Slot||a.DisplayName!=b.DisplayName)return false;
            if(!new HashSet<string>(a.AllowedClassIds,StringComparer.Ordinal).SetEquals(b.AllowedClassIds))return false;
            var x=a.EquipmentValues;var y=b.EquipmentValues;
            return x==null||y==null?ReferenceEquals(x,y):x.Tank==y.Tank&&x.Damage==y.Damage&&x.Healing==y.Healing&&x.SupportControl==y.SupportControl;
        }
        internal static void Conservation(GuildRuntimeSnapshot before,GuildRuntimeSnapshot after)
        {
            var left=Locations(before);var right=Locations(after);
            if(left.Count!=right.Count)throw new EquipmentRejected(EquipmentCode.InvalidInstance);
            foreach(var pair in left)if(!right.TryGetValue(pair.Key,out var item)||!ReferenceEquals(pair.Value,item))throw new EquipmentRejected(EquipmentCode.InvalidInstance);
            var a=Potions(before);var b=Potions(after);
            var keys=new HashSet<string>(a.Keys,StringComparer.Ordinal);keys.UnionWith(b.Keys);
            foreach(var key in keys){a.TryGetValue(key,out var x);b.TryGetValue(key,out var y);if(x!=y)throw new EquipmentRejected(EquipmentCode.InvalidPotionAssignment);}
        }
        private static Dictionary<string,EquipmentInstance> Locations(GuildRuntimeSnapshot s)
        {
            var result=new Dictionary<string,EquipmentInstance>(StringComparer.Ordinal);
            foreach(var e in s.Storage.Equipment)result.Add(e.Key,e.Value);
            foreach(var a in s.Members)foreach(var e in a.Equipment.Slots)result.Add(e.Value.InstanceId,e.Value);
            return result;
        }
        private static Dictionary<string,decimal> Potions(GuildRuntimeSnapshot s)
        {
            var result=new Dictionary<string,decimal>(StringComparer.Ordinal);
            foreach(var p in s.Storage.PotionStacks)result[p.Key]=p.Value;
            foreach(var a in s.Members)foreach(var p in a.Potions.Quantities){result.TryGetValue(p.Key,out var n);result[p.Key]=n+p.Value;}
            return result;
        }
    }
}

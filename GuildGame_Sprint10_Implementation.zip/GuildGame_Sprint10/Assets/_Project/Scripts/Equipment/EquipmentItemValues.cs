using System;
namespace GuildGame
{
    /// <summary>Selection suitability only. No combat or simulation effects.</summary>
    public sealed class EquipmentItemValues
    {
        public int Tank { get; }
        public int Damage { get; }
        public int Healing { get; }
        public int SupportControl { get; }
        public EquipmentItemValues(int tank,int damage,int healing,int supportControl)
        {if(tank<0||damage<0||healing<0||supportControl<0)throw new ArgumentOutOfRangeException();Tank=tank;Damage=damage;Healing=healing;SupportControl=supportControl;}
        public long Score(AdventurerRole roles) =>
            ((roles&AdventurerRole.Tank)!=0?(long)Tank:0)+((roles&AdventurerRole.Damage)!=0?(long)Damage:0)+
            ((roles&AdventurerRole.Healing)!=0?(long)Healing:0)+((roles&AdventurerRole.SupportControl)!=0?(long)SupportControl:0);
        internal static EquipmentItemValues ApprovedDefault(string id)
        {
            switch(id)
            {
                case "item.weapon.training_sword.common":return new EquipmentItemValues(2,2,0,0);
                case "item.weapon.training_dagger.common":case "item.weapon.training_staff.common":return new EquipmentItemValues(0,2,0,0);
                case "item.weapon.training_mace.common":return new EquipmentItemValues(0,0,2,2);
                case "item.armor.training_upper.common":case "item.armor.training_legs.common":return new EquipmentItemValues(1,1,1,1);
                default:return null;
            }
        }
    }
}

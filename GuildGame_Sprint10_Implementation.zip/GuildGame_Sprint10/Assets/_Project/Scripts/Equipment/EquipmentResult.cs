using System;
using System.Collections.Generic;
namespace GuildGame
{
    public enum EquipmentCode
    {
        Applied,NoChange,InvalidAdventurerId,UnknownAdventurer,AdventurerDead,MemberQuestLocked,
        InvalidInstance,DuplicateInstanceLocation,DefinitionConflict,ClassIncompatible,SlotIncompatible,
        MissingEvaluationData,InvalidPotionAssignment,NumericOverflow,StaleState,Busy,PreparationFailed
    }
    public sealed class EquipmentResult
    {
        public EquipmentCode Status { get; }
        public bool Success=>Status==EquipmentCode.Applied||Status==EquipmentCode.NoChange;
        public EquipmentChangeSet Changes { get; }
        internal EquipmentResult(EquipmentCode code,EquipmentChangeSet changes=null){Status=code;Changes=changes;}
    }
    public sealed class EquipmentChangeSet
    {
        public IReadOnlyList<string> ChangedAdventurerIds { get; }
        public IReadOnlyList<string> PotionShortageMemberIds { get; }
        internal EquipmentChangeSet(IEnumerable<string> changed,IEnumerable<string> missing)
        {
            var ids=new List<string>(changed);ids.Sort(StringComparer.Ordinal);ChangedAdventurerIds=Array.AsReadOnly(ids.ToArray());
            PotionShortageMemberIds=Array.AsReadOnly(new List<string>(missing).ToArray());
        }
    }
    internal sealed class EquipmentRejected : Exception
    {
        internal EquipmentCode Code { get; }
        internal EquipmentRejected(EquipmentCode code):base(code.ToString()){Code=code;}
    }
    internal sealed class EquipmentPreparation
    {
        internal GuildRuntimeSnapshot Snapshot;
        internal EquipmentChangeSet Changes;
        internal bool Changed=>Changes.ChangedAdventurerIds.Count>0;
    }
}

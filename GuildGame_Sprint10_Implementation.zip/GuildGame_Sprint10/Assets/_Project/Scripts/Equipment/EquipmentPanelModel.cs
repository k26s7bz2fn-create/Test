namespace GuildGame
{
    public sealed class EquipmentPanelModel
    {
        public AdventurerState Member { get; }
        public long AsOfTimestamp { get; }
        public bool QuestLocked { get; }
        public EquipmentCode Status { get; }
        public GuildStorageState Storage { get; }
        public bool CanReevaluate=>Member!=null&&!Member.IsDead&&!QuestLocked&&Status==EquipmentCode.NoChange;
        public bool CanReturnEquipment=>Member!=null&&!QuestLocked&&(Status==EquipmentCode.NoChange||Status==EquipmentCode.AdventurerDead);
        public bool CanReturnPotions=>CanReturnEquipment;
        public bool IsInjured=>Member!=null&&Member.IsInjuredAt(AsOfTimestamp);
        internal EquipmentPanelModel(AdventurerState member,long now,bool locked,EquipmentCode status,GuildStorageState storage)
        {Member=member;AsOfTimestamp=now;QuestLocked=locked;Status=status;Storage=storage;}
    }
}

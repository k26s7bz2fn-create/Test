using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace GuildGame
{
    public sealed class EquipmentState
    {
        public static EquipmentState Empty { get; }=new EquipmentState(new Dictionary<EquipmentSlot,EquipmentInstance>());
        public IReadOnlyDictionary<EquipmentSlot,EquipmentInstance> Slots { get; }
        internal EquipmentState(IDictionary<EquipmentSlot,EquipmentInstance> slots)
        {Slots=new ReadOnlyDictionary<EquipmentSlot,EquipmentInstance>(new Dictionary<EquipmentSlot,EquipmentInstance>(slots));}
        public EquipmentInstance Get(EquipmentSlot slot)=>Slots.TryGetValue(slot,out var item)?item:null;
        internal EquipmentState With(EquipmentSlot slot,EquipmentInstance item)
        {
            var copy=new Dictionary<EquipmentSlot,EquipmentInstance>();foreach(var e in Slots)copy.Add(e.Key,e.Value);
            if(item==null)copy.Remove(slot);else copy[slot]=item;
            return new EquipmentState(copy);
        }
    }
}

using System;

namespace GuildGame
{
    public enum GuildHallGestureKind
    {
        None = 0,
        Ui,
        WorldTap,
        WorldDrag
    }

    public sealed class GuildHallInputPolicy
    {
        public float DragThresholdNormalized { get; }

        public GuildHallInputPolicy(float dragThresholdNormalized)
        {
            if (dragThresholdNormalized <= 0f || dragThresholdNormalized >= 1f)
                throw new ArgumentOutOfRangeException(nameof(dragThresholdNormalized));
            DragThresholdNormalized = dragThresholdNormalized;
        }

        public GuildHallGestureKind Classify(bool beganOverUi, bool cancelled, float normalizedDistance)
        {
            if (cancelled) return GuildHallGestureKind.None;
            if (beganOverUi) return GuildHallGestureKind.Ui;
            return normalizedDistance >= DragThresholdNormalized
                ? GuildHallGestureKind.WorldDrag
                : GuildHallGestureKind.WorldTap;
        }
    }
}

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallNavigationController : MonoBehaviour
    {
        [SerializeField] private GuildHallCameraController cameraController;
        [SerializeField] private GuildHallPanelController panelController;
        [SerializeField] private GuildHallInteractionPoint[] interactionPoints = Array.Empty<GuildHallInteractionPoint>();

        private readonly Dictionary<GuildHallDestination, GuildHallInteractionPoint> byDestination = new Dictionary<GuildHallDestination, GuildHallInteractionPoint>();
        private int requestVersion;
        public GuildHallDestination? CurrentDestination { get; private set; }
        public string LastError { get; private set; } = string.Empty;

        public bool Initialize()
        {
            byDestination.Clear(); LastError = string.Empty;
            if (cameraController == null || panelController == null) return Fail("Camera or panel controller missing.");
            if (!panelController.Rebuild()) return Fail("Panel configuration must contain each of the six destinations exactly once.");
            if (interactionPoints == null || interactionPoints.Length != 6) return Fail("Exactly six interaction points are required.");
            for (var i = 0; i < interactionPoints.Length; i++)
            {
                var point = interactionPoints[i];
                if (point == null || !point.IsConfigured) return Fail("Interaction point configuration is invalid.");
                if (!panelController.HasPanel(point.Destination) || byDestination.ContainsKey(point.Destination)) return Fail("Destination registration is invalid.");
                byDestination.Add(point.Destination, point);
            }
            return byDestination.Count == 6;
        }

        public bool NavigateTo(GuildHallDestination destination)
        {
            if (!byDestination.TryGetValue(destination, out var point) || point.CameraAnchor == null || !panelController.HasPanel(destination))
                return Fail("Destination is not configured.");
            if (CurrentDestination == destination && panelController.OpenDestination == destination) return true;

            var version = ++requestVersion;
            panelController.CloseAll();
            cameraController.Focus(point.CameraAnchor, success =>
            {
                if (!success || version != requestVersion) return;
                CurrentDestination = destination;
                panelController.Open(destination);
            });
            return true;
        }

        public void CloseCurrent()
        {
            var version = ++requestVersion;
            panelController.CloseAll();
            CurrentDestination = null;
            cameraController.ReturnToOverview(success => { if (version != requestVersion) return; });
        }

        public bool TryNavigateFromCollider(Collider hitCollider)
        {
            if (hitCollider == null) return false;
            var point = hitCollider.GetComponentInParent<GuildHallInteractionPoint>();
            return point != null && point.InteractionCollider == hitCollider && NavigateTo(point.Destination);
        }

        private bool Fail(string message) { LastError = message; return false; }

        private void OnDisable()
        {
            requestVersion++;
            if (cameraController != null) cameraController.CancelTransition();
        }
    }
}

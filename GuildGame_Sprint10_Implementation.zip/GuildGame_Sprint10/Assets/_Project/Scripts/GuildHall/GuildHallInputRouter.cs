using UnityEngine;
using UnityEngine.EventSystems;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallInputRouter : MonoBehaviour
    {
        [SerializeField] private GuildHallNavigationController navigation;
        [SerializeField] private GuildHallCameraController cameraController;
        [SerializeField] private float dragThresholdNormalized = 0.015f;
        [SerializeField] private LayerMask interactionMask = ~0;

        private GuildHallInputPolicy policy;
        private bool active;
        private bool beganOverUi;
        private Vector2 start;
        private Vector2 previous;
        private float maxDistance;

        private void Awake() => policy = new GuildHallInputPolicy(dragThresholdNormalized);

        public void BeginPointer(Vector2 screenPosition, bool overUi)
        {
            active = true; beganOverUi = overUi; start = previous = screenPosition; maxDistance = 0f;
        }

        public void MovePointer(Vector2 screenPosition)
        {
            if (!active) return;
            var size = new Vector2(Mathf.Max(1f, Screen.width), Mathf.Max(1f, Screen.height));
            var fromStart = new Vector2((screenPosition.x-start.x)/size.x, (screenPosition.y-start.y)/size.y);
            maxDistance = Mathf.Max(maxDistance, fromStart.magnitude);
            if (!beganOverUi && maxDistance >= dragThresholdNormalized && cameraController != null)
            {
                var delta = new Vector2((screenPosition.x-previous.x)/size.x, (screenPosition.y-previous.y)/size.y);
                cameraController.ApplyNormalizedDrag(delta);
            }
            previous = screenPosition;
        }

        public void EndPointer(Vector2 screenPosition, bool cancelled)
        {
            if (!active) return;
            MovePointer(screenPosition);
            var kind = policy.Classify(beganOverUi, cancelled, maxDistance);
            active = false;
            if (kind != GuildHallGestureKind.WorldTap || navigation == null || cameraController == null || cameraController.ControlledCamera == null) return;
            var ray = cameraController.ControlledCamera.ScreenPointToRay(screenPosition);
            if (Physics.Raycast(ray, out var hit, 100f, interactionMask, QueryTriggerInteraction.Ignore))
                navigation.TryNavigateFromCollider(hit.collider);
        }

        public void CancelPointer() => EndPointer(previous, true);

        private void OnApplicationFocus(bool hasFocus) { if (!hasFocus) CancelPointer(); }
        private void OnDisable() { active = false; }
    }
}

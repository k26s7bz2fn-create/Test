using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallInteractionPoint : MonoBehaviour
    {
        [SerializeField] private GuildHallDestination destination;
        [SerializeField] private Transform cameraAnchor;
        [SerializeField] private Collider interactionCollider;

        public GuildHallDestination Destination => destination;
        public Transform CameraAnchor => cameraAnchor;
        public Collider InteractionCollider => interactionCollider;
        public bool IsConfigured => cameraAnchor != null && interactionCollider != null && interactionCollider.enabled;

        public void Configure(GuildHallDestination value, Transform anchor, Collider collider)
        {
            destination = value;
            cameraAnchor = anchor;
            interactionCollider = collider;
        }
    }
}

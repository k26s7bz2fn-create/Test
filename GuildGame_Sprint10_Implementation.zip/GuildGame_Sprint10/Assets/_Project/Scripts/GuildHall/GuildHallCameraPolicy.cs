using System;

namespace GuildGame
{
    public sealed class GuildHallCameraPolicy
    {
        public float MinYaw { get; }
        public float MaxYaw { get; }
        public float MinPitch { get; }
        public float MaxPitch { get; }

        public GuildHallCameraPolicy(float minYaw, float maxYaw, float minPitch, float maxPitch)
        {
            if (minYaw > maxYaw) throw new ArgumentOutOfRangeException(nameof(minYaw));
            if (minPitch > maxPitch) throw new ArgumentOutOfRangeException(nameof(minPitch));
            MinYaw = minYaw;
            MaxYaw = maxYaw;
            MinPitch = minPitch;
            MaxPitch = maxPitch;
        }

        public float ClampYaw(float value) => Math.Max(MinYaw, Math.Min(MaxYaw, value));
        public float ClampPitch(float value) => Math.Max(MinPitch, Math.Min(MaxPitch, value));
    }
}

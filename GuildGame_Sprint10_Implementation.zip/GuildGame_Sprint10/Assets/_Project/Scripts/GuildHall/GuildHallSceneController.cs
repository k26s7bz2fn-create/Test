using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallSceneController : MonoBehaviour
    {
        [SerializeField] private GuildHallNavigationController navigation;
        [SerializeField] private GuildHallCameraController cameraController;
        [SerializeField] private RecruitmentPanelPresenter recruitmentPresenter;
        public bool IsReady { get; private set; }
        public string Error { get; private set; } = string.Empty;

        public void Initialize(RecruitmentManager recruitmentManager)
        {
            Error = string.Empty;
            if (navigation == null || cameraController == null)
            {
                IsReady = false; Error = "Guild hall navigation dependencies are missing."; return;
            }
            if (!navigation.Initialize())
            {
                IsReady = false; Error = navigation.LastError; return;
            }
            cameraController.SnapToOverview();
            if (recruitmentPresenter != null) recruitmentPresenter.Bind(recruitmentManager);
            IsReady = true;
        }
    }
}

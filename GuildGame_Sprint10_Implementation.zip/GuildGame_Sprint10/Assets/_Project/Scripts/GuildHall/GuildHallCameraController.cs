using System;
using System.Collections;
using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallCameraController : MonoBehaviour
    {
        [SerializeField] private Camera controlledCamera;
        [SerializeField] private Transform overviewAnchor;
        [SerializeField] private float transitionDuration = 0.45f;
        [SerializeField] private float minYaw = -35f;
        [SerializeField] private float maxYaw = 35f;
        [SerializeField] private float minPitch = -15f;
        [SerializeField] private float maxPitch = 18f;
        [SerializeField] private float dragSensitivity = 70f;

        private GuildHallCameraPolicy policy;
        private Coroutine transition;
        private int transitionVersion;
        private float yaw;
        private float pitch;

        public GuildHallNavigationState State { get; private set; } = GuildHallNavigationState.Overview;
        public Camera ControlledCamera => controlledCamera;

        private void Awake()
        {
            policy = new GuildHallCameraPolicy(minYaw, maxYaw, minPitch, maxPitch);
            if (controlledCamera == null) controlledCamera = GetComponentInChildren<Camera>();
        }

        public void SnapToOverview()
        {
            CancelTransition();
            if (controlledCamera == null || overviewAnchor == null) return;
            yaw = 0f; pitch = 0f;
            controlledCamera.transform.SetPositionAndRotation(overviewAnchor.position, overviewAnchor.rotation);
            State = GuildHallNavigationState.Overview;
        }

        public void ApplyNormalizedDrag(Vector2 viewportDelta)
        {
            if (State != GuildHallNavigationState.Overview || controlledCamera == null || overviewAnchor == null) return;
            yaw = policy.ClampYaw(yaw + viewportDelta.x * dragSensitivity);
            pitch = policy.ClampPitch(pitch - viewportDelta.y * dragSensitivity);
            controlledCamera.transform.position = overviewAnchor.position;
            controlledCamera.transform.rotation = overviewAnchor.rotation * Quaternion.Euler(pitch, yaw, 0f);
        }

        public void Focus(Transform target, Action<bool> completed)
        {
            if (target == null || controlledCamera == null) { completed?.Invoke(false); return; }
            StartTransition(target.position, target.rotation, GuildHallNavigationState.Focused, completed);
        }

        public void ReturnToOverview(Action<bool> completed)
        {
            if (overviewAnchor == null || controlledCamera == null) { completed?.Invoke(false); return; }
            yaw = 0f; pitch = 0f;
            StartTransition(overviewAnchor.position, overviewAnchor.rotation, GuildHallNavigationState.Overview, completed);
        }

        private void StartTransition(Vector3 position, Quaternion rotation, GuildHallNavigationState endState, Action<bool> completed)
        {
            CancelTransition();
            var version = ++transitionVersion;
            if (transitionDuration <= 0f)
            {
                controlledCamera.transform.SetPositionAndRotation(position, rotation);
                State = endState;
                completed?.Invoke(true);
                return;
            }
            State = GuildHallNavigationState.Transitioning;
            transition = StartCoroutine(TransitionRoutine(version, position, rotation, endState, completed));
        }

        private IEnumerator TransitionRoutine(int version, Vector3 targetPosition, Quaternion targetRotation, GuildHallNavigationState endState, Action<bool> completed)
        {
            var startPosition = controlledCamera.transform.position;
            var startRotation = controlledCamera.transform.rotation;
            var elapsed = 0f;
            while (elapsed < transitionDuration)
            {
                if (version != transitionVersion) yield break;
                elapsed += Time.unscaledDeltaTime;
                var t = Mathf.Clamp01(elapsed / transitionDuration);
                t = t * t * (3f - 2f * t);
                controlledCamera.transform.position = Vector3.Lerp(startPosition, targetPosition, t);
                controlledCamera.transform.rotation = Quaternion.Slerp(startRotation, targetRotation, t);
                yield return null;
            }
            if (version != transitionVersion) yield break;
            controlledCamera.transform.SetPositionAndRotation(targetPosition, targetRotation);
            State = endState;
            transition = null;
            completed?.Invoke(true);
        }

        public void CancelTransition()
        {
            transitionVersion++;
            if (transition != null) StopCoroutine(transition);
            transition = null;
        }

        private void OnDisable()
        {
            CancelTransition();
        }
    }
}

using System;

namespace GuildGame
{
    public readonly struct NormalizedSafeArea
    {
        public float MinX { get; }
        public float MinY { get; }
        public float MaxX { get; }
        public float MaxY { get; }
        public bool IsValid => MinX >= 0f && MinY >= 0f && MaxX <= 1f && MaxY <= 1f && MinX <= MaxX && MinY <= MaxY;

        public NormalizedSafeArea(float minX, float minY, float maxX, float maxY)
        {
            MinX = minX; MinY = minY; MaxX = maxX; MaxY = maxY;
        }
    }

    public static class GuildHallSafeAreaPolicy
    {
        public static bool TryNormalize(float screenWidth, float screenHeight, float x, float y, float width, float height, out NormalizedSafeArea area)
        {
            area = default;
            if (screenWidth <= 0f || screenHeight <= 0f || width < 0f || height < 0f) return false;
            var minX = Clamp01(x / screenWidth);
            var minY = Clamp01(y / screenHeight);
            var maxX = Clamp01((x + width) / screenWidth);
            var maxY = Clamp01((y + height) / screenHeight);
            area = new NormalizedSafeArea(minX, minY, maxX, maxY);
            return area.IsValid;
        }

        private static float Clamp01(float value) => Math.Max(0f, Math.Min(1f, value));
    }
}

namespace GuildGame
{
    public enum GuildHallNavigationState
    {
        Overview = 0,
        Transitioning,
        Focused
    }
}

namespace GuildGame
{
    public enum GuildHallDestination
    {
        Recruitment = 0,
        QuestBoard,
        Storage,
        Forge,
        DungeonPortal,
        Memorial
    }
}

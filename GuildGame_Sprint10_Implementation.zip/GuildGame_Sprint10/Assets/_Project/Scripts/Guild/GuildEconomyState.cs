using System;
namespace GuildGame
{
    public sealed class GuildEconomyState
    {
        public long Gold { get; }
        public GuildEconomyState(long gold)
        {if(gold<0)throw new ArgumentOutOfRangeException(nameof(gold));Gold=gold;}
        internal GuildEconomyState Add(long amount)
        {if(amount<0)throw new ArgumentOutOfRangeException(nameof(amount));return new GuildEconomyState(checked(Gold+amount));}
    }
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
namespace GuildGame.Combat
{
    public sealed class CombatEquipmentReference
    {
        public string DefinitionId {get;} public string InstanceId {get;}
        public CombatEquipmentReference(string definitionId,string instanceId)
        {CombatInput.ValidateId(definitionId);CombatInput.ValidateId(instanceId);DefinitionId=definitionId;InstanceId=instanceId;}
    }
    public abstract class CombatantInput
    {
        public string CombatantId {get;} public string SourceAdventurerId {get;} public CombatProfile Profile {get;}
        public int StartHP {get;} public int StartMana=>Profile.MaxMana;
        public IReadOnlyList<CombatEquipmentReference> Equipment {get;}
        protected CombatantInput(string id,string source,string definition,int hp,CombatEquipmentReference weapon,CombatEquipmentReference upper,CombatEquipmentReference legs)
        {
            CombatInput.ValidateId(id);Profile=CombatRules.Profile(definition);
            if(hp<1||hp>Profile.MaxHP)throw new CombatValidationException(CombatCode.InvalidResources);
            CombatantId=id;SourceAdventurerId=source??"";StartHP=hp;
            Equipment=Array.AsReadOnly(new[]{weapon,upper,legs});
        }
    }
    public sealed class AdventurerCombatant:CombatantInput
    {
        public AdventurerCombatant(string id,string sourceId,string classId,int hp,CombatEquipmentReference weapon=null,CombatEquipmentReference upper=null,CombatEquipmentReference legs=null):base(id,sourceId,classId,hp,weapon,upper,legs)
        {CombatInput.ValidateId(sourceId);if(Profile.Faction!=CombatFaction.Adventurer)throw new CombatValidationException(CombatCode.InvalidInput);}
    }
    public sealed class EnemyCombatant:CombatantInput
    {
        public EnemyCombatant(string id,string definitionId):base(id,"",definitionId,CombatRules.Profile(definitionId).MaxHP,null,null,null)
        {if(Profile.Faction!=CombatFaction.Enemy)throw new CombatValidationException(CombatCode.InvalidInput);}
    }
    public sealed class CombatInput
    {
        public ulong Seed {get;} public IReadOnlyList<CombatantInput> Participants {get;} public string Fingerprint {get;}
        public CombatInput(IEnumerable<CombatantInput> participants,ulong seed)
        {
            if(participants==null)throw new CombatValidationException(CombatCode.InvalidInput);
            var list=new List<CombatantInput>(participants);var ids=new HashSet<string>(StringComparer.Ordinal);var sources=new HashSet<string>(StringComparer.Ordinal);var equipmentIds=new HashSet<string>(StringComparer.Ordinal);int allies=0,enemies=0;
            foreach(var p in list)
            {
                if(p==null)throw new CombatValidationException(CombatCode.InvalidInput);
                if(!ids.Add(p.CombatantId))throw new CombatValidationException(CombatCode.DuplicateId);
                if(p.Profile.Faction==CombatFaction.Adventurer){allies++;if(!sources.Add(p.SourceAdventurerId))throw new CombatValidationException(CombatCode.DuplicateId);}else enemies++;
                for(var slot=0;slot<3;slot++)if(p.Equipment[slot]!=null)
                {
                    var e=p.Equipment[slot];if(!equipmentIds.Add(e.InstanceId))throw new CombatValidationException(CombatCode.InvalidEquipment);
                    string expected=slot==1?"item.armor.training_upper.common":slot==2?"item.armor.training_legs.common":p.Profile.Id=="class.warrior"?"item.weapon.training_sword.common":p.Profile.Id=="class.rogue"?"item.weapon.training_dagger.common":p.Profile.Id=="class.mage"?"item.weapon.training_staff.common":"item.weapon.training_mace.common";
                    if(e.DefinitionId!=expected)throw new CombatValidationException(CombatCode.InvalidEquipment);
                }
            }
            if(allies<1||allies>CombatRules.MaximumPerFaction||enemies<1||enemies>CombatRules.MaximumPerFaction)throw new CombatValidationException(CombatCode.InvalidInput);
            list.Sort((a,b)=>string.CompareOrdinal(a.CombatantId,b.CombatantId));Participants=Array.AsReadOnly(list.ToArray());Seed=seed;
            var fields=new List<string>{CombatRules.InputSchema,CombatRules.RulesVersion,list.Count.ToString(CultureInfo.InvariantCulture)};
            foreach(var p in list)
            {
                fields.Add(p.CombatantId);fields.Add(p.Profile.Faction.ToString());fields.Add(p.SourceAdventurerId);fields.Add(p.Profile.Id);fields.Add(((int)p.Profile.Roles).ToString(CultureInfo.InvariantCulture));fields.Add(p.StartHP.ToString(CultureInfo.InvariantCulture));fields.Add(p.StartMana.ToString(CultureInfo.InvariantCulture));
                foreach(var e in p.Equipment){fields.Add(e?.DefinitionId??"");fields.Add(e?.InstanceId??"");}
            }
            fields.Add(seed.ToString("x16",CultureInfo.InvariantCulture));Fingerprint=CombatRandom.HashHex(fields);
        }
        internal static void ValidateId(string id)
        {if(string.IsNullOrWhiteSpace(id)||id!=id.Trim())throw new CombatValidationException(CombatCode.InvalidInput);}
    }
}

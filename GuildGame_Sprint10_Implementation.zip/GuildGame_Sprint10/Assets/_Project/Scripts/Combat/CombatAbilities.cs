using System;
using System.Collections.Generic;
namespace GuildGame.Combat
{
    public sealed class CombatAbilityDefinition
    {
        public string Id {get;} public int CooldownTicks {get;} public int ManaCost {get;} public int? FixedRawDamage {get;} public CombatStatusKind? Status {get;} public bool IsHeal {get;} public bool IsStabilize {get;}
        internal CombatAbilityDefinition(string id,int cd,int mana=0,int? raw=null,CombatStatusKind? status=null,bool heal=false,bool stabilize=false)
        {Id=id;CooldownTicks=cd;ManaCost=mana;FixedRawDamage=raw;Status=status;IsHeal=heal;IsStabilize=stabilize;}
    }
    public static class CombatAbilities
    {
        private static readonly IReadOnlyDictionary<string,IReadOnlyList<CombatAbilityDefinition>> definitions=Build();
        public static IReadOnlyList<CombatAbilityDefinition> For(string definitionId)=>definitions[definitionId];
        private static IReadOnlyDictionary<string,IReadOnlyList<CombatAbilityDefinition>> Build()
        {
            var d=new Dictionary<string,IReadOnlyList<CombatAbilityDefinition>>(StringComparer.Ordinal);
            d.Add("class.warrior",Array.AsReadOnly(new[]{new CombatAbilityDefinition("combat.warrior.shield_bash",24,status:CombatStatusKind.Stun),new CombatAbilityDefinition("combat.warrior.strike",8)}));
            d.Add("class.rogue",Array.AsReadOnly(new[]{new CombatAbilityDefinition("combat.rogue.bleeding_cut",24,status:CombatStatusKind.Bleed),new CombatAbilityDefinition("combat.rogue.strike",8)}));
            d.Add("class.mage",Array.AsReadOnly(new[]{new CombatAbilityDefinition("combat.mage.burning_bolt",24,6,status:CombatStatusKind.Burn),new CombatAbilityDefinition("combat.mage.bolt",8,4),new CombatAbilityDefinition("combat.mage.staff_strike",8,raw:3)}));
            d.Add("class.priest",Array.AsReadOnly(new[]{new CombatAbilityDefinition("combat.priest.stabilize",16,6,stabilize:true),new CombatAbilityDefinition("combat.priest.heal",8,6,heal:true),new CombatAbilityDefinition("combat.priest.strike",8)}));
            foreach(var p in CombatRules.Profiles.Values)if(p.Faction==CombatFaction.Enemy)
            {
                var list=new List<CombatAbilityDefinition>();
                if(p.Id=="enemy.goblin.ranged")list.Add(new CombatAbilityDefinition("combat.goblin.poison_shot",24,status:CombatStatusKind.Poison));
                if(p.Id=="enemy.goblin.brute")list.Add(new CombatAbilityDefinition("combat.goblin.stunning_blow",24,status:CombatStatusKind.Stun));
                list.Add(new CombatAbilityDefinition("combat.enemy.basic_attack",p.BasicCooldownTicks));d.Add(p.Id,Array.AsReadOnly(list.ToArray()));
            }
            return new System.Collections.ObjectModel.ReadOnlyDictionary<string,IReadOnlyList<CombatAbilityDefinition>>(d);
        }
    }
    internal static class CombatTargeting
    {
        internal static WorkingCombatant Attack(WorkingCombatant actor,List<WorkingCombatant> members)
        {
            var candidates=members.FindAll(x=>x.Life==CombatLife.Alive&&x.Profile.Faction!=actor.Profile.Faction);
            if(candidates.Exists(x=>x.Profile.Front))candidates.RemoveAll(x=>!x.Profile.Front);
            if(candidates.Exists(x=>x.Profile.Faction==CombatFaction.Adventurer&&x.Profile.Front&&(x.Profile.Roles&AdventurerRole.Tank)!=0))candidates.RemoveAll(x=>(x.Profile.Roles&AdventurerRole.Tank)==0);
            var target=candidates.Find(x=>x.Id==actor.TargetId);return target??(candidates.Count==0?null:candidates[0]);
        }
        internal static WorkingCombatant Heal(List<WorkingCombatant> members)
        {
            WorkingCombatant best=null;
            foreach(var x in members)if(x.Profile.Faction==CombatFaction.Adventurer&&x.Life==CombatLife.Alive&&2L*x.HP<=x.Profile.MaxHP)
                if(best==null||(long)x.HP*best.Profile.MaxHP<(long)best.HP*x.Profile.MaxHP)best=x;
            return best;
        }
        internal static WorkingCombatant Stabilize(List<WorkingCombatant> members)
        {WorkingCombatant best=null;foreach(var x in members)if(x.Profile.Faction==CombatFaction.Adventurer&&x.Life==CombatLife.Incapacitated&&(best==null||x.DeathCheckTick.Value<best.DeathCheckTick.Value))best=x;return best;}
    }
    public static class CombatEffects
    {
        public static int Damage(int raw,int defense,bool critical)
        {if(raw<0||defense<0)throw new ArgumentOutOfRangeException();return checked(Math.Max(1,checked(raw-defense))*(critical?CombatRules.CritMultiplier:1));}
        public static int Heal(int hp,int maxHP)=>Math.Min(maxHP,checked(hp+CombatRules.HealAmount));
    }
}

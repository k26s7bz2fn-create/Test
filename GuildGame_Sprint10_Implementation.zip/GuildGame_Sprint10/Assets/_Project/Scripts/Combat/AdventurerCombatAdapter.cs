using System;
using System.Collections.Generic;
namespace GuildGame.Combat
{
    /// <summary>Read-only projection. This does NOT start a guild/dungeon mission or reserve members.</summary>
    public static class AdventurerCombatAdapter
    {
        public static CombatOperationResult TryCreate(AdventurerManager adventurers,PartyState party,QuestActivityRegistry quests,IReadOnlyList<EnemyCombatant> enemies,long asOfTimestamp,ulong seed,out CombatInput input)
        {
            input=null;
            if(adventurers==null||party==null||quests==null||enemies==null||asOfTimestamp<0)return new CombatOperationResult(CombatCode.InvalidInput);
            try
            {
                // Same authoritative roster is read throughout; no replacement or publication occurs.
                var snapshot=adventurers.RuntimeStore.Current;
                var participants=new List<CombatantInput>();
                if(quests.IsPartyCommitted(party.PartyId))return new CombatOperationResult(CombatCode.ParticipantQuestBound);
                if(party.MemberCount<1||party.MemberCount>6)return new CombatOperationResult(CombatCode.InvalidInput);
                var ids=new HashSet<string>(StringComparer.Ordinal);
                foreach(var id in party.MemberIds)
                {
                    if(!ids.Add(id)||!adventurers.TryGetById(id,out var a))return new CombatOperationResult(CombatCode.InvalidInput);
                    if(!a.CanDeployAt(asOfTimestamp))return new CombatOperationResult(CombatCode.ParticipantUnavailable);
                    // Inspect the roster's actual quest root, not only the supplied registry.
                    if(EquipmentConsistency.Locked(snapshot,a.Id)||quests.IsMemberCommitted(a.Id))return new CombatOperationResult(CombatCode.ParticipantQuestBound);
                    if(!adventurers.TryGetClass(a.ClassId,out var cls)||cls.Roles!=CombatRules.Profile(a.ClassId).Roles)return new CombatOperationResult(CombatCode.UnknownDefinition);
                    participants.Add(new AdventurerCombatant(a.Id,a.Id,a.ClassId,CombatRules.Profile(a.ClassId).MaxHP,Ref(a,EquipmentSlot.Weapon),Ref(a,EquipmentSlot.UpperBody),Ref(a,EquipmentSlot.Legs)));
                }
                if(party.LeaderId!=null&&!ids.Contains(party.LeaderId))return new CombatOperationResult(CombatCode.InvalidInput);
                EquipmentConsistency.Validate(snapshot);
                foreach(var e in enemies)participants.Add(e);
                input=new CombatInput(participants,seed);return new CombatOperationResult(CombatCode.Success);
            }
            catch(CombatValidationException ex){return new CombatOperationResult(ex.Code);}
            catch(EquipmentRejected){return new CombatOperationResult(CombatCode.InvalidEquipment);}
            catch(ArgumentException){return new CombatOperationResult(CombatCode.InvalidInput);}
            catch(OverflowException){return new CombatOperationResult(CombatCode.NumericOverflow);}
        }
        private static CombatEquipmentReference Ref(AdventurerState a,EquipmentSlot slot)
        {var e=a.Equipment.Get(slot);return e==null?null:new CombatEquipmentReference(e.Definition.ItemDefinitionId,e.InstanceId);}
    }
}

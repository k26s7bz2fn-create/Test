using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace GuildGame.Combat
{
    public static class CombatRandom
    {
        public static byte[] Encode(IEnumerable<string> fields)
        {
            using(var stream=new MemoryStream())
            {
                foreach(var field in fields)
                {
                    var bytes=new UTF8Encoding(false,true).GetBytes(field);var n=checked((uint)bytes.Length);
                    stream.WriteByte((byte)(n>>24));stream.WriteByte((byte)(n>>16));stream.WriteByte((byte)(n>>8));stream.WriteByte((byte)n);stream.Write(bytes,0,bytes.Length);
                }
                return stream.ToArray();
            }
        }
        private static byte[] Digest(IEnumerable<string> fields){using(var sha=SHA256.Create())return sha.ComputeHash(Encode(fields));}
        public static string HashHex(IEnumerable<string> fields)
        {var b=Digest(fields);var s=new StringBuilder(64);foreach(var x in b)s.Append(x.ToString("x2",CultureInfo.InvariantCulture));return s.ToString();}
        public static uint Draw(CombatInput input,int tick,string actor,ulong sequence,string purpose)
        {
            if(purpose!="critical"&&purpose!="death.normal"&&purpose!="death.collapse")throw new ArgumentException("Unknown RNG purpose");
            var b=Digest(new[]{CombatRules.RngVersion,CombatRules.RulesVersion,input.Seed.ToString("x16",CultureInfo.InvariantCulture),input.Fingerprint,tick.ToString(CultureInfo.InvariantCulture),actor,sequence.ToString(CultureInfo.InvariantCulture),purpose});
            return ((uint)b[0]<<24)|((uint)b[1]<<16)|((uint)b[2]<<8)|b[3];
        }
        public static bool Pass(uint draw,int basisPoints)
        {if(basisPoints<0||basisPoints>10000)throw new ArgumentOutOfRangeException(nameof(basisPoints));return (ulong)draw*10000UL<(ulong)basisPoints*4294967296UL;}
    }
}

using System;
namespace GuildGame.Combat
{
    public sealed class CombatTimeController
    {
        private readonly CombatSession session;private long pendingMilliseconds;
        public int Speed {get;private set;}=1;
        public long PendingMilliseconds=>pendingMilliseconds;
        public CombatTimeController(CombatSession session){this.session=session??throw new ArgumentNullException(nameof(session));}
        private bool Terminal=>session.State.Phase==CombatPhase.Completed||session.State.Phase==CombatPhase.TechnicalAbort;
        public CombatOperationResult SetSpeed(int speed)
        {
            if(Terminal)return new CombatOperationResult(CombatCode.Terminal);
            if(speed!=0&&speed!=1&&speed!=2&&speed!=4)return new CombatOperationResult(CombatCode.InvalidSpeed);
            Speed=speed;return new CombatOperationResult(CombatCode.Success);
        }
        public CombatOperationResult Advance(long elapsedMilliseconds)
        {
            if(elapsedMilliseconds<0)return new CombatOperationResult(CombatCode.InvalidTime);
            if(Terminal)return new CombatOperationResult(CombatCode.Terminal);
            if(Speed==0)return new CombatOperationResult(CombatCode.Success);
            long next;try{next=checked(pendingMilliseconds+checked(elapsedMilliseconds*Speed));}catch(OverflowException){return new CombatOperationResult(CombatCode.NumericOverflow);}
            pendingMilliseconds=next;var processed=0;
            while(pendingMilliseconds>=CombatRules.TickMilliseconds&&!Terminal)
            {
                var result=session.Step();
                if(result.ProcessedTicks>0){pendingMilliseconds-=CombatRules.TickMilliseconds;processed++;}
                if(!result.Success)return new CombatOperationResult(result.Code,processed);
            }
            return new CombatOperationResult(CombatCode.Success,processed);
        }
        public CombatPanelModel GetPanelModel()=>new CombatPanelModel(session.State,Speed);
    }
}

using System;
using System.Collections.Generic;
namespace GuildGame.Combat
{
    /// <summary>Single-owner, scene-independent combat. A complete tick is the publication unit.</summary>
    public sealed class CombatSession
    {
        public CombatInput Input {get;}
        public CombatState State {get;private set;}
        internal Action BeforePublishForTests;
        private bool processing;
        public CombatSession(CombatInput input)
        {
            Input=input??throw new ArgumentNullException(nameof(input));var members=new List<WorkingCombatant>();foreach(var p in input.Participants)members.Add(new WorkingCombatant(p));
            State=new CombatState(0,CombatPhase.Running,0,null,members,Array.Empty<CombatEvent>());
        }
        public static CombatOperationResult TryCreate(IEnumerable<CombatantInput> participants,ulong seed,out CombatSession session)
        {
            session=null;try{session=new CombatSession(new CombatInput(participants,seed));return new CombatOperationResult(CombatCode.Success);}
            catch(CombatValidationException ex){return new CombatOperationResult(ex.Code);}
            catch(ArgumentException){return new CombatOperationResult(CombatCode.InvalidInput);}
        }
        public CombatOperationResult Step()
        {
            if(processing)return new CombatOperationResult(CombatCode.TickFailed);
            if(State.Phase==CombatPhase.Completed||State.Phase==CombatPhase.TechnicalAbort)return new CombatOperationResult(CombatCode.Terminal);
            processing=true;
            try
            {
                var before=State;var next=Advance(before);
                BeforePublishForTests?.Invoke();
                State=next;
                return new CombatOperationResult(next.Phase==CombatPhase.TechnicalAbort?CombatCode.SimulationLimitReached:CombatCode.Success,1);
            }
            catch(OverflowException){return new CombatOperationResult(CombatCode.NumericOverflow);}
            catch(Exception){return new CombatOperationResult(CombatCode.TickFailed);}
            finally{processing=false;}
        }
        private CombatState Advance(CombatState before)
        {
            var tick=checked(before.TickIndex+1);var phase=before.Phase;var sequence=before.ActionSequence;var victory=before.VictoryTick;
            var members=new List<WorkingCombatant>();foreach(var m in before.Participants)members.Add(new WorkingCombatant(m));
            var events=new List<CombatEvent>();
            if(phase==CombatPhase.Running)ProcessStatuses(members,tick,events);
            foreach(var m in members)if(m.Life==CombatLife.Alive&&(phase==CombatPhase.Running||m.IsPriest))m.Mana=Math.Min(m.Profile.MaxMana,checked(m.Mana+CombatRules.ManaPerTick));
            var offset=(tick-1)%members.Count;
            for(var i=0;i<members.Count;i++)
            {
                var actor=members[(offset+i)%members.Count];
                if(actor.Life!=CombatLife.Alive||actor.NextActionTick>tick||actor.Statuses.ContainsKey(CombatStatusKind.Stun))continue;
                if(phase==CombatPhase.Aftermath&&!actor.IsPriest)continue;
                Act(actor,members,tick,phase,events,ref sequence);
            }
            // Collapse is checked BEFORE ordinary due deadlines, even if both occur this tick.
            var anyAlive=members.Exists(x=>x.Profile.Faction==CombatFaction.Adventurer&&x.Life==CombatLife.Alive);
            if(!anyAlive)
            {
                foreach(var m in members)if(m.Profile.Faction==CombatFaction.Adventurer&&m.Life==CombatLife.Incapacitated)Death(m,tick,true,events,ref sequence);
                return Complete(tick,sequence,victory,members,events,CombatOutcome.Defeat);
            }
            foreach(var m in members)if(m.Profile.Faction==CombatFaction.Adventurer&&m.Life==CombatLife.Incapacitated&&m.DeathCheckTick.Value<=tick)Death(m,tick,false,events,ref sequence);
            if(!members.Exists(x=>x.Profile.Faction==CombatFaction.Enemy&&x.Life==CombatLife.Alive))
            {
                if(!victory.HasValue)victory=tick;
                if(!members.Exists(x=>x.Profile.Faction==CombatFaction.Adventurer&&x.Life==CombatLife.Incapacitated))return Complete(tick,sequence,victory,members,events,CombatOutcome.Victory);
                phase=CombatPhase.Aftermath;
                foreach(var m in members)m.Statuses.Clear();
            }
            // Tick 480 has already run in full. A provisional victory wins over this limit.
            if(phase==CombatPhase.Running&&tick>=CombatRules.LimitTicks)phase=CombatPhase.TechnicalAbort;
            return new CombatState(tick,phase,sequence,victory,members,events);
        }
        private CombatState Complete(int tick,ulong sequence,int? victory,List<WorkingCombatant> members,List<CombatEvent> events,CombatOutcome outcome)
        {
            foreach(var m in members)m.Statuses.Clear();
            var result=new CombatResult(Input,outcome,tick,victory,members);
            return new CombatState(tick,CombatPhase.Completed,sequence,victory,members,events,result);
        }
        private uint Draw(int tick,string actor,string purpose,ref ulong sequence)
        {var draw=CombatRandom.Draw(Input,tick,actor,sequence,purpose);sequence=checked(sequence+1UL);return draw;}
        private void Death(WorkingCombatant m,int tick,bool collapse,List<CombatEvent> events,ref ulong sequence)
        {
            var dead=CombatRandom.Pass(Draw(tick,m.Id,collapse?"death.collapse":"death.normal",ref sequence),collapse?CombatRules.CollapseDeathBasisPoints:CombatRules.NormalDeathBasisPoints);
            m.DeathCheckTick=null;m.Statuses.Clear();
            if(dead){m.Life=CombatLife.Dead;m.HP=0;m.DeathTick=tick;}
            else{m.Life=CombatLife.Stabilized;m.HP=1;m.Stabilization=StabilizationReason.UnaidedSurvival;}
            events.Add(new CombatEvent(tick,m.Id,m.Id,collapse?"death.collapse":"death.normal",dead?1:0));
        }
        internal static void Damage(WorkingCombatant target,int amount,int tick)
        {
            target.HP=Math.Max(0,target.HP-amount);
            if(target.HP!=0||target.Life!=CombatLife.Alive)return;
            target.Statuses.Clear();
            if(target.Profile.Faction==CombatFaction.Enemy){target.Life=CombatLife.Dead;target.DeathTick=tick;}
            else{target.Life=CombatLife.Incapacitated;target.WasIncapacitated=true;target.DeathCheckTick=checked(tick+CombatRules.IncapacitatedTicks);}
        }
        internal static void ApplyStatus(WorkingCombatant target,CombatStatusKind kind,string source,int tick)
        {
            if(target.Life!=CombatLife.Alive)return;
            var duration=kind==CombatStatusKind.Stun?CombatRules.StunDuration:CombatRules.DotDuration;
            if(target.Statuses.TryGetValue(kind,out var old))target.Statuses[kind]=new CombatStatusState(kind,old.SourceCombatantId,checked(tick+duration),old.NextPulseTick);
            else target.Statuses[kind]=new CombatStatusState(kind,source,checked(tick+duration),kind==CombatStatusKind.Stun?0:checked(tick+CombatRules.DotInterval));
            target.History.Add(kind);
        }
        internal static void ProcessStatuses(List<WorkingCombatant> members,int tick,List<CombatEvent> events)
        {
            // Members retain canonical ordinal order. Enum order is explicitly Poison, Bleed, Burn, Stun.
            foreach(var m in members)
            {
                foreach(var kind in new[]{CombatStatusKind.Poison,CombatStatusKind.Bleed,CombatStatusKind.Burn})
                {
                    if(m.Life!=CombatLife.Alive)break;
                    if(m.Statuses.TryGetValue(kind,out var s)&&s.NextPulseTick<=tick&&tick<=s.ExpiresAtTick)
                    {
                        var amount=CombatRules.StatusDamage(kind);Damage(m,amount,tick);events.Add(new CombatEvent(tick,s.SourceCombatantId,m.Id,"status."+kind,amount));
                        if(m.Life==CombatLife.Alive)m.Statuses[kind]=new CombatStatusState(kind,s.SourceCombatantId,s.ExpiresAtTick,checked(s.NextPulseTick+CombatRules.DotInterval));
                    }
                }
            }
            foreach(var m in members)
            {var remove=new List<CombatStatusKind>();foreach(var s in m.Statuses)if(s.Value.ExpiresAtTick<=tick)remove.Add(s.Key);foreach(var k in remove)m.Statuses.Remove(k);}
        }
        private void Act(WorkingCombatant actor,List<WorkingCombatant> members,int tick,CombatPhase phase,List<CombatEvent> events,ref ulong sequence)
        {
            WorkingCombatant attack=null;
            if(phase==CombatPhase.Running){attack=CombatTargeting.Attack(actor,members);actor.TargetId=attack?.Id;}
            foreach(var ability in CombatAbilities.For(actor.Profile.Id))
            {
                if(phase==CombatPhase.Aftermath&&!ability.IsStabilize)continue;
                actor.Ready.TryGetValue(ability.Id,out var ready);
                if(ready>tick||actor.Mana<ability.ManaCost)continue;
                var target=ability.IsStabilize?CombatTargeting.Stabilize(members):ability.IsHeal?CombatTargeting.Heal(members):attack;
                if(target==null||ability.Status.HasValue&&target.Statuses.ContainsKey(ability.Status.Value))continue;
                if(ability.IsStabilize)
                {
                    target.Life=CombatLife.Stabilized;target.HP=1;target.DeathCheckTick=null;target.Stabilization=StabilizationReason.Healer;target.Statuses.Clear();
                    events.Add(new CombatEvent(tick,actor.Id,target.Id,ability.Id,1));
                }
                else if(ability.IsHeal)
                {var hp=target.HP;target.HP=CombatEffects.Heal(hp,target.Profile.MaxHP);events.Add(new CombatEvent(tick,actor.Id,target.Id,ability.Id,target.HP-hp));}
                else
                {
                    var critical=CombatRandom.Pass(Draw(tick,actor.Id,"critical",ref sequence),actor.Profile.CritBasisPoints);
                    var amount=CombatEffects.Damage(ability.FixedRawDamage??actor.Profile.Attack,target.Profile.Defense,critical);
                    Damage(target,amount,tick);events.Add(new CombatEvent(tick,actor.Id,target.Id,ability.Id,amount,critical));
                    if(ability.Status.HasValue)ApplyStatus(target,ability.Status.Value,actor.Id,tick);
                }
                actor.Mana-=ability.ManaCost;actor.Ready[ability.Id]=checked(tick+ability.CooldownTicks);actor.NextActionTick=checked(tick+CombatRules.ActionLockTicks);return;
            }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace GuildGame.Combat
{
    public enum CombatFaction { Adventurer, Enemy }
    public enum CombatLife { Alive, Incapacitated, Stabilized, Dead }
    public enum CombatPhase { Running, Aftermath, Completed, TechnicalAbort }
    public enum CombatOutcome { Victory, Defeat }
    public enum CombatStatusKind { Poison, Bleed, Burn, Stun }
    public enum StabilizationReason { None, Healer, UnaidedSurvival }
    public enum CombatCode { Success, InvalidInput, UnknownDefinition, DuplicateId, InvalidResources, InvalidTime, InvalidSpeed, Terminal, NumericOverflow, TickFailed, SimulationLimitReached, ParticipantUnavailable, ParticipantQuestBound, InvalidEquipment }

    // Frozen, approved v1 configuration. Changing balance requires a new rules version.
    public static class CombatRules
    {
        public const string RulesVersion="combat.rules.v1", RngVersion="combat.rng.sha256.v1", InputSchema="combat.input.v1";
        public const int TickMilliseconds=250, ActionLockTicks=4, LimitTicks=480, MaximumPerFaction=6;
        public const int ManaPerTick=1, HealAmount=12, CritMultiplier=2, NormalDeathBasisPoints=2500, CollapseDeathBasisPoints=6000;
        public const int IncapacitatedTicks=32, RecoverySeconds=120, DotDuration=16, DotInterval=4, StunDuration=4;
        private static readonly IReadOnlyDictionary<string,CombatProfile> profiles=BuildProfiles();
        public static IReadOnlyDictionary<string,CombatProfile> Profiles=>profiles;
        private static IReadOnlyDictionary<string,CombatProfile> BuildProfiles()
        {
            var p=new Dictionary<string,CombatProfile>(StringComparer.Ordinal);
            Add(p,"class.warrior",CombatFaction.Adventurer,AdventurerRole.Tank|AdventurerRole.Damage,60,0,8,3,1000,true,8);
            Add(p,"class.rogue",CombatFaction.Adventurer,AdventurerRole.Damage,40,0,10,1,2000,true,8);
            Add(p,"class.mage",CombatFaction.Adventurer,AdventurerRole.Damage|AdventurerRole.SupportControl,36,24,9,1,1000,false,8);
            Add(p,"class.priest",CombatFaction.Adventurer,AdventurerRole.Healing|AdventurerRole.SupportControl,42,24,5,1,1000,false,8);
            Add(p,"enemy.goblin.melee",CombatFaction.Enemy,AdventurerRole.None,24,0,6,1,1000,true,8);
            Add(p,"enemy.goblin.ranged",CombatFaction.Enemy,AdventurerRole.None,18,0,5,0,1000,false,8);
            Add(p,"enemy.goblin.brute",CombatFaction.Enemy,AdventurerRole.None,48,0,9,2,1000,true,12);
            Add(p,"enemy.goblin.boss",CombatFaction.Enemy,AdventurerRole.None,96,0,11,3,1000,true,12);
            return new ReadOnlyDictionary<string,CombatProfile>(p);
        }
        private static void Add(Dictionary<string,CombatProfile> p,string id,CombatFaction faction,AdventurerRole roles,int hp,int mana,int attack,int defense,int crit,bool front,int cd)
        {p.Add(id,new CombatProfile(id,faction,roles,hp,mana,attack,defense,crit,front,cd));}
        public static CombatProfile Profile(string id)
        {if(id==null||!profiles.TryGetValue(id,out var p))throw new CombatValidationException(CombatCode.UnknownDefinition);return p;}
        public static int StatusDamage(CombatStatusKind kind)=>kind==CombatStatusKind.Poison?1:kind==CombatStatusKind.Stun?0:2;
    }
    public sealed class CombatProfile
    {
        public string Id {get;} public CombatFaction Faction {get;} public AdventurerRole Roles {get;}
        public int MaxHP {get;} public int MaxMana {get;} public int Attack {get;} public int Defense {get;} public int CritBasisPoints {get;} public bool Front {get;} public int BasicCooldownTicks {get;}
        internal CombatProfile(string id,CombatFaction f,AdventurerRole r,int hp,int mana,int a,int d,int c,bool front,int cd)
        {Id=id;Faction=f;Roles=r;MaxHP=hp;MaxMana=mana;Attack=a;Defense=d;CritBasisPoints=c;Front=front;BasicCooldownTicks=cd;}
    }
    public sealed class CombatValidationException:Exception
    {public CombatCode Code {get;} internal CombatValidationException(CombatCode code):base(code.ToString()){Code=code;}}
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace GuildGame.Combat
{
    public sealed class CombatStatusState
    {
        public CombatStatusKind Kind {get;} public string SourceCombatantId {get;} public int ExpiresAtTick {get;} public int NextPulseTick {get;}
        internal CombatStatusState(CombatStatusKind kind,string source,int expires,int pulse){Kind=kind;SourceCombatantId=source;ExpiresAtTick=expires;NextPulseTick=pulse;}
    }
    public sealed class CombatantState
    {
        public CombatantInput Input {get;} public string Id=>Input.CombatantId;
        public int HP {get;} public int Mana {get;} public CombatLife Life {get;} public bool WasIncapacitated {get;}
        public StabilizationReason Stabilization {get;} public int? DeathTick {get;} public int? DeathCheckTick {get;}
        public string TargetId {get;} public int NextActionTick {get;}
        public IReadOnlyDictionary<string,int> ReadyAtTicks {get;} public IReadOnlyDictionary<CombatStatusKind,CombatStatusState> Statuses {get;}
        public IReadOnlyList<CombatStatusKind> EncounteredStatuses {get;}
        internal CombatantState(WorkingCombatant w)
        {
            Input=w.Input;HP=w.HP;Mana=w.Mana;Life=w.Life;WasIncapacitated=w.WasIncapacitated;Stabilization=w.Stabilization;DeathTick=w.DeathTick;DeathCheckTick=w.DeathCheckTick;TargetId=w.TargetId;NextActionTick=w.NextActionTick;
            ReadyAtTicks=new ReadOnlyDictionary<string,int>(new Dictionary<string,int>(w.Ready,StringComparer.Ordinal));Statuses=new ReadOnlyDictionary<CombatStatusKind,CombatStatusState>(new Dictionary<CombatStatusKind,CombatStatusState>(w.Statuses));
            var history=new List<CombatStatusKind>(w.History);history.Sort();EncounteredStatuses=Array.AsReadOnly(history.ToArray());
        }
    }
    internal sealed class WorkingCombatant
    {
        internal CombatantInput Input;internal int HP,Mana,NextActionTick;internal CombatLife Life;internal bool WasIncapacitated;
        internal StabilizationReason Stabilization;internal int? DeathTick,DeathCheckTick;internal string TargetId;
        internal Dictionary<string,int> Ready=new Dictionary<string,int>(StringComparer.Ordinal);
        internal Dictionary<CombatStatusKind,CombatStatusState> Statuses=new Dictionary<CombatStatusKind,CombatStatusState>();internal HashSet<CombatStatusKind> History=new HashSet<CombatStatusKind>();
        internal WorkingCombatant(CombatantInput input){Input=input;HP=input.StartHP;Mana=input.StartMana;Life=CombatLife.Alive;}
        internal WorkingCombatant(CombatantState s)
        {Input=s.Input;HP=s.HP;Mana=s.Mana;Life=s.Life;WasIncapacitated=s.WasIncapacitated;Stabilization=s.Stabilization;DeathTick=s.DeathTick;DeathCheckTick=s.DeathCheckTick;TargetId=s.TargetId;NextActionTick=s.NextActionTick;foreach(var p in s.ReadyAtTicks)Ready.Add(p.Key,p.Value);foreach(var p in s.Statuses)Statuses.Add(p.Key,p.Value);History=new HashSet<CombatStatusKind>(s.EncounteredStatuses);}
        internal string Id=>Input.CombatantId;
        internal CombatProfile Profile=>Input.Profile;
        internal bool IsPriest=>Profile.Id=="class.priest";
    }
    public sealed class CombatEvent
    {
        public int Tick {get;} public string ActorId {get;} public string TargetId {get;} public string Kind {get;} public int Amount {get;} public bool Critical {get;}
        internal CombatEvent(int tick,string actor,string target,string kind,int amount=0,bool critical=false){Tick=tick;ActorId=actor;TargetId=target;Kind=kind;Amount=amount;Critical=critical;}
    }
    public sealed class CombatState
    {
        public int TickIndex {get;} public long ElapsedMilliseconds=>(long)TickIndex*CombatRules.TickMilliseconds;
        public CombatPhase Phase {get;} public ulong ActionSequence {get;} public int? VictoryTick {get;}
        public IReadOnlyList<CombatantState> Participants {get;} public IReadOnlyList<CombatEvent> LastTickEvents {get;} public CombatResult Result {get;}
        internal CombatState(int tick,CombatPhase phase,ulong sequence,int? victory,IEnumerable<WorkingCombatant> members,IEnumerable<CombatEvent> events,CombatResult result=null)
        {TickIndex=tick;Phase=phase;ActionSequence=sequence;VictoryTick=victory;var list=new List<CombatantState>();foreach(var w in members)list.Add(new CombatantState(w));Participants=Array.AsReadOnly(list.ToArray());LastTickEvents=Array.AsReadOnly(new List<CombatEvent>(events).ToArray());Result=result;}
    }
}

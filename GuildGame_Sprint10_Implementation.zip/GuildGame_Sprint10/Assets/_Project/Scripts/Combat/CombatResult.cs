using System;
using System.Collections.Generic;
namespace GuildGame.Combat
{
    public sealed class CombatMemberResult
    {
        public CombatantState FinalState {get;} public int RecoveryDurationSeconds {get;}
        internal CombatMemberResult(CombatantState state){FinalState=state;RecoveryDurationSeconds=state.Input.Profile.Faction==CombatFaction.Adventurer&&state.WasIncapacitated&&state.Life!=CombatLife.Dead?CombatRules.RecoverySeconds:0;}
    }
    public sealed class CombatResult
    {
        public string ResultId {get;} public string InputFingerprint {get;} public ulong Seed {get;} public string RulesVersion=>CombatRules.RulesVersion;
        public CombatOutcome Outcome {get;} public bool IsWipe {get;} public long EngagementDurationMilliseconds {get;} public long AftermathDurationMilliseconds {get;}
        public long TotalDurationMilliseconds=>EngagementDurationMilliseconds+AftermathDurationMilliseconds;
        public IReadOnlyList<CombatMemberResult> Participants {get;}
        public IReadOnlyList<string> ConsumedPotions {get;}=Array.AsReadOnly(Array.Empty<string>());
        internal CombatResult(CombatInput input,CombatOutcome outcome,int tick,int? victory,List<WorkingCombatant> members)
        {
            InputFingerprint=input.Fingerprint;Seed=input.Seed;Outcome=outcome;
            ResultId=CombatRandom.HashHex(new[]{"combat.result.v1",input.Fingerprint});
            EngagementDurationMilliseconds=(long)(victory??tick)*CombatRules.TickMilliseconds;AftermathDurationMilliseconds=(long)(tick-(victory??tick))*CombatRules.TickMilliseconds;
            IsWipe=true;var list=new List<CombatMemberResult>();foreach(var m in members){if(m.Profile.Faction==CombatFaction.Adventurer&&m.Life!=CombatLife.Dead)IsWipe=false;list.Add(new CombatMemberResult(new CombatantState(m)));}Participants=Array.AsReadOnly(list.ToArray());
        }
    }
    public sealed class CombatOperationResult
    {
        public CombatCode Code {get;} public bool Success=>Code==CombatCode.Success;public int ProcessedTicks {get;}
        internal CombatOperationResult(CombatCode code,int processed=0){Code=code;ProcessedTicks=processed;}
    }
    public sealed class CombatPanelModel
    {
        public CombatState State {get;} public int Speed {get;} public bool CanAdvance=>State.Phase==CombatPhase.Running||State.Phase==CombatPhase.Aftermath;
        internal CombatPanelModel(CombatState state,int speed){State=state;Speed=speed;}
    }
}

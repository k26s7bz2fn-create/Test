using System;

namespace GuildGame
{
    public sealed class RecruitmentCandidate
    {
        public string CandidateId { get; }
        public string SessionId { get; }
        public AdventurerState AdventurerData { get; }

        public RecruitmentCandidate(string candidateId, string sessionId, AdventurerState adventurerData)
        {
            if (!Guid.TryParse(candidateId, out var candidateGuid) || candidateGuid == Guid.Empty)
                throw new ArgumentException("Candidate id must be a non-empty GUID.", nameof(candidateId));
            if (string.IsNullOrWhiteSpace(sessionId))
                throw new ArgumentException("Session id is required.", nameof(sessionId));
            AdventurerData = adventurerData ?? throw new ArgumentNullException(nameof(adventurerData));
            var normalizedCandidateId = candidateGuid.ToString("D");
            if (!string.Equals(normalizedCandidateId, AdventurerData.Id, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Candidate id must match the adventurer id.", nameof(candidateId));

            CandidateId = normalizedCandidateId;
            SessionId = sessionId.Trim();
        }
    }
}

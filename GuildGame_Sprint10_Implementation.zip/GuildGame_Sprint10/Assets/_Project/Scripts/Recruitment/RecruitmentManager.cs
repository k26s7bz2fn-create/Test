using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class RecruitmentManager
    {
        private readonly AdventurerManager adventurerManager;
        private readonly IStartCandidateGenerator candidateGenerator;
        private RecruitmentSession session;
        private RecruitmentResult lastResult = RecruitmentResult.Ok();

        public RecruitmentManager(AdventurerManager adventurerManager, IStartCandidateGenerator candidateGenerator)
        {
            this.adventurerManager = adventurerManager ?? throw new ArgumentNullException(nameof(adventurerManager));
            this.candidateGenerator = candidateGenerator ?? throw new ArgumentNullException(nameof(candidateGenerator));
        }

        public RecruitmentSession Session => session;

        public RecruitmentResult Initialize(string sessionId, int seed)
        {
            if (string.IsNullOrWhiteSpace(sessionId))
                return Set(new RecruitmentResult(RecruitmentStatus.InvalidCandidateData, "Session id is required."));
            if (session != null)
            {
                lastResult = RecruitmentResult.Ok(session.CommittedAdventurerIds);
                return lastResult;
            }

            var created = new RecruitmentSession(sessionId, seed);
            var generated = candidateGenerator.Generate(created.SessionId, created.Seed, out var candidates);
            if (!generated.Success)
            {
                lastResult = generated;
                return generated;
            }
            if (candidates == null || candidates.Count != StartCandidateGenerator.CandidateCount)
            {
                lastResult = new RecruitmentResult(RecruitmentStatus.InvalidCandidateCount);
                return lastResult;
            }

            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < candidates.Count; i++)
            {
                if (candidates[i] == null || !string.Equals(candidates[i].SessionId, created.SessionId, StringComparison.Ordinal) || candidates[i].AdventurerData == null)
                {
                    lastResult = new RecruitmentResult(RecruitmentStatus.InvalidCandidateData);
                    return lastResult;
                }
                if (!ids.Add(candidates[i].CandidateId))
                {
                    lastResult = new RecruitmentResult(RecruitmentStatus.DuplicateCandidateId);
                    return lastResult;
                }
            }

            created.PublishCandidates(candidates);
            session = created;
            lastResult = RecruitmentResult.Ok();
            return lastResult;
        }

        public RecruitmentResult SelectCandidate(string candidateId)
        {
            var ready = ValidateEditableSession();
            if (ready != null) return Set(ready);
            if (!session.ContainsCandidate(candidateId)) return Set(new RecruitmentResult(RecruitmentStatus.InvalidCandidateId));
            if (session.IsSelected(candidateId)) return Set(new RecruitmentResult(RecruitmentStatus.CandidateAlreadySelected));
            if (session.SelectedCount >= 3) return Set(new RecruitmentResult(RecruitmentStatus.SelectionLimitReached));
            session.Select(candidateId);
            return Set(RecruitmentResult.Ok());
        }

        public RecruitmentResult DeselectCandidate(string candidateId)
        {
            var ready = ValidateEditableSession();
            if (ready != null) return Set(ready);
            if (!session.ContainsCandidate(candidateId)) return Set(new RecruitmentResult(RecruitmentStatus.InvalidCandidateId));
            if (!session.IsSelected(candidateId)) return Set(new RecruitmentResult(RecruitmentStatus.CandidateNotSelected));
            session.Deselect(candidateId);
            return Set(RecruitmentResult.Ok());
        }

        public RecruitmentResult ConfirmSelection()
        {
            var ready = ValidateEditableSession();
            if (ready != null) return Set(ready);
            if (!session.IsSelectionComplete) return Set(new RecruitmentResult(RecruitmentStatus.InvalidSelectionCount));
            if (adventurerManager.Count > AdventurerManager.Capacity - 3)
                return Set(new RecruitmentResult(RecruitmentStatus.GuildCapacityExceeded));

            var states = new AdventurerState[3];
            for (var i = 0; i < session.SelectedCandidateIds.Count; i++)
            {
                var candidate = session.GetCandidate(session.SelectedCandidateIds[i]);
                if (candidate?.AdventurerData == null) return Set(new RecruitmentResult(RecruitmentStatus.InvalidCandidateData));
                states[i] = candidate.AdventurerData;
            }

            var add = adventurerManager.TryAddBatch(states);
            if (!add.Success)
            {
                var status = add.Status == AdventurerStatus.CapacityReached
                    ? RecruitmentStatus.GuildCapacityExceeded
                    : RecruitmentStatus.CommitFailed;
                return Set(new RecruitmentResult(status, add.Message));
            }

            var ids = new string[states.Length];
            for (var i = 0; i < states.Length; i++) ids[i] = states[i].Id;
            session.MarkCommitted(ids);
            return Set(RecruitmentResult.Ok(Array.AsReadOnly(ids)));
        }

        public RecruitmentPanelModel GetPanelModel()
        {
            if (session == null) return null;
            return new RecruitmentPanelModel(session, adventurerManager, lastResult);
        }

        private RecruitmentResult ValidateEditableSession()
        {
            if (session == null || session.State == RecruitmentState.Created)
                return new RecruitmentResult(RecruitmentStatus.SessionNotReady);
            if (session.State == RecruitmentState.Committed)
                return new RecruitmentResult(RecruitmentStatus.SessionAlreadyCommitted);
            return null;
        }

        private RecruitmentResult Set(RecruitmentResult result)
        {
            lastResult = result;
            return result;
        }
    }
}

namespace GuildGame
{
    public enum RecruitmentState
    {
        Created = 0,
        Selecting,
        Committed
    }
}

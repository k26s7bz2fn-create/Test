using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class RecruitmentSession
    {
        private readonly List<RecruitmentCandidate> candidates = new List<RecruitmentCandidate>(5);
        private readonly List<string> selectedCandidateIds = new List<string>(3);
        private readonly List<string> committedAdventurerIds = new List<string>(3);

        public string SessionId { get; }
        public int Seed { get; }
        public RecruitmentState State { get; private set; }
        public IReadOnlyList<RecruitmentCandidate> Candidates => Array.AsReadOnly(candidates.ToArray());
        public IReadOnlyList<string> SelectedCandidateIds => Array.AsReadOnly(selectedCandidateIds.ToArray());
        public IReadOnlyList<string> CommittedAdventurerIds => Array.AsReadOnly(committedAdventurerIds.ToArray());
        public int SelectedCount => selectedCandidateIds.Count;
        public bool IsSelectionComplete => selectedCandidateIds.Count == 3;

        public RecruitmentSession(string sessionId, int seed)
        {
            if (string.IsNullOrWhiteSpace(sessionId)) throw new ArgumentException("Session id is required.", nameof(sessionId));
            SessionId = sessionId.Trim();
            Seed = seed;
            State = RecruitmentState.Created;
        }

        internal void PublishCandidates(IReadOnlyList<RecruitmentCandidate> generated)
        {
            candidates.Clear();
            for (var i = 0; i < generated.Count; i++) candidates.Add(generated[i]);
            selectedCandidateIds.Clear();
            State = RecruitmentState.Selecting;
        }

        internal bool ContainsCandidate(string candidateId)
        {
            for (var i = 0; i < candidates.Count; i++)
                if (string.Equals(candidates[i].CandidateId, candidateId, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        internal bool IsSelected(string candidateId)
        {
            for (var i = 0; i < selectedCandidateIds.Count; i++)
                if (string.Equals(selectedCandidateIds[i], candidateId, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        internal void Select(string candidateId) => selectedCandidateIds.Add(candidateId);

        internal void Deselect(string candidateId)
        {
            for (var i = 0; i < selectedCandidateIds.Count; i++)
            {
                if (!string.Equals(selectedCandidateIds[i], candidateId, StringComparison.OrdinalIgnoreCase)) continue;
                selectedCandidateIds.RemoveAt(i);
                return;
            }
        }

        internal RecruitmentCandidate GetCandidate(string candidateId)
        {
            for (var i = 0; i < candidates.Count; i++)
                if (string.Equals(candidates[i].CandidateId, candidateId, StringComparison.OrdinalIgnoreCase)) return candidates[i];
            return null;
        }

        internal void MarkCommitted(IReadOnlyList<string> adventurerIds)
        {
            committedAdventurerIds.Clear();
            for (var i = 0; i < adventurerIds.Count; i++) committedAdventurerIds.Add(adventurerIds[i]);
            State = RecruitmentState.Committed;
        }
    }
}

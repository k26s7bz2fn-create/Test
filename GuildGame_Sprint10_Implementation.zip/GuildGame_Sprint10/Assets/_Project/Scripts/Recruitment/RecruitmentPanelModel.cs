using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class RecruitmentPanelModel
    {
        public sealed class CandidateView
        {
            public string CandidateId { get; }
            public string DisplayName { get; }
            public string ClassId { get; }
            public string Rank { get; }
            public int Level { get; }
            public string AppearanceId { get; }
            public bool IsSelected { get; }

            internal CandidateView(RecruitmentCandidate candidate, bool selected)
            {
                CandidateId = candidate.CandidateId;
                DisplayName = candidate.AdventurerData.DisplayName;
                ClassId = candidate.AdventurerData.ClassId;
                Rank = candidate.AdventurerData.Rank;
                Level = candidate.AdventurerData.Level;
                AppearanceId = candidate.AdventurerData.AppearanceId;
                IsSelected = selected;
            }
        }

        public string SessionId { get; }
        public RecruitmentState State { get; }
        public IReadOnlyList<CandidateView> Candidates { get; }
        public int SelectedCount { get; }
        public int RequiredSelectionCount => 3;
        public int GuildMemberCount { get; }
        public int GuildCapacity => AdventurerManager.Capacity;
        public bool CanSelect => State == RecruitmentState.Selecting && SelectedCount < 3;
        public bool CanDeselect => State == RecruitmentState.Selecting && SelectedCount > 0;
        public bool CanCommit { get; }
        public RecruitmentStatus LastStatus { get; }
        public string LastMessage { get; }

        internal RecruitmentPanelModel(RecruitmentSession session, AdventurerManager manager, RecruitmentResult lastResult)
        {
            SessionId = session.SessionId;
            State = session.State;
            SelectedCount = session.SelectedCount;
            GuildMemberCount = manager.Count;
            CanCommit = State == RecruitmentState.Selecting && session.IsSelectionComplete && manager.Count <= AdventurerManager.Capacity - 3;
            LastStatus = lastResult?.Status ?? RecruitmentStatus.Success;
            LastMessage = lastResult?.Message ?? string.Empty;

            var views = new CandidateView[session.Candidates.Count];
            for (var i = 0; i < session.Candidates.Count; i++)
            {
                var candidate = session.Candidates[i];
                views[i] = new CandidateView(candidate, session.IsSelected(candidate.CandidateId));
            }
            Candidates = Array.AsReadOnly(views);
        }
    }
}

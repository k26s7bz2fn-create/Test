using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace GuildGame
{
    public interface IStartCandidateGenerator
    {
        RecruitmentResult Generate(string sessionId, int seed, out IReadOnlyList<RecruitmentCandidate> candidates);
    }

    public sealed class StartCandidateGenerator : IStartCandidateGenerator
    {
        public const int CandidateCount = 5;
        private readonly AdventurerCatalog catalog;

        public StartCandidateGenerator(AdventurerCatalog catalog)
        {
            this.catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
        }

        public RecruitmentResult Generate(string sessionId, int seed, out IReadOnlyList<RecruitmentCandidate> candidates)
        {
            candidates = Array.Empty<RecruitmentCandidate>();
            if (string.IsNullOrWhiteSpace(sessionId))
                return new RecruitmentResult(RecruitmentStatus.InvalidCandidateData, "Session id is required.");
            var validationStatus = ValidateCanonicalClasses(out var front, out var healer, out var damage);
            if (validationStatus != RecruitmentStatus.Success)
                return new RecruitmentResult(validationStatus, validationStatus == RecruitmentStatus.InvalidClassDefinition
                    ? "Canonical class definitions are invalid."
                    : "Canonical role coverage is unavailable.");

            var random = new RandomGenerator(seed);
            var requested = new string[CandidateCount];
            requested[0] = front.Id;
            requested[1] = healer.Id;
            requested[2] = damage.Id;
            for (var i = 3; i < CandidateCount; i++)
            {
                var index = random.NextIndex(catalog.Classes.Count);
                requested[i] = catalog.Classes[index].Id;
            }

            var result = new RecruitmentCandidate[CandidateCount];
            var seenCandidateIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < CandidateCount; i++)
            {
                var position = i;
                var generator = new AdventurerGenerator(catalog, random, () => CandidateGuid(sessionId.Trim(), position));
                var generated = generator.Generate(requested[i]);
                if (!generated.Success || generated.State == null || generated.State.Rank != AdventurerState.InitialRank || generated.State.Level != AdventurerState.InitialLevel)
                    return new RecruitmentResult(RecruitmentStatus.InvalidCandidateData, "Generated adventurer violates the F1 contract.");

                var candidateId = generated.State.Id;
                if (!seenCandidateIds.Add(candidateId))
                    return new RecruitmentResult(RecruitmentStatus.DuplicateCandidateId, "Generated candidate id is duplicated.");
                result[i] = new RecruitmentCandidate(candidateId, sessionId, generated.State);
            }

            if (result.Length != CandidateCount)
                return new RecruitmentResult(RecruitmentStatus.InvalidCandidateCount);

            candidates = Array.AsReadOnly(result);
            return RecruitmentResult.Ok();
        }

        private RecruitmentStatus ValidateCanonicalClasses(out AdventurerCatalog.ClassData front, out AdventurerCatalog.ClassData healer, out AdventurerCatalog.ClassData damage)
        {
            front = null;
            healer = null;
            damage = null;
            if (catalog.Classes == null || catalog.Classes.Count != 4) return RecruitmentStatus.InvalidClassDefinition;

            var canonical = new HashSet<string>(StringComparer.Ordinal)
            {
                "class.warrior", "class.rogue", "class.mage", "class.priest"
            };
            for (var i = 0; i < catalog.Classes.Count; i++)
            {
                var data = catalog.Classes[i];
                if (data == null || !canonical.Remove(data.Id)) return RecruitmentStatus.InvalidClassDefinition;
                if (front == null && (data.Roles & AdventurerRole.Tank) != 0) front = data;
                if (healer == null && (data.Roles & AdventurerRole.Healing) != 0) healer = data;
            }
            if (canonical.Count != 0) return RecruitmentStatus.InvalidClassDefinition;
            if (front == null || healer == null) return RecruitmentStatus.InsufficientRoleCoverage;

            for (var i = 0; i < catalog.Classes.Count; i++)
            {
                var data = catalog.Classes[i];
                if (ReferenceEquals(data, front) || ReferenceEquals(data, healer)) continue;
                if ((data.Roles & AdventurerRole.Damage) != 0)
                {
                    damage = data;
                    break;
                }
            }
            return damage == null ? RecruitmentStatus.InsufficientRoleCoverage : RecruitmentStatus.Success;
        }

        private static string CandidateGuid(string sessionId, int position)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(sessionId + "|candidate|" + position));
                var guidBytes = new byte[16];
                Array.Copy(bytes, guidBytes, guidBytes.Length);
                return new Guid(guidBytes).ToString("D");
            }
        }
    }
}

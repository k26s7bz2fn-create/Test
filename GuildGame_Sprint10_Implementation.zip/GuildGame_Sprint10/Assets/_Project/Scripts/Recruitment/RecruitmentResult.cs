using System;
using System.Collections.Generic;

namespace GuildGame
{
    public enum RecruitmentStatus
    {
        Success = 0,
        InvalidCandidateCount,
        InvalidSelectionCount,
        SelectionLimitReached,
        DuplicateCandidateId,
        CandidateAlreadySelected,
        InvalidCandidateId,
        CandidateNotSelected,
        SessionNotReady,
        SessionAlreadyCommitted,
        GuildCapacityExceeded,
        InvalidClassDefinition,
        InvalidCandidateData,
        InsufficientRoleCoverage,
        CommitFailed
    }

    public sealed class RecruitmentResult
    {
        public RecruitmentStatus Status { get; }
        public string Message { get; }
        public IReadOnlyList<string> AdventurerIds { get; }
        public bool Success => Status == RecruitmentStatus.Success;

        public RecruitmentResult(RecruitmentStatus status, string message = null, IReadOnlyList<string> adventurerIds = null)
        {
            Status = status;
            Message = message ?? string.Empty;
            AdventurerIds = adventurerIds ?? Array.Empty<string>();
        }

        public static RecruitmentResult Ok(IReadOnlyList<string> adventurerIds = null) =>
            new RecruitmentResult(RecruitmentStatus.Success, adventurerIds: adventurerIds);
    }
}

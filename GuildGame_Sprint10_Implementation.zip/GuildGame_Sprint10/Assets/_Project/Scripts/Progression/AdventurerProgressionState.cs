using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace GuildGame
{
    public sealed class AdventurerProgressionState
    {
        public long TotalAppliedXp { get; }
        public int Level { get; }
        public int GrantedSkillPoints { get; }
        public IReadOnlyDictionary<string,int> SkillAllocations { get; }
        public static AdventurerProgressionState Initial { get; } = new AdventurerProgressionState(0,1,new Dictionary<string,int>());
        internal AdventurerProgressionState(long xp,int level,IDictionary<string,int> skills)
        {
            TotalAppliedXp=xp;Level=level;GrantedSkillPoints=checked((level-1)*ProgressionRules.PointsPerLevel);
            SkillAllocations=new ReadOnlyDictionary<string,int>(new Dictionary<string,int>(skills,System.StringComparer.Ordinal));
        }
    }
}

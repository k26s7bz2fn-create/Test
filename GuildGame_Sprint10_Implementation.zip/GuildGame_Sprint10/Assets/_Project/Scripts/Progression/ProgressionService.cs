using System;
namespace GuildGame
{
    public sealed class ProgressionChange
    {
        public string AdventurerId { get; }
        public string XpOutputId { get; }
        public long ResultXp { get; }
        public long AppliedXp { get; }
        public long CapOverflow => ResultXp-AppliedXp;
        public AdventurerProgressionState Before { get; }
        public AdventurerProgressionState After { get; }
        public int GrantedPoints => After.GrantedSkillPoints-Before.GrantedSkillPoints;
        internal ProgressionChange(string id,string output,long resultXp,long applied,AdventurerProgressionState before,AdventurerProgressionState after)
        {AdventurerId=id;XpOutputId=output;ResultXp=resultXp;AppliedXp=applied;Before=before;After=after;}
    }
    public sealed class ProgressionService
    {
        private readonly ProgressionRules rules=new ProgressionRules();
        private readonly ClassSkillAllocationRules skills=new ClassSkillAllocationRules();
        public ProgressionChange Prepare(AdventurerState member,long xp,string outputId)
        {
            if(member==null || xp<0 || string.IsNullOrWhiteSpace(outputId)) throw new ArgumentException("Invalid progression input.");
            var before=member.Progression;
            if(before.Level!=rules.LevelAt(before.TotalAppliedXp) || before.GrantedSkillPoints!=(before.Level-1)*ProgressionRules.PointsPerLevel)
                throw new ArgumentException("Invalid progression state.");
            var expected=skills.Allocate(member.ClassId,before.Level);
            if(expected.Count!=before.SkillAllocations.Count) throw new ArgumentException("Invalid prior skills.");
            foreach(var entry in expected)
                if(!before.SkillAllocations.TryGetValue(entry.Key,out var rank) || rank!=entry.Value) throw new ArgumentException("Invalid prior skills.");
            // Bound before addition: even a valid Int64.MaxValue input cannot wrap or create E-rank XP.
            var applied=Math.Min(xp,rules.Cap-before.TotalAppliedXp);
            var total=checked(before.TotalAppliedXp+applied);var level=rules.LevelAt(total);
            var after=new AdventurerProgressionState(total,level,skills.Allocate(member.ClassId,level));
            return new ProgressionChange(member.Id,outputId,xp,applied,before,after);
        }
    }
}

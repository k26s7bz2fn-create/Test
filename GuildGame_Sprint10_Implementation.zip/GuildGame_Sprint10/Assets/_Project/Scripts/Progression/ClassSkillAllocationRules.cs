using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class SkillDefinition
    {
        public string Id { get; }
        public string DisplayName { get; }
        public int MaximumRank => 3;
        internal SkillDefinition(string id,string name){Id=id;DisplayName=name;}
    }
    public sealed class ClassSkillAllocationRules
    {
        public string Version => "s8.skills.v1";
        private readonly Dictionary<string,IReadOnlyList<SkillDefinition>> catalogs = new Dictionary<string,IReadOnlyList<SkillDefinition>>(StringComparer.Ordinal)
        {
            {"class.warrior", Array.AsReadOnly(new SkillDefinition[]{new SkillDefinition("skill.warrior.steadfastness","Standfestigkeit"),new SkillDefinition("skill.warrior.weapon_training","Waffentraining"),new SkillDefinition("skill.warrior.endurance","Ausdauer"),new SkillDefinition("skill.warrior.guard","Deckung"),new SkillDefinition("skill.warrior.precision","Präzision"),new SkillDefinition("skill.warrior.armor_training","Rüstungstraining"),new SkillDefinition("skill.warrior.resilience","Widerstandskraft"),new SkillDefinition("skill.warrior.striking_power","Schlagkraft"),new SkillDefinition("skill.warrior.discipline","Disziplin")})},
            {"class.rogue", Array.AsReadOnly(new SkillDefinition[]{new SkillDefinition("skill.rogue.weapon_training","Waffentraining"),new SkillDefinition("skill.rogue.precision","Präzision"),new SkillDefinition("skill.rogue.agility","Beweglichkeit"),new SkillDefinition("skill.rogue.timing","Timing"),new SkillDefinition("skill.rogue.dexterity","Geschicklichkeit"),new SkillDefinition("skill.rogue.focus","Konzentration"),new SkillDefinition("skill.rogue.weak_point_study","Schwachstellenkunde"),new SkillDefinition("skill.rogue.coordination","Koordination"),new SkillDefinition("skill.rogue.attack_discipline","Angriffsdisziplin")})},
            {"class.mage", Array.AsReadOnly(new SkillDefinition[]{new SkillDefinition("skill.mage.spell_training","Zaubertraining"),new SkillDefinition("skill.mage.focus","Konzentration"),new SkillDefinition("skill.mage.spell_precision","Zauberpräzision"),new SkillDefinition("skill.mage.channeling","Kanalisierung"),new SkillDefinition("skill.mage.control","Zauberkontrolle"),new SkillDefinition("skill.mage.arcane_study","Arkane Studien"),new SkillDefinition("skill.mage.spell_power","Zauberkraft"),new SkillDefinition("skill.mage.composure","Besonnenheit"),new SkillDefinition("skill.mage.casting_discipline","Zauberdisziplin")})},
            {"class.priest", Array.AsReadOnly(new SkillDefinition[]{new SkillDefinition("skill.priest.healing_study","Heilkunde"),new SkillDefinition("skill.priest.focus","Konzentration"),new SkillDefinition("skill.priest.support_training","Unterstützungstraining"),new SkillDefinition("skill.priest.care","Fürsorge"),new SkillDefinition("skill.priest.composure","Besonnenheit"),new SkillDefinition("skill.priest.healing_precision","Heilpräzision"),new SkillDefinition("skill.priest.healing_power","Heilkraft"),new SkillDefinition("skill.priest.vigilance","Wachsamkeit"),new SkillDefinition("skill.priest.support_discipline","Unterstützungsdisziplin")})}
        };
        public bool TryGetSkills(string classId,out IReadOnlyList<SkillDefinition> skills)
        {skills=null;return classId!=null && catalogs.TryGetValue(classId,out skills);}
        internal Dictionary<string,int> Allocate(string classId,int level)
        {
            if(level<1 || level>10 || !TryGetSkills(classId,out var skills)) throw new ArgumentException("Invalid class/level allocation.");
            var result=new Dictionary<string,int>(StringComparer.Ordinal);
            for(var point=0;point<(level-1)*ProgressionRules.PointsPerLevel;point++)
            {
                var skill=skills[point%skills.Count];result.TryGetValue(skill.Id,out var rank);
                if(rank>=skill.MaximumRank) throw new ArgumentException("Skill rank limit.");
                result[skill.Id]=rank+1;
            }
            return result;
        }
    }
}

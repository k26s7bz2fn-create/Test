using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class ProgressionRules
    {
        public const int MinimumLevel = 1, MaximumLevel = 10, PointsPerLevel = 3;
        public string Version => "s8.progression.v1";
        public IReadOnlyList<long> Thresholds { get; } = Array.AsReadOnly(new long[]{0,30,70,120,180,250,330,420,520,630});
        public long Cap => Thresholds[MaximumLevel-1];
        public int LevelAt(long xp)
        {
            if(xp<0 || xp>Cap) throw new ArgumentOutOfRangeException(nameof(xp));
            var level=1;
            while(level<MaximumLevel && xp>=Thresholds[level]) level++;
            return level;
        }
    }
}

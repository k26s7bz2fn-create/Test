using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallNavigationBar : MonoBehaviour
    {
        [SerializeField] private GuildHallNavigationController navigation;

        public void OpenRecruitment() => Navigate(GuildHallDestination.Recruitment);
        public void OpenQuestBoard() => Navigate(GuildHallDestination.QuestBoard);
        public void OpenStorage() => Navigate(GuildHallDestination.Storage);
        public void OpenForge() => Navigate(GuildHallDestination.Forge);
        public void OpenDungeonPortal() => Navigate(GuildHallDestination.DungeonPortal);
        public void OpenMemorial() => Navigate(GuildHallDestination.Memorial);
        public void CloseCurrent() { if (navigation != null) navigation.CloseCurrent(); }
        private void Navigate(GuildHallDestination destination) { if (navigation != null) navigation.NavigateTo(destination); }
    }
}

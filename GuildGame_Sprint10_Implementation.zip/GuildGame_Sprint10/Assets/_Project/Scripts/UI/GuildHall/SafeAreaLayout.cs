using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class SafeAreaLayout : MonoBehaviour
    {
        [SerializeField] private RectTransform target;
        private Rect lastSafeArea;
        private int lastWidth = -1;
        private int lastHeight = -1;

        private void Awake() { if (target == null) target = transform as RectTransform; ApplyIfChanged(true); }
        private void Update() => ApplyIfChanged(false);

        public bool ApplyIfChanged(bool force)
        {
            var safe = Screen.safeArea;
            if (!force && safe == lastSafeArea && Screen.width == lastWidth && Screen.height == lastHeight) return false;
            if (target == null || !GuildHallSafeAreaPolicy.TryNormalize(Screen.width, Screen.height, safe.x, safe.y, safe.width, safe.height, out var normalized)) return false;
            target.anchorMin = new Vector2(normalized.MinX, normalized.MinY);
            target.anchorMax = new Vector2(normalized.MaxX, normalized.MaxY);
            target.offsetMin = Vector2.zero;
            target.offsetMax = Vector2.zero;
            lastSafeArea = safe; lastWidth = Screen.width; lastHeight = Screen.height;
            return true;
        }
    }
}

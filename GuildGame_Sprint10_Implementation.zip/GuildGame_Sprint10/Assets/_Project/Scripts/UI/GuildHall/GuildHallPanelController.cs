using System;
using System.Collections.Generic;
using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class GuildHallPanelController : MonoBehaviour
    {
        [Serializable]
        private sealed class Entry
        {
            public GuildHallDestination destination;
            public GameObject panel;
        }

        [SerializeField] private Entry[] panels = Array.Empty<Entry>();
        private readonly Dictionary<GuildHallDestination, GameObject> byDestination = new Dictionary<GuildHallDestination, GameObject>();
        public GuildHallDestination? OpenDestination { get; private set; }

        private void Awake()
        {
            Rebuild();
            CloseAll();
        }

        public bool Rebuild()
        {
            byDestination.Clear();
            if (panels == null) return false;
            for (var i = 0; i < panels.Length; i++)
            {
                var entry = panels[i];
                if (entry == null || entry.panel == null || byDestination.ContainsKey(entry.destination)) return false;
                byDestination.Add(entry.destination, entry.panel);
            }
            return byDestination.Count == 6;
        }

        public bool HasPanel(GuildHallDestination destination) => byDestination.ContainsKey(destination);

        public bool Open(GuildHallDestination destination)
        {
            if (!byDestination.TryGetValue(destination, out var selected)) return false;
            foreach (var item in byDestination) item.Value.SetActive(ReferenceEquals(item.Value, selected));
            OpenDestination = destination;
            return true;
        }

        public void CloseAll()
        {
            foreach (var item in byDestination) if (item.Value != null) item.Value.SetActive(false);
            OpenDestination = null;
        }
    }
}

using UnityEngine;

namespace GuildGame
{
    [DisallowMultipleComponent]
    public sealed class RecruitmentPanelPresenter : MonoBehaviour
    {
        private RecruitmentManager recruitmentManager;
        public RecruitmentPanelModel Model { get; private set; }
        public string Error { get; private set; } = string.Empty;

        public void Bind(RecruitmentManager manager)
        {
            recruitmentManager = manager;
            Refresh();
        }

        public void Refresh()
        {
            Model = recruitmentManager?.GetPanelModel();
            Error = recruitmentManager == null ? "Recruitment system is not initialized." : string.Empty;
        }

        public RecruitmentResult SelectCandidate(string candidateId)
        {
            if (recruitmentManager == null) return Missing();
            var result = recruitmentManager.SelectCandidate(candidateId); Refresh(); return result;
        }

        public RecruitmentResult DeselectCandidate(string candidateId)
        {
            if (recruitmentManager == null) return Missing();
            var result = recruitmentManager.DeselectCandidate(candidateId); Refresh(); return result;
        }

        public RecruitmentResult ConfirmSelection()
        {
            if (recruitmentManager == null) return Missing();
            var result = recruitmentManager.ConfirmSelection(); Refresh(); return result;
        }

        private RecruitmentResult Missing()
        {
            Error = "Recruitment system is not initialized.";
            return new RecruitmentResult(RecruitmentStatus.SessionNotReady, Error);
        }
    }
}

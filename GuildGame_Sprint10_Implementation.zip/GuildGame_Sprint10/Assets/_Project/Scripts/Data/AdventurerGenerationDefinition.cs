using System;
using System.Collections.Generic;
using UnityEngine;

namespace GuildGame
{
    [CreateAssetMenu(menuName = "Guild Game/Adventurers/Generation Definition", fileName = "Generation_")]
    public sealed class AdventurerGenerationDefinition : ScriptableObject
    {
        public const string RequiredId = "generation.adventurer.placeholder.v01";
        private static readonly string[] CanonicalClassIds =
        {
            "class.warrior", "class.rogue", "class.mage", "class.priest"
        };

        [SerializeField] private string id;
        [SerializeField] private string displayName;
        [SerializeField] private AdventurerClassDefinition[] classes;
        [SerializeField] private string[] names;
        [SerializeField] private string[] appearanceIds;

        public string Id => id;
        public string DisplayName => displayName;

        public bool TryBuildCatalog(out AdventurerCatalog catalog, out string error)
        {
            catalog = null;
            if (!string.Equals((id ?? string.Empty).Trim(), RequiredId, StringComparison.Ordinal))
            {
                error = "Generation definition id is invalid.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(displayName))
            {
                error = "Generation display name is required.";
                return false;
            }
            if (classes == null || classes.Length != CanonicalClassIds.Length)
            {
                error = "Exactly four class definitions are required.";
                return false;
            }

            var byId = new Dictionary<string, AdventurerClassDefinition>(StringComparer.Ordinal);
            foreach (var definition in classes)
            {
                if (definition == null || !definition.TryValidate(out error)) return false;
                var classId = definition.Id.Trim();
                if (!IsCanonicalClass(classId))
                {
                    error = "Unknown class definition: " + classId;
                    return false;
                }
                if (byId.ContainsKey(classId))
                {
                    error = "Duplicate class definition: " + classId;
                    return false;
                }
                byId.Add(classId, definition);
            }

            if (!TryNormalizePool(names, "name", out var cleanNames, out error)) return false;
            if (!TryNormalizePool(appearanceIds, "appearance", out var cleanLooks, out error)) return false;

            var runtimeClasses = new AdventurerCatalog.ClassData[CanonicalClassIds.Length];
            for (var i = 0; i < CanonicalClassIds.Length; i++)
            {
                if (!byId.TryGetValue(CanonicalClassIds[i], out var source))
                {
                    error = "Missing canonical class: " + CanonicalClassIds[i];
                    return false;
                }
                var expectedName = ExpectedDisplayName(CanonicalClassIds[i]);
                var expectedRoles = ExpectedRoles(CanonicalClassIds[i]);
                if (!string.Equals(source.DisplayName.Trim(), expectedName, StringComparison.Ordinal) || source.Roles != expectedRoles)
                {
                    error = "Class metadata conflicts with the canonical Sprint 2 contract: " + CanonicalClassIds[i];
                    return false;
                }
                runtimeClasses[i] = new AdventurerCatalog.ClassData(
                    source.Id.Trim(), source.DisplayName.Trim(), source.Roles);
            }

            catalog = new AdventurerCatalog(runtimeClasses, cleanNames, cleanLooks);
            error = string.Empty;
            return true;
        }

        private static bool TryNormalizePool(string[] source, string label, out string[] result, out string error)
        {
            result = null;
            if (source == null || source.Length == 0)
            {
                error = "At least one " + label + " is required.";
                return false;
            }
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var normalized = new string[source.Length];
            for (var i = 0; i < source.Length; i++)
            {
                var value = (source[i] ?? string.Empty).Trim();
                if (string.IsNullOrEmpty(value))
                {
                    error = "Empty " + label + " entry.";
                    return false;
                }
                if (!seen.Add(value))
                {
                    error = "Duplicate " + label + " entry: " + value;
                    return false;
                }
                normalized[i] = value;
            }
            result = normalized;
            error = string.Empty;
            return true;
        }

        private static string ExpectedDisplayName(string id)
        {
            switch (id)
            {
                case "class.warrior": return "Krieger";
                case "class.rogue": return "Schurke";
                case "class.mage": return "Magier";
                case "class.priest": return "Priester";
                default: return string.Empty;
            }
        }

        private static AdventurerRole ExpectedRoles(string id)
        {
            switch (id)
            {
                case "class.warrior": return AdventurerRole.Tank | AdventurerRole.Damage;
                case "class.rogue": return AdventurerRole.Damage;
                case "class.mage": return AdventurerRole.Damage | AdventurerRole.SupportControl;
                case "class.priest": return AdventurerRole.Healing | AdventurerRole.SupportControl;
                default: return AdventurerRole.None;
            }
        }

        private static bool IsCanonicalClass(string id)
        {
            for (var i = 0; i < CanonicalClassIds.Length; i++)
                if (string.Equals(id, CanonicalClassIds[i], StringComparison.Ordinal)) return true;
            return false;
        }
    }
}

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GuildGame
{
    [CreateAssetMenu(menuName = "Guild Game/Quests/Quest Definition", fileName = "Quest_")]
    public sealed class QuestDefinition : ScriptableObject
    {
        [Serializable]
        private sealed class LootEntry
        {
            public string itemDefinitionId;
            public string displayName;
            public int minimumQuantity;
            public int maximumQuantity;
        }
        [SerializeField] private string definitionId;
        [SerializeField] private string displayName;
        [SerializeField] private QuestType type;
        [SerializeField] private string rank;
        [SerializeField] private QuestDistance distance;
        [SerializeField] private long expectedDurationSeconds;
        [SerializeField] private int recommendedPartySize = 1;
        [SerializeField] private string dangerLabel;
        [SerializeField] private int goldReward;
        [SerializeField] private int xpReward;
        [SerializeField] private LootEntry[] possibleLoot = Array.Empty<LootEntry>();

        public bool TryBuildData(out QuestDefinitionData data, out string error)
        {
            data = null; error = string.Empty;
            if (possibleLoot == null) { error = "Loot list is null."; return false; }
            var loot = new List<QuestLootContract>();
            foreach (var item in possibleLoot)
            {
                if (item == null) { error = "Null loot entry."; return false; }
                try { loot.Add(new QuestLootContract(item.itemDefinitionId, item.minimumQuantity, item.maximumQuantity, item.displayName)); }
                catch (ArgumentException ex) { error = ex.Message; return false; }
            }
            return QuestDefinitionData.TryCreate(definitionId, displayName, type, rank, distance, expectedDurationSeconds,
                recommendedPartySize, dangerLabel, goldReward, xpReward, loot, out data, out error);
        }
    }
}

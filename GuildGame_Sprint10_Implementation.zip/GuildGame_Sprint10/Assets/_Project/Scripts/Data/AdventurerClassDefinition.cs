using UnityEngine;

namespace GuildGame
{
    [CreateAssetMenu(menuName = "Guild Game/Adventurers/Class Definition", fileName = "Class_")]
    public sealed class AdventurerClassDefinition : ScriptableObject
    {
        [SerializeField] private string id;
        [SerializeField] private string displayName;
        [SerializeField] private AdventurerRole roles;

        public string Id => id;
        public string DisplayName => displayName;
        public AdventurerRole Roles => roles;

        public bool TryValidate(out string error)
        {
            var normalizedId = (id ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(normalizedId))
            {
                error = "Class id is required.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(displayName))
            {
                error = "Class display name is required.";
                return false;
            }
            if (roles == AdventurerRole.None)
            {
                error = "At least one role is required.";
                return false;
            }
            error = string.Empty;
            return true;
        }
    }
}

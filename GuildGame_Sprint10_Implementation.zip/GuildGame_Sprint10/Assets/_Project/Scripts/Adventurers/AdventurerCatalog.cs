using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace GuildGame
{
    public sealed class AdventurerCatalog
    {
        public sealed class ClassData
        {
            public string Id { get; }
            public string DisplayName { get; }
            public AdventurerRole Roles { get; }

            internal ClassData(string id, string displayName, AdventurerRole roles)
            {
                Id = id;
                DisplayName = displayName;
                Roles = roles;
            }
        }

        private readonly ClassData[] classes;
        private readonly string[] names;
        private readonly string[] appearances;
        private readonly Dictionary<string, ClassData> byId;
        private readonly HashSet<string> appearanceSet;
        private readonly ReadOnlyCollection<ClassData> classesView;
        private readonly ReadOnlyCollection<string> namesView;
        private readonly ReadOnlyCollection<string> appearancesView;

        internal AdventurerCatalog(ClassData[] classes, string[] names, string[] appearances)
        {
            this.classes = (ClassData[])classes.Clone();
            this.names = (string[])names.Clone();
            this.appearances = (string[])appearances.Clone();
            byId = new Dictionary<string, ClassData>(StringComparer.Ordinal);
            foreach (var item in this.classes) byId.Add(item.Id, item);
            appearanceSet = new HashSet<string>(this.appearances, StringComparer.Ordinal);
            classesView = Array.AsReadOnly(this.classes);
            namesView = Array.AsReadOnly(this.names);
            appearancesView = Array.AsReadOnly(this.appearances);
        }

        public IReadOnlyList<ClassData> Classes => classesView;
        public IReadOnlyList<string> Names => namesView;
        public IReadOnlyList<string> Appearances => appearancesView;

        public bool TryGetClass(string classId, out ClassData data)
        {
            data = null;
            if (string.IsNullOrWhiteSpace(classId)) return false;
            return byId.TryGetValue(classId.Trim(), out data);
        }

        public bool ContainsAppearance(string appearanceId) =>
            !string.IsNullOrWhiteSpace(appearanceId) && appearanceSet.Contains(appearanceId.Trim());

        public bool ContainsName(string displayName)
        {
            if (string.IsNullOrWhiteSpace(displayName)) return false;
            var normalized = displayName.Trim();
            for (var i = 0; i < names.Length; i++)
                if (string.Equals(names[i], normalized, StringComparison.Ordinal)) return true;
            return false;
        }
    }
}

using System;

namespace GuildGame
{
    public interface IRandomSource
    {
        int NextIndex(int exclusiveMax);
    }

    public sealed class RandomGenerator : IRandomSource
    {
        private readonly Random random;

        public RandomGenerator(int seed)
        {
            random = new Random(seed);
        }

        public int NextIndex(int exclusiveMax)
        {
            if (exclusiveMax <= 0) throw new ArgumentOutOfRangeException(nameof(exclusiveMax));
            return random.Next(exclusiveMax);
        }
    }
}

using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class AdventurerManager
    {
        public const int Capacity = 12;
        private readonly AdventurerCatalog catalog;
        internal readonly GuildRuntimeStore RuntimeStore = new GuildRuntimeStore();
        private IReadOnlyList<AdventurerState> members => RuntimeStore.Current.Members;
        internal bool TryGetClass(string id, out AdventurerCatalog.ClassData data) => catalog.TryGetClass(id,out data);

        public AdventurerManager(AdventurerCatalog catalog)
        {
            this.catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
        }

        public int Count => members.Count;

        public AdventurerResult TryAdd(AdventurerState state)
        {
            var validation = ValidateForAdd(state);
            if (validation != null) return validation;
            if (members.Count >= Capacity)
                return new AdventurerResult(AdventurerStatus.CapacityReached, state);

            var next = new List<AdventurerState>(members) { state };
            RuntimeStore.ReplaceMembers(next);
            return AdventurerResult.Ok(state);
        }

        public AdventurerResult TryAddBatch(IReadOnlyList<AdventurerState> states)
        {
            if (states == null || states.Count == 0)
                return new AdventurerResult(AdventurerStatus.InvalidState, message: "Batch is empty.");
            if (members.Count + states.Count > Capacity)
                return new AdventurerResult(AdventurerStatus.CapacityReached);

            var batchIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < states.Count; i++)
            {
                var validation = ValidateForAdd(states[i], batchIds);
                if (validation != null) return validation;
            }

            var next = new List<AdventurerState>(members);
            for (var i = 0; i < states.Count; i++) next.Add(states[i]);
            RuntimeStore.ReplaceMembers(next);
            return AdventurerResult.Ok(states[states.Count - 1]);
        }

        private AdventurerResult ValidateForAdd(AdventurerState state, HashSet<string> batchIds = null)
        {
            if (state == null) return new AdventurerResult(AdventurerStatus.InvalidState);
            if (!Guid.TryParse(state.Id, out var id) || id == Guid.Empty || string.IsNullOrWhiteSpace(state.DisplayName))
                return new AdventurerResult(AdventurerStatus.InvalidState);
            if (!catalog.TryGetClass(state.ClassId, out _))
                return new AdventurerResult(AdventurerStatus.UnknownClass, state);
            if (!catalog.ContainsAppearance(state.AppearanceId))
                return new AdventurerResult(AdventurerStatus.UnknownAppearance, state);

            var normalizedId = id.ToString("D");
            for (var i = 0; i < members.Count; i++)
                if (string.Equals(members[i].Id, normalizedId, StringComparison.OrdinalIgnoreCase))
                    return new AdventurerResult(AdventurerStatus.DuplicateId, state);
            if (batchIds != null && !batchIds.Add(normalizedId))
                return new AdventurerResult(AdventurerStatus.DuplicateId, state);
            return null;
        }

        public bool TryGetById(string id, out AdventurerState state)
        {
            state = null;
            if (!Guid.TryParse(id, out var guid) || guid == Guid.Empty) return false;
            var normalized = guid.ToString("D");
            for (var i = 0; i < members.Count; i++)
            {
                if (string.Equals(members[i].Id, normalized, StringComparison.OrdinalIgnoreCase))
                {
                    state = members[i];
                    return true;
                }
            }
            return false;
        }

        public IReadOnlyList<AdventurerState> GetMembersSnapshot() =>
            Array.AsReadOnly(new List<AdventurerState>(members).ToArray());
    }
}

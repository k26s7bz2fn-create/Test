namespace GuildGame
{
    public enum AdventurerStatus
    {
        Success = 0,
        InvalidDefinition,
        InvalidState,
        UnknownClass,
        UnknownAppearance,
        DuplicateId,
        CapacityReached,
        GenerationFailed
    }

    public sealed class AdventurerResult
    {
        public AdventurerStatus Status { get; }
        public AdventurerState State { get; }
        public string Message { get; }
        public bool Success => Status == AdventurerStatus.Success;

        public AdventurerResult(AdventurerStatus status, AdventurerState state = null, string message = null)
        {
            Status = status;
            State = state;
            Message = message ?? string.Empty;
        }

        public static AdventurerResult Ok(AdventurerState state) =>
            new AdventurerResult(AdventurerStatus.Success, state);
    }
}

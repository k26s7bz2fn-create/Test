using System;

namespace GuildGame
{
    [Flags]
    public enum AdventurerRole
    {
        None = 0,
        Tank = 1 << 0,
        Damage = 1 << 1,
        Healing = 1 << 2,
        SupportControl = 1 << 3
    }
}

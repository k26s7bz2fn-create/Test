using System;
using System.Collections.Generic;
namespace GuildGame
{
    // Single publication root, not a second roster or a second health database.
    internal sealed class GuildRuntimeSnapshot
    {
        internal readonly IReadOnlyList<AdventurerState> Members;
        internal readonly Dictionary<string, QuestRuntimeState> Quests;
        internal readonly long? ObservedTimestamp;
        internal readonly GuildEconomyState Economy;
        internal readonly GuildStorageState Storage;
        internal readonly RewardLedgerState RewardLedger;
        internal GuildRuntimeSnapshot(IEnumerable<AdventurerState> members, Dictionary<string, QuestRuntimeState> quests, long? observed, GuildEconomyState economy=null, GuildStorageState storage=null, RewardLedgerState ledger=null)
        {
            Members = Array.AsReadOnly(new List<AdventurerState>(members).ToArray());
            Quests = new Dictionary<string, QuestRuntimeState>(quests, StringComparer.Ordinal);
            ObservedTimestamp = observed;
            Economy=economy??new GuildEconomyState(0);Storage=storage??GuildStorageState.Empty;RewardLedger=ledger??RewardLedgerState.Empty;
        }
        internal GuildRuntimeSnapshot WithEquipment(IEnumerable<AdventurerState> members,GuildStorageState storage) =>
            new GuildRuntimeSnapshot(members,Quests,ObservedTimestamp,Economy,storage,RewardLedger);
        internal GuildRuntimeSnapshot WithMembers(IEnumerable<AdventurerState> members) =>
            new GuildRuntimeSnapshot(members,Quests,ObservedTimestamp,Economy,Storage,RewardLedger);
        internal GuildRuntimeSnapshot WithQuests(IEnumerable<AdventurerState> members,Dictionary<string,QuestRuntimeState> quests,long? observed) =>
            new GuildRuntimeSnapshot(members,quests,observed,Economy,Storage,RewardLedger);
        internal GuildRuntimeSnapshot WithRewards(IEnumerable<AdventurerState> members,GuildEconomyState economy,GuildStorageState storage,RewardLedgerState ledger) =>
            new GuildRuntimeSnapshot(members,Quests,ObservedTimestamp,economy,storage,ledger);
    }
    internal sealed class GuildRuntimeStore
    {
        internal GuildRuntimeSnapshot Current { get; private set; } = new GuildRuntimeSnapshot(
            Array.Empty<AdventurerState>(),new Dictionary<string,QuestRuntimeState>(StringComparer.Ordinal),null);
        private object questOwner;
        internal void BindQuestRegistry(object owner)
        {
            if (questOwner != null && !ReferenceEquals(owner,questOwner)) throw new InvalidOperationException("Roster already bound to another quest registry.");
            questOwner=owner;
        }
        internal bool TryPublish(GuildRuntimeSnapshot expected, GuildRuntimeSnapshot next)
        {
            if (!ReferenceEquals(Current,expected)) return false;
            Current=next; return true; // Only publication point for health AND quest resolution.
        }
        internal void ReplaceMembers(IEnumerable<AdventurerState> members)
        {
            var before=Current;
            if(!TryPublish(before,before.WithMembers(members)))
                throw new InvalidOperationException("Stale roster mutation.");
        }
    }
}

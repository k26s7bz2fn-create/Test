using System;

namespace GuildGame
{
    public sealed class AdventurerState
    {
        public const string InitialRank = "F";
        public const int InitialLevel = 1;

        public bool IsDead { get; }
        public long? RecoveryUntil { get; }
        public decimal LeadershipQuality { get; }
        public decimal PersonalityBoldness { get; }
        public bool IsInjuredAt(long now) => !IsDead && RecoveryUntil.HasValue && now < RecoveryUntil.Value;
        public bool CanDeployAt(long now) => now >= 0 && !IsDead && !IsInjuredAt(now);
        public string Id { get; }
        public string ClassId { get; }
        public string DisplayName { get; }
        public string AppearanceId { get; }
        public string Rank => InitialRank;
        public AdventurerProgressionState Progression { get; }
        public int Level => Progression.Level;
        public EquipmentState Equipment { get; }
        public HealingPotionAssignmentState Potions { get; }

        private AdventurerState(string id, string classId, string displayName, string appearanceId, bool dead = false, long? recovery = null, decimal leadership = QuestSimulationRules.DefaultLeaderQuality, decimal boldness = QuestSimulationRules.DefaultBoldness, AdventurerProgressionState progression = null, EquipmentState equipment = null, HealingPotionAssignmentState potions = null)
        {
            Progression = progression ?? AdventurerProgressionState.Initial;
            Equipment=equipment??EquipmentState.Empty;Potions=potions??HealingPotionAssignmentState.Empty;
            IsDead = dead; RecoveryUntil = recovery; LeadershipQuality = leadership; PersonalityBoldness = boldness;
            Id = id;
            ClassId = classId;
            DisplayName = displayName;
            AppearanceId = appearanceId;
        }

        // Used only by the atomic resolution path. Death cannot be undone by later consequences.
        internal AdventurerState WithQuestConsequences(bool dead, long? recovery)
        {
            if (recovery.HasValue && recovery.Value < 0) throw new ArgumentOutOfRangeException(nameof(recovery));
            return new AdventurerState(Id,ClassId,DisplayName,AppearanceId,IsDead || dead,
                IsDead || dead ? null : recovery,LeadershipQuality,PersonalityBoldness,Progression,Equipment,Potions);
        }
        internal AdventurerState WithProgression(AdventurerProgressionState progression)
        {
            if(progression==null)throw new ArgumentNullException(nameof(progression));
            return new AdventurerState(Id,ClassId,DisplayName,AppearanceId,IsDead,RecoveryUntil,
                LeadershipQuality,PersonalityBoldness,progression,Equipment,Potions);
        }
        internal AdventurerState WithLoadout(EquipmentState equipment,HealingPotionAssignmentState potions)
        {
            if(equipment==null||potions==null)throw new ArgumentNullException();
            return new AdventurerState(Id,ClassId,DisplayName,AppearanceId,IsDead,RecoveryUntil,
                LeadershipQuality,PersonalityBoldness,Progression,equipment,potions);
        }
        public static bool TryCreate(string id, string classId, string name, string appearance,
            decimal leadership, decimal boldness, out AdventurerState state)
        {
            state=null;
            if(leadership<0m || leadership>1m || boldness< -1m || boldness>1m) return false;
            if(!TryCreate(id,classId,name,appearance,out var basic)) return false;
            state=new AdventurerState(basic.Id,basic.ClassId,basic.DisplayName,basic.AppearanceId,
                false,null,leadership,boldness);
            return true;
        }

        public static bool TryCreate(
            string id,
            string classId,
            string displayName,
            string appearanceId,
            out AdventurerState state)
        {
            state = null;
            if (!Guid.TryParse(id, out var guid) || guid == Guid.Empty) return false;
            var normalizedClass = (classId ?? string.Empty).Trim();
            var normalizedName = (displayName ?? string.Empty).Trim();
            var normalizedAppearance = (appearanceId ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(normalizedClass) || string.IsNullOrEmpty(normalizedName) || string.IsNullOrEmpty(normalizedAppearance))
                return false;
            state = new AdventurerState(guid.ToString("D"), normalizedClass, normalizedName, normalizedAppearance);
            return true;
        }
    }
}

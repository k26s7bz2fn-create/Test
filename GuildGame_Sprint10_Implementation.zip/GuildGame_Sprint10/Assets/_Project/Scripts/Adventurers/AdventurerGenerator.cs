using System;

namespace GuildGame
{
    public sealed class AdventurerGenerator
    {
        private readonly AdventurerCatalog catalog;
        private readonly IRandomSource random;
        private readonly Func<string> idFactory;

        public AdventurerGenerator(AdventurerCatalog catalog, IRandomSource random, Func<string> idFactory = null)
        {
            this.catalog = catalog;
            this.random = random;
            this.idFactory = idFactory ?? (() => Guid.NewGuid().ToString("D"));
        }

        public AdventurerResult Generate(string requestedClassId = null)
        {
            if (catalog == null || random == null || idFactory == null)
                return new AdventurerResult(AdventurerStatus.InvalidDefinition, message: "Generator dependencies are invalid.");

            AdventurerCatalog.ClassData classData;
            if (requestedClassId != null)
            {
                if (string.IsNullOrWhiteSpace(requestedClassId))
                    return new AdventurerResult(AdventurerStatus.UnknownClass, message: "Requested class is empty.");
                if (!catalog.TryGetClass(requestedClassId, out classData))
                    return new AdventurerResult(AdventurerStatus.UnknownClass, message: "Requested class is unknown.");
            }
            else
            {
                if (!TryIndex(catalog.Classes.Count, out var classIndex))
                    return new AdventurerResult(AdventurerStatus.GenerationFailed, message: "Class selection failed.");
                classData = catalog.Classes[classIndex];
            }

            if (!TryIndex(catalog.Names.Count, out var nameIndex) ||
                !TryIndex(catalog.Appearances.Count, out var lookIndex))
                return new AdventurerResult(AdventurerStatus.GenerationFailed, message: "Name or appearance selection failed.");

            string rawId;
            try { rawId = idFactory(); }
            catch (Exception ex) { return new AdventurerResult(AdventurerStatus.GenerationFailed, message: ex.Message); }

            if (!AdventurerState.TryCreate(rawId, classData.Id, catalog.Names[nameIndex], catalog.Appearances[lookIndex], out var state))
                return new AdventurerResult(AdventurerStatus.GenerationFailed, message: "Generated state is invalid.");

            return AdventurerResult.Ok(state);
        }

        private bool TryIndex(int exclusiveMax, out int index)
        {
            index = -1;
            if (exclusiveMax <= 0) return false;
            try { index = random.NextIndex(exclusiveMax); }
            catch { return false; }
            return index >= 0 && index < exclusiveMax;
        }
    }
}

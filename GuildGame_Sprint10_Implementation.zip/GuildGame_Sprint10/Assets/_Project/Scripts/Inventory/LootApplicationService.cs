using System;
using System.Collections.Generic;
using System.Globalization;
namespace GuildGame
{
    public sealed class LootApplicationChange
    {
        public GuildStorageState After { get; }
        public IReadOnlyList<QuestLootOutput> Outputs { get; }
        public IReadOnlyList<string> CreatedInstanceIds { get; }
        internal LootApplicationChange(GuildStorageState after,List<QuestLootOutput> outputs,List<string> ids)
        {After=after;Outputs=Array.AsReadOnly(outputs.ToArray());CreatedInstanceIds=Array.AsReadOnly(ids.ToArray());}
    }
    public sealed class LootApplicationService
    {
        public LootApplicationChange Prepare(GuildStorageState before,IReadOnlyList<QuestLootOutput> outputs,ItemCatalog catalog)
        {
            if(before==null||outputs==null||catalog==null)throw new RewardRejectedException(RewardApplicationCode.StorageValidationFailed);
            var equipment=new Dictionary<string,EquipmentInstance>(StringComparer.Ordinal);
            foreach(var e in before.Equipment)equipment.Add(e.Key,e.Value);
            var potions=new Dictionary<string,long>(StringComparer.Ordinal);
            foreach(var p in before.PotionStacks)potions.Add(p.Key,p.Value);
            var seen=new HashSet<string>(StringComparer.Ordinal);var ids=new List<string>();var copied=new List<QuestLootOutput>();
            // Validate entire batch before expanding any equipment quantity.
            foreach(var o in outputs)
            {
                if(o==null||string.IsNullOrWhiteSpace(o.OutputId)||o.Quantity<=0)throw new RewardRejectedException(RewardApplicationCode.InvalidRewardAmount);
                if(!seen.Add(o.OutputId))throw new RewardRejectedException(RewardApplicationCode.RewardIdentityConflict);
                if(!catalog.TryGet(o.ItemDefinitionId,out _))throw new RewardRejectedException(RewardApplicationCode.UnknownItemDefinition);
                copied.Add(o);
            }
            copied.Sort((a,b)=>string.CompareOrdinal(a.OutputId,b.OutputId));
            foreach(var o in copied)
            {
                catalog.TryGet(o.ItemDefinitionId,out var definition);
                if(definition.StorageMode==ItemStorageMode.Stack)
                {potions.TryGetValue(o.ItemDefinitionId,out var count);potions[o.ItemDefinitionId]=checked(count+o.Quantity);}
                else
                    for(var index=0;index<o.Quantity;index++)
                    {
                        var id=o.OutputId+"/instance/"+index.ToString(CultureInfo.InvariantCulture);
                        if(equipment.ContainsKey(id))throw new RewardRejectedException(RewardApplicationCode.RewardIdentityConflict);
                        equipment.Add(id,new EquipmentInstance(id,definition,o.OutputId));ids.Add(id);
                    }
            }
            return new LootApplicationChange(new GuildStorageState(equipment,potions),copied,ids);
        }
    }
}

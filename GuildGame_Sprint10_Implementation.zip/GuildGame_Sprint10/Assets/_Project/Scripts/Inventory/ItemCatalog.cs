using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class ItemCatalog
    {
        private readonly Dictionary<string,ItemDefinitionData> items=new Dictionary<string,ItemDefinitionData>(StringComparer.Ordinal);
        public IReadOnlyList<ItemDefinitionData> Definitions { get; }
        public ItemCatalog(IEnumerable<ItemDefinitionData> definitions)
        {
            if(definitions==null)throw new ArgumentNullException(nameof(definitions));
            foreach(var item in definitions)
            {if(item==null||items.ContainsKey(item.ItemDefinitionId))throw new ArgumentException("Null/duplicate item.");items.Add(item.ItemDefinitionId,item);}
            var sorted=new List<ItemDefinitionData>(items.Values);sorted.Sort((a,b)=>string.CompareOrdinal(a.ItemDefinitionId,b.ItemDefinitionId));
            Definitions=Array.AsReadOnly(sorted.ToArray());
        }
        public bool TryGet(string id,out ItemDefinitionData item){item=null;return id!=null&&items.TryGetValue(id,out item);}
        public static ItemCatalog CreateV01()
        {
            var all=new[]{"class.warrior","class.rogue","class.mage","class.priest"};
            return new ItemCatalog(new[]{
                new ItemDefinitionData("item.weapon.training_sword.common","Übungsschwert",ItemType.Weapon,ItemRarity.Common,new[]{all[0]}),
                new ItemDefinitionData("item.weapon.training_dagger.common","Übungsdolch",ItemType.Weapon,ItemRarity.Common,new[]{all[1]}),
                new ItemDefinitionData("item.weapon.training_staff.common","Übungsstab",ItemType.Weapon,ItemRarity.Common,new[]{all[2]}),
                new ItemDefinitionData("item.weapon.training_mace.common","Übungsstreitkolben",ItemType.Weapon,ItemRarity.Common,new[]{all[3]}),
                new ItemDefinitionData("item.armor.training_upper.common","Einfache Oberkörperrüstung",ItemType.ArmorUpper,ItemRarity.Common,all),
                new ItemDefinitionData("item.armor.training_legs.common","Einfache Beinrüstung",ItemType.ArmorLegs,ItemRarity.Common,all),
                new ItemDefinitionData("item.potion.healing.basic","Einfacher Heiltrank",ItemType.HealingPotion,null,Array.Empty<string>())
            });
        }
    }
}

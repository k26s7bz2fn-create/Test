using System;
using System.Collections.Generic;
namespace GuildGame
{
    public enum ItemType { Weapon, ArmorUpper, ArmorLegs, HealingPotion }
    public enum ItemCategory { Weapon, Armor, Potion, Special }
    public enum ItemRarity { Common, Uncommon, Rare }
    public enum EquipmentSlot { Weapon, UpperBody, Legs }
    public enum ItemStorageMode { Instance, Stack }
    public sealed class ItemDefinitionData
    {
        public EquipmentItemValues EquipmentValues { get; }
        public string ItemDefinitionId { get; }
        public string DisplayName { get; }
        public ItemType ItemType { get; }
        public ItemCategory Category { get; }
        public ItemRarity? Rarity { get; }
        public EquipmentSlot? Slot { get; }
        public ItemStorageMode StorageMode { get; }
        public IReadOnlyList<string> AllowedClassIds { get; }
        public ItemDefinitionData(string id,string name,ItemType type,ItemRarity? rarity,IReadOnlyList<string> classes,EquipmentItemValues equipmentValues=null)
        {
            if(string.IsNullOrWhiteSpace(id)||id!=id.Trim()||string.IsNullOrWhiteSpace(name)||!Enum.IsDefined(typeof(ItemType),type)||classes==null)
                throw new ArgumentException("Invalid item definition.");
            var copy=new List<string>(classes);var seen=new HashSet<string>(StringComparer.Ordinal);
            var skills=new ClassSkillAllocationRules();
            foreach(var cls in copy)if(!seen.Add(cls)||!skills.TryGetSkills(cls,out _))throw new ArgumentException("Invalid allowed class.");
            var potion=type==ItemType.HealingPotion;
            if(potion ? rarity.HasValue || copy.Count!=0 : !rarity.HasValue || !Enum.IsDefined(typeof(ItemRarity),rarity.Value) || copy.Count==0)
                throw new ArgumentException("Invalid rarity/classes for item type.");
            EquipmentValues=potion?null:equipmentValues??EquipmentItemValues.ApprovedDefault(id);
            ItemDefinitionId=id;DisplayName=name;ItemType=type;Rarity=rarity;AllowedClassIds=Array.AsReadOnly(copy.ToArray());
            Category=potion?ItemCategory.Potion:type==ItemType.Weapon?ItemCategory.Weapon:ItemCategory.Armor;
            StorageMode=potion?ItemStorageMode.Stack:ItemStorageMode.Instance;
            Slot=potion?(EquipmentSlot?)null:type==ItemType.Weapon?EquipmentSlot.Weapon:type==ItemType.ArmorUpper?EquipmentSlot.UpperBody:EquipmentSlot.Legs;
        }
    }
}

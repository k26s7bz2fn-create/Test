using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace GuildGame
{
    public sealed class EquipmentInstance
    {
        public string InstanceId { get; }
        public ItemDefinitionData Definition { get; }
        public string SourceOutputId { get; }
        public int Quantity => 1;
        internal EquipmentInstance(string id,ItemDefinitionData definition,string output)
        {InstanceId=id;Definition=definition;SourceOutputId=output;}
    }
    public sealed class GuildStorageState
    {
        public IReadOnlyDictionary<string,EquipmentInstance> Equipment { get; }
        public IReadOnlyDictionary<string,long> PotionStacks { get; }
        public static GuildStorageState Empty { get; }=new GuildStorageState(new Dictionary<string,EquipmentInstance>(),new Dictionary<string,long>());
        internal GuildStorageState(IDictionary<string,EquipmentInstance> equipment,IDictionary<string,long> potions)
        {
            foreach(var entry in potions)if(entry.Value<0)throw new ArgumentException("Negative stock.");
            Equipment=new ReadOnlyDictionary<string,EquipmentInstance>(new Dictionary<string,EquipmentInstance>(equipment,StringComparer.Ordinal));
            PotionStacks=new ReadOnlyDictionary<string,long>(new Dictionary<string,long>(potions,StringComparer.Ordinal));
        }
    }
}

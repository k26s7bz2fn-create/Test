using System;

namespace GuildGame
{
    /// <summary>Possible loot only: no instance, drop chance, inventory or outcome.</summary>
    public sealed class QuestLootContract
    {
        public string ItemDefinitionId { get; }
        public string DisplayName { get; }
        public int MinimumQuantity { get; }
        public int MaximumQuantity { get; }

        public QuestLootContract(string itemDefinitionId, int minimumQuantity, int maximumQuantity, string displayName = null)
        {
            if (string.IsNullOrWhiteSpace(itemDefinitionId)) throw new ArgumentException("Item definition ID required.", nameof(itemDefinitionId));
            if (minimumQuantity < 0 || maximumQuantity < minimumQuantity) throw new ArgumentOutOfRangeException(nameof(minimumQuantity));
            ItemDefinitionId = itemDefinitionId.Trim();
            DisplayName = displayName == null ? string.Empty : displayName.Trim();
            MinimumQuantity = minimumQuantity; MaximumQuantity = maximumQuantity;
        }
    }
}

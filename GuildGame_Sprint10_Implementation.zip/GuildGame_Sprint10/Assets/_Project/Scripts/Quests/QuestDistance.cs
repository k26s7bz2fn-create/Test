namespace GuildGame
{
    public enum QuestDistance { Near = 0, Medium = 1, Far = 2 }
}

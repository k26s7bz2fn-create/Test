namespace GuildGame
{
    public enum QuestResolutionCode
    {
        Success, AlreadyResolved, InvalidQuestId, UnknownQuest, NotPending,
        InvalidInput, InvalidInputOrRules, NumericOverflow, SimulationFailed, StaleState, Busy, EquipmentReturnFailed
    }
    public sealed class QuestResolutionResult
    {
        public QuestResolutionCode Status { get; }
        public QuestSimulationResult Result { get; }
        // Exactly one successful command publishes a new result. Retries only expose the stored receipt.
        public bool HasNewResult => Status == QuestResolutionCode.Success;
        internal QuestResolutionResult(QuestResolutionCode status, QuestSimulationResult result = null)
        { Status = status; Result = result; }
    }
}

using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Globalization;
namespace GuildGame
{
    internal interface IQuestSimulationRandom { decimal Unit(string domain); }
    internal sealed class QuestSimulationRandom : IQuestSimulationRandom
    {
        private readonly string seed,quest,version;
        internal QuestSimulationRandom(long seed,string quest,string version)
        {this.seed=seed.ToString(CultureInfo.InvariantCulture);this.quest=quest;this.version=version;}
        internal static byte[] Digest(params string[] parts)
        {
            using(var stream=new MemoryStream())
            {
                foreach(var part in parts)
                {
                    var b=Encoding.UTF8.GetBytes(part??string.Empty);var n=(uint)b.Length;
                    stream.WriteByte((byte)(n>>24));stream.WriteByte((byte)(n>>16));stream.WriteByte((byte)(n>>8));stream.WriteByte((byte)n);
                    stream.Write(b,0,b.Length);
                }
                using(var sha=SHA256.Create()) return sha.ComputeHash(stream.ToArray());
            }
        }
        internal static string Hash(params string[] parts)=>BitConverter.ToString(Digest(parts)).Replace("-","").ToLowerInvariant();
        public decimal Unit(string domain)
        {
            var hash=Digest(seed,quest,version,domain);ulong value=0;
            for(var i=0;i<8;i++) value=(value<<8)|hash[i];
            return (decimal)(value>>11)/9007199254740992m;
        }
    }
}

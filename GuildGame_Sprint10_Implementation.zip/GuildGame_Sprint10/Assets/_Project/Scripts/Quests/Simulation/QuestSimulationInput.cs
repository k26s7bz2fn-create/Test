using System;
using System.Collections.Generic;
using System.Globalization;
namespace GuildGame
{
    public sealed class QuestSimulationMember
    {
        public AdventurerState Adventurer { get; }
        public AdventurerRole Roles { get; }
        public QuestSimulationMember(AdventurerState state,AdventurerRole roles)
        {Adventurer=state??throw new ArgumentNullException(nameof(state));Roles=roles;}
    }
    public sealed class QuestSimulationInput
    {
        public QuestRuntimeState Quest { get; }
        public PartyState Party { get; }
        public IReadOnlyList<QuestSimulationMember> Members { get; }
        public string Fingerprint { get; }
        public QuestSimulationInput(QuestRuntimeState quest,PartyState party,IReadOnlyList<QuestSimulationMember> members)
        {
            if(quest==null || party==null || members==null) throw new ArgumentException("Missing simulation inputs.");
            if(quest.Status!=QuestStatus.CompletedPendingResolution || !quest.CompletionTimestamp.HasValue || !quest.StartTimestamp.HasValue)
                throw new ArgumentException("Only pending quests can be simulated.");
            if(party.PartyId!=quest.AssignedPartyId || party.LeaderId!=quest.LeaderIdAtStart || members.Count<1 || members.Count>6)
                throw new ArgumentException("Mismatched group snapshot.");
            var ids=new HashSet<string>(quest.MemberIdsAtStart,StringComparer.Ordinal);
            if(ids.Count!=quest.MemberIdsAtStart.Count || !ids.SetEquals(party.MemberIds) || ids.Count!=party.MemberCount)
                throw new ArgumentException("Invalid participants.");
            var list=new List<QuestSimulationMember>(members);list.Sort((a,b)=>string.CompareOrdinal(a?.Adventurer.Id,b?.Adventurer.Id));
            foreach(var m in list)
                if(m==null || !ids.Remove(m.Adventurer.Id) || !m.Adventurer.CanDeployAt(quest.StartTimestamp.Value))
                    throw new ArgumentException("Invalid participant state.");
            if(ids.Count!=0 || (party.LeaderId!=null && !Contains(list,party.LeaderId))) throw new ArgumentException("Missing participant/leader.");
            Quest=quest;Party=party;Members=Array.AsReadOnly(list.ToArray());
            var d=quest.DefinitionSnapshot;
            var parts=new List<string>{quest.QuestInstanceId,party.PartyId,party.LeaderId??"",d.DefinitionId,d.DisplayName,
                d.Type.ToString(),d.Rank,d.Distance.ToString(),d.DangerLabel,d.ExpectedDurationSeconds.ToString(CultureInfo.InvariantCulture),
                d.RecommendedPartySize.ToString(CultureInfo.InvariantCulture),d.GoldReward.ToString(CultureInfo.InvariantCulture),d.XpReward.ToString(CultureInfo.InvariantCulture),
                quest.StartTimestamp.Value.ToString(CultureInfo.InvariantCulture),quest.CompletionTimestamp.Value.ToString(CultureInfo.InvariantCulture)};
            foreach(var m in list)
            {
                var a=m.Adventurer;parts.Add(a.Id);parts.Add(a.ClassId);parts.Add(a.Rank);parts.Add(a.Level.ToString(CultureInfo.InvariantCulture));
                parts.Add(((int)m.Roles).ToString(CultureInfo.InvariantCulture));parts.Add(a.LeadershipQuality.ToString(CultureInfo.InvariantCulture));parts.Add(a.PersonalityBoldness.ToString(CultureInfo.InvariantCulture));
            }
            var lootEntries=new List<QuestLootContract>(d.PossibleLoot);
            lootEntries.Sort((a,b)=>{var c=string.CompareOrdinal(a.ItemDefinitionId,b.ItemDefinitionId);if(c!=0)return c;c=a.MinimumQuantity.CompareTo(b.MinimumQuantity);return c!=0?c:a.MaximumQuantity.CompareTo(b.MaximumQuantity);});
            foreach(var loot in lootEntries){parts.Add(loot.ItemDefinitionId);parts.Add(loot.MinimumQuantity.ToString(CultureInfo.InvariantCulture));parts.Add(loot.MaximumQuantity.ToString(CultureInfo.InvariantCulture));}
            Fingerprint=QuestSimulationRandom.Hash(parts.ToArray());
        }
        private static bool Contains(List<QuestSimulationMember> list,string id)
        {foreach(var m in list)if(m.Adventurer.Id==id)return true;return false;}
    }
}

using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class QuestMemberOutcome
    {
        public string AdventurerId { get; }
        public bool Incapacitated { get; }
        public bool Stabilized { get; }
        public bool IsDead { get; }
        public bool IsInjured => !IsDead && RecoveryUntil.HasValue;
        public int RecoverySeconds { get; }
        public long? RecoveryUntil { get; }
        public long Xp { get; }
        public string XpOutputId { get; }
        internal QuestMemberOutcome(string id,bool incap,bool stabilized,bool dead,int seconds,long? until,long xp,string output)
        {AdventurerId=id;Incapacitated=incap;Stabilized=stabilized;IsDead=dead;RecoverySeconds=seconds;RecoveryUntil=until;Xp=xp;XpOutputId=output;}
    }
    public sealed class QuestLootOutput
    {
        public string OutputId { get; }
        public string ItemDefinitionId { get; }
        public int Quantity { get; }
        internal QuestLootOutput(string output,string item,int quantity){OutputId=output;ItemDefinitionId=item;Quantity=quantity;}
    }
    public sealed class QuestSimulationResult
    {
        public string ResolutionId { get; }
        public string QuestInstanceId { get; }
        public string PartyId { get; }
        public string InputFingerprint { get; }
        public string RulesVersion { get; }
        public string RulesFingerprint { get; }
        public long Seed { get; }
        public decimal PartyPower { get; }
        public decimal QuestDifficulty { get; }
        public decimal Ratio { get; }
        public decimal Overload { get; }
        public decimal RetreatProbability { get; }
        public decimal SuccessProbability { get; }
        public bool ObjectiveSucceeded { get; }
        public bool RetreatOccurred { get; }
        public bool IsWipe { get; }
        public long GoldOutput { get; }
        public string GoldOutputId => ResolutionId+"/gold";
        public IReadOnlyList<QuestMemberOutcome> MemberResults { get; }
        public IReadOnlyList<QuestLootOutput> LootOutputs { get; }
        internal QuestSimulationResult(QuestSimulationInput input,string id,string version,string rules,long seed,
            decimal power,decimal difficulty,decimal ratio,decimal overload,decimal retreatProbability,decimal successProbability,
            bool success,bool retreat,bool wipe,long gold,List<QuestMemberOutcome> members,List<QuestLootOutput> loot)
        {
            QuestInstanceId=input.Quest.QuestInstanceId;PartyId=input.Party.PartyId;InputFingerprint=input.Fingerprint;
            ResolutionId=id;RulesVersion=version;RulesFingerprint=rules;Seed=seed;PartyPower=power;QuestDifficulty=difficulty;Ratio=ratio;
            Overload=overload;RetreatProbability=retreatProbability;SuccessProbability=successProbability;
            ObjectiveSucceeded=success;RetreatOccurred=retreat;IsWipe=wipe;GoldOutput=gold;
            MemberResults=Array.AsReadOnly(members.ToArray());LootOutputs=Array.AsReadOnly(loot.ToArray());
        }
    }
}

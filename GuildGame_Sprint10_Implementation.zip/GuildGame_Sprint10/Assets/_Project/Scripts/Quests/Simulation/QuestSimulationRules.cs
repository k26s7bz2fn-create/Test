using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
namespace GuildGame
{
    /// <summary>Approved v1 defaults. Service copies/validates configuration at construction.</summary>
    public sealed class QuestSimulationRules
    {
        public const decimal DefaultLeaderQuality=0.5m, DefaultBoldness=0m;
        public string Version="s7.v1";
        public decimal BasePower=10m, LevelStep=.10m, RankFactor=1.5m;
        public decimal TankBonus=.08m, HealingBonus=.08m, DamageBonus=.04m;
        public decimal PowerRandom=.05m, OverloadScale=.5m;
        public decimal RetreatBase=.45m, LeaderRetreat=.40m, PersonalityRetreat=.03m, RetreatMax=.90m;
        public decimal SuccessBase=.10m, SuccessSlope=.80m, SuccessMin=.05m, SuccessMax=.98m;
        public decimal IncapSlope=.45m, IncapMax=.45m, RetreatIncap=.35m;
        public decimal InjuryBase=.10m, InjurySlope=.30m, InjuryMax=.40m, RetreatInjury=.60m;
        public decimal StabilizeChance=.65m, DeathBase=.15m, DeathOverload=.50m, CollapseDeath=.20m, DeathMax=.90m;
        public decimal XpBaseCoefficient=30m, GoldBaseCoefficient=20m;
        public decimal SuccessXp=1m, RetreatXp=.35m, FailureXp=.20m, WipeXp=0m, LootChance=.35m;
        public decimal RecoveryBase=60m, RecoveryOverload=180m, RecoveryIncap=60m, RecoveryMin=60m, RecoveryMax=300m;
        public Dictionary<string,int> RankIndices=new Dictionary<string,int>(StringComparer.Ordinal){{"F",0}};
        public Dictionary<string,decimal> DangerFactors=new Dictionary<string,decimal>(StringComparer.Ordinal)
            {{"Niedrig",.8m},{"Normal",1m},{"Hoch",1.25m}};

        internal QuestSimulationRules Freeze()
        {
            var c=(QuestSimulationRules)MemberwiseClone();
            if(string.IsNullOrWhiteSpace(Version) || RankIndices==null || DangerFactors==null) throw new ArgumentException("Missing rules configuration.");
            c.RankIndices=new Dictionary<string,int>(RankIndices,StringComparer.Ordinal);
            c.DangerFactors=new Dictionary<string,decimal>(DangerFactors,StringComparer.Ordinal);
            foreach(var f in typeof(QuestSimulationRules).GetFields(BindingFlags.Public|BindingFlags.Instance))
                if(f.FieldType==typeof(decimal) && (decimal)f.GetValue(c)<0m) throw new ArgumentException("Negative rule: "+f.Name);
            if(BasePower<=0 || RankFactor<=0 || OverloadScale<=0 || SuccessMin>SuccessMax || RecoveryMin>RecoveryMax || RecoveryMax>300m)
                throw new ArgumentException("Invalid rule range.");
            foreach(var p in new[]{PowerRandom,RetreatMax,SuccessMin,SuccessMax,IncapMax,RetreatIncap,InjuryMax,RetreatInjury,StabilizeChance,DeathMax,LootChance})
                if(p>1m) throw new ArgumentException("Probability outside [0,1].");
            if(PersonalityRetreat>.03m || PowerRandom>.05m || WipeXp!=0m) throw new ArgumentException("Approved safety bounds violated.");
            foreach(var p in c.RankIndices) if(string.IsNullOrWhiteSpace(p.Key)||p.Value<0) throw new ArgumentException("Invalid rank mapping.");
            foreach(var p in c.DangerFactors) if(string.IsNullOrWhiteSpace(p.Key)||p.Value<=0m) throw new ArgumentException("Invalid danger mapping.");
            return c;
        }
        internal string Fingerprint()
        {
            var parts=new List<string>(); var fields=typeof(QuestSimulationRules).GetFields(BindingFlags.Public|BindingFlags.Instance);
            Array.Sort(fields,(a,b)=>string.CompareOrdinal(a.Name,b.Name));
            foreach(var f in fields)
                if(f.FieldType==typeof(decimal) || f.FieldType==typeof(string)) {parts.Add(f.Name);parts.Add(Convert.ToString(f.GetValue(this),CultureInfo.InvariantCulture));}
            var keys=new List<string>(RankIndices.Keys);keys.Sort(StringComparer.Ordinal);
            foreach(var k in keys){parts.Add("rank");parts.Add(k);parts.Add(RankIndices[k].ToString(CultureInfo.InvariantCulture));}
            keys=new List<string>(DangerFactors.Keys);keys.Sort(StringComparer.Ordinal);
            foreach(var k in keys){parts.Add("danger");parts.Add(k);parts.Add(DangerFactors[k].ToString(CultureInfo.InvariantCulture));}
            return QuestSimulationRandom.Hash(parts.ToArray());
        }
        internal decimal RankPower(string rank)
        {
            if(!RankIndices.TryGetValue(rank,out var index)) throw new ArgumentException("Unmapped rank: "+rank);
            decimal p=1m;for(var i=0;i<index;i++) p=checked(p*RankFactor);return p;
        }
        internal decimal Danger(string label)
        { if(!DangerFactors.TryGetValue(label,out var f)) throw new ArgumentException("Unmapped danger: "+label);return f; }
        public static decimal Clamp(decimal n,decimal min,decimal max)=>Math.Max(min,Math.Min(max,n));
    }
}

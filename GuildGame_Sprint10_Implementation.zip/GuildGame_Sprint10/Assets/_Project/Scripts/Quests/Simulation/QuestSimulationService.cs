using System;
using System.Collections.Generic;
using System.Globalization;
namespace GuildGame
{
    public sealed class QuestSimulationService
    {
        private readonly QuestSimulationRules r;
        private readonly IQuestSimulationRandom testRandom;
        public long Seed { get; }
        public QuestSimulationService(QuestSimulationRules rules = null,long seed = 0)
            :this(rules??new QuestSimulationRules(),seed,null){}
        internal QuestSimulationService(QuestSimulationRules rules,long seed,IQuestSimulationRandom testRandom)
        {r=rules.Freeze();Seed=seed;this.testRandom=testRandom;}
        public QuestSimulationResult Simulate(QuestSimulationInput input)
        {
            if(input==null || input.Quest.Status!=QuestStatus.CompletedPendingResolution)throw new ArgumentException("Pending input required.");
            var rng=testRandom??new QuestSimulationRandom(Seed,input.Quest.QuestInstanceId,r.Version);
            Func<string,decimal> u=domain=>{var v=rng.Unit(domain);if(v<0m||v>=1m)throw new ArgumentOutOfRangeException("random");return v;};
            var n=input.Members.Count;var d=input.Quest.DefinitionSnapshot;
            decimal power=0m,bold=0m,leader=0m;AdventurerRole roles=AdventurerRole.None;
            foreach(var m in input.Members)
            {
                var a=m.Adventurer;power=checked(power+r.BasePower*(1m+r.LevelStep*(a.Level-1))*r.RankPower(a.Rank));roles|=m.Roles;
                bold+=a.PersonalityBoldness;if(a.Id==input.Party.LeaderId)leader=a.LeadershipQuality;
            }
            power*=1m+((roles&AdventurerRole.Tank)!=0?r.TankBonus:0m)+((roles&AdventurerRole.Healing)!=0?r.HealingBonus:0m)+((roles&AdventurerRole.Damage)!=0?r.DamageBonus:0m);
            var difficulty=checked(r.BasePower*d.RecommendedPartySize*r.RankPower(d.Rank)*r.Danger(d.DangerLabel));
            var ratio=power/difficulty*(1m+r.PowerRandom*(2m*u("power")-1m));
            var h=QuestSimulationRules.Clamp((1m-ratio)/r.OverloadScale,0m,1m);
            bold=QuestSimulationRules.Clamp(bold/n,-1m,1m);
            var pr=QuestSimulationRules.Clamp(h*(r.RetreatBase+r.LeaderRetreat*leader-r.PersonalityRetreat*bold),0m,r.RetreatMax);
            var ps=QuestSimulationRules.Clamp(r.SuccessBase+r.SuccessSlope*ratio,r.SuccessMin,r.SuccessMax);
            var retreat=u("retreat")<pr;var success=!retreat && u("objective")<ps;
            var pk=QuestSimulationRules.Clamp(r.IncapSlope*(1m-ratio),0m,r.IncapMax)*(retreat?r.RetreatIncap:1m);
            var pi=QuestSimulationRules.Clamp(r.InjuryBase+r.InjurySlope*(1m-ratio),0m,r.InjuryMax)*(retreat?r.RetreatInjury:1m);
            var incap=new bool[n];var stabilized=new bool[n];var dead=new bool[n];var injured=new bool[n];
            var targets=new Queue<int>();var healers=new Queue<int>();
            for(var i=0;i<n;i++)
            {
                incap[i]=u("incapacitation/"+input.Members[i].Adventurer.Id)<pk;
                if(incap[i])targets.Enqueue(i);
                else if((input.Members[i].Roles&AdventurerRole.Healing)!=0)healers.Enqueue(i);
            }
            var collapse=targets.Count==n;
            while(targets.Count>0 && healers.Count>0)
            {
                var t=targets.Dequeue();var healer=healers.Dequeue();
                stabilized[t]=u("stabilization/"+input.Members[healer].Adventurer.Id+"/"+input.Members[t].Adventurer.Id)<r.StabilizeChance;
            }
            var pd=QuestSimulationRules.Clamp(r.DeathBase+r.DeathOverload*h+(collapse?r.CollapseDeath:0m),0m,r.DeathMax);
            var deadCount=0;
            for(var i=0;i<n;i++)
            {
                var id=input.Members[i].Adventurer.Id;
                dead[i]=incap[i] && !stabilized[i] && u("death/"+id)<pd;
                if(dead[i])deadCount++;
                injured[i]=!dead[i] && (incap[i] || u("injury/"+id)<pi);
            }
            var wipe=deadCount==n;
            var factor=wipe?r.WipeXp:success?r.SuccessXp:retreat?r.RetreatXp:r.FailureXp;
            var xp=checked((long)decimal.Floor(d.XpReward*factor/n));
            var gold=success&&!wipe?(long)d.GoldReward:0L;
            var ruleHash=r.Fingerprint();
            var resolutionId=QuestSimulationRandom.Hash("resolution",input.Quest.QuestInstanceId,input.Fingerprint,ruleHash,Seed.ToString(CultureInfo.InvariantCulture));
            var outcomes=new List<QuestMemberOutcome>();
            for(var i=0;i<n;i++)
            {
                var id=input.Members[i].Adventurer.Id;
                var seconds=injured[i]?(int)decimal.Ceiling(QuestSimulationRules.Clamp(r.RecoveryBase+r.RecoveryOverload*h+(incap[i]?r.RecoveryIncap:0m),r.RecoveryMin,r.RecoveryMax)):0;
                long? until=injured[i]?(long?)checked(input.Quest.CompletionTimestamp.Value+checked(seconds*1000L)):null;
                outcomes.Add(new QuestMemberOutcome(id,incap[i],stabilized[i],dead[i],seconds,until,dead[i]?0:xp,resolutionId+"/xp/"+id));
            }
            var lootOut=new List<QuestLootOutput>();
            if(success&&!wipe)
            {
                var occurrences=new Dictionary<string,int>(StringComparer.Ordinal);
                var loot=new List<QuestLootContract>(d.PossibleLoot);
                loot.Sort((a,b)=>{var c=string.CompareOrdinal(a.ItemDefinitionId,b.ItemDefinitionId);if(c!=0)return c;c=a.MinimumQuantity.CompareTo(b.MinimumQuantity);return c!=0?c:a.MaximumQuantity.CompareTo(b.MaximumQuantity);});
                foreach(var item in loot)
                {
                    var key=QuestSimulationRandom.Hash(item.ItemDefinitionId,item.MinimumQuantity.ToString(CultureInfo.InvariantCulture),item.MaximumQuantity.ToString(CultureInfo.InvariantCulture));
                    occurrences.TryGetValue(key,out var ordinal);occurrences[key]=ordinal+1;key+="/"+ordinal.ToString(CultureInfo.InvariantCulture);
                    if(item.MaximumQuantity==0 || u("loot/"+key+"/drop")>=r.LootChance)continue;
                    var min=Math.Max(1,item.MinimumQuantity);var width=(long)item.MaximumQuantity-min+1;
                    var qty=checked(min+(int)decimal.Floor(u("loot/"+key+"/quantity")*width));
                    lootOut.Add(new QuestLootOutput(resolutionId+"/loot/"+key,item.ItemDefinitionId,qty));
                }
            }
            return new QuestSimulationResult(input,resolutionId,r.Version,ruleHash,Seed,power,difficulty,ratio,h,pr,ps,success,retreat,wipe,gold,outcomes,lootOut);
        }
    }
}

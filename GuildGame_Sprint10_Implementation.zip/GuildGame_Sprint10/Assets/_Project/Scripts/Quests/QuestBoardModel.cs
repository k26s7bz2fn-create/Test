using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class QuestBoardModel
    {
        public IReadOnlyList<QuestRuntimeState> Quests { get; }
        public int OccupiedSlotCount { get; }
        public int MaximumActiveGroups => QuestActivityRegistry.MaximumActiveGroups;
        public long? AsOfTimestamp { get; }
        internal QuestBoardModel(IReadOnlyList<QuestRuntimeState> quests, int occupied, long? observed)
        {
            Quests = Array.AsReadOnly(new List<QuestRuntimeState>(quests).ToArray());
            OccupiedSlotCount = occupied; AsOfTimestamp = observed;
        }
    }
}

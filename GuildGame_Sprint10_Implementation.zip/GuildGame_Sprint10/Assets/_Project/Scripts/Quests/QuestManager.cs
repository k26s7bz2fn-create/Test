using System;
using System.Collections.Generic;

namespace GuildGame
{
    /// <summary>
    /// Synchronous owning-game-thread commands. Clock callbacks must be read-only.
    /// Resolution publishes consequences and quest state together. No save/reward application.
    /// </summary>
    public sealed class QuestManager
    {
        private readonly AdventurerManager adventurers;
        private readonly PartyManager parties;
        private readonly QuestCatalog catalog;
        private readonly QuestActivityRegistry registry;
        private readonly IQuestClock clock;
        private readonly QuestSimulationService simulation;
        private bool resolving;

        public QuestManager(AdventurerManager adventurers, PartyManager parties, QuestCatalog catalog,
            QuestActivityRegistry registry, IQuestClock clock, QuestSimulationService simulation = null)
        {
            this.adventurers = adventurers ?? throw new ArgumentNullException(nameof(adventurers));
            this.parties = parties ?? throw new ArgumentNullException(nameof(parties));
            this.catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
            this.registry = registry ?? throw new ArgumentNullException(nameof(registry));
            this.clock = clock ?? throw new ArgumentNullException(nameof(clock));
            if (!parties.UsesDependencies(adventurers, registry))
                throw new ArgumentException("PartyManager must use the same AdventurerManager and QuestActivityRegistry.", nameof(parties));
            this.simulation = simulation ?? new QuestSimulationService();
            registry.Attach(this, adventurers);
        }

        public QuestResult TryRegisterOffer(string instanceId, string definitionId)
        {
            if (!PartyManager.NormalizeId(instanceId, out var id)) return new QuestResult(QuestResultCode.InvalidQuestInstanceId);
            if (registry.TryGet(id, out _)) return new QuestResult(QuestResultCode.DuplicateQuestInstance);
            if (!catalog.TryGet(definitionId, out var definition)) return new QuestResult(QuestResultCode.UnknownDefinition);
            var state = QuestRuntimeState.Available(id, definition);
            var next = registry.CopyStates(); next.Add(id, state);
            registry.Publish(this, next, registry.ObservedTimestamp);
            return new QuestResult(QuestResultCode.Success, state);
        }

        private QuestResultCode ReadTime(out long now)
        {
            now = 0;
            try { now = clock.UtcNowMilliseconds; }
            catch { return QuestResultCode.ClockUnavailable; }
            return now < 0 ? QuestResultCode.InvalidTimestamp : QuestResultCode.Success;
        }

        public QuestResult RefreshTime()
        {
            var status = ReadTime(out var now);
            if (status != QuestResultCode.Success) return new QuestResult(status);
            RefreshAt(now);
            return new QuestResult(QuestResultCode.Success);
        }

        private void RefreshAt(long now)
        {
            var next = registry.CopyStates();
            foreach (var q in registry.GetSnapshot())
                if (q.Status == QuestStatus.Active && q.CompletionTimestamp.HasValue && now >= q.CompletionTimestamp.Value)
                    next[q.QuestInstanceId] = q.MarkPending();
            registry.Publish(this, next, now);
        }

        private QuestResultCode ValidateStart(string instanceId, string partyId, long now,
            out QuestRuntimeState quest, out PartyState party, out long completion)
        {
            quest = null; party = null; completion = 0;
            if (!PartyManager.NormalizeId(instanceId, out var questId)) return QuestResultCode.InvalidQuestInstanceId;
            if (!registry.TryGet(questId, out quest)) return QuestResultCode.UnknownQuest;
            if (quest.Status != QuestStatus.Available) return QuestResultCode.QuestNotAvailable;
            if (!PartyManager.NormalizeId(partyId, out var groupId)) return QuestResultCode.InvalidPartyId;
            if (!parties.TryGetParty(groupId, out party)) return QuestResultCode.UnknownParty;
            if (!parties.ValidateComposition(groupId).Success || party.MemberCount < PartyState.MinimumMembers || party.MemberCount > PartyState.MaximumMembers)
                return QuestResultCode.InvalidPartyComposition;
            foreach (var id in party.MemberIds)
            {
                if (!adventurers.TryGetById(id, out var member)) return QuestResultCode.UnknownAdventurer;
                if (!member.CanDeployAt(now)) return QuestResultCode.AdventurerUnavailable;
            }
            var reservation = registry.ValidateReservation(party);
            if (reservation != QuestResultCode.Success) return reservation;
            if (now < 0) return QuestResultCode.InvalidTimestamp;
            try { completion = checked(now + checked(quest.DefinitionSnapshot.ExpectedDurationSeconds * 1000L)); }
            catch (OverflowException) { return QuestResultCode.TimestampOverflow; }
            return QuestResultCode.Success;
        }

        public QuestResult TryStartQuest(string instanceId, string partyId)
        {
            // Read clock once, before snapshots/validation; no external callbacks after validation.
            var status = ReadTime(out var now);
            if (status != QuestResultCode.Success) return new QuestResult(status);
            status = ValidateStart(instanceId, partyId, now, out var quest, out var party, out var completion);
            if (status != QuestResultCode.Success) return new QuestResult(status);
            var before=registry.Capture();
            try
            {
                var equipment=new AutoEquipService().Prepare(before,party.MemberIds,adventurers);
                var potions=new HealingPotionAssignmentService().Prepare(equipment.Snapshot,party,now,adventurers);
                var active=quest.Start(party,now,completion);
                var states=new Dictionary<string,QuestRuntimeState>(potions.Snapshot.Quests,StringComparer.Ordinal);states[active.QuestInstanceId]=active;
                // Time transitions are staged too: failed preparation publishes nothing.
                foreach(var q in potions.Snapshot.Quests.Values)
                    if(q.Status==QuestStatus.Active&&q.CompletionTimestamp.HasValue&&now>=q.CompletionTimestamp.Value)
                        states[q.QuestInstanceId]=q.MarkPending();
                var next=potions.Snapshot.WithQuests(potions.Snapshot.Members,states,now);
                if(!registry.TryPublishResolution(this,before,next))return new QuestResult(QuestResultCode.PreparationConflict);
                return new QuestResult(QuestResultCode.Success,active,potionShortages:potions.Changes.PotionShortageMemberIds);
            }
            catch(EquipmentRejected ex){return new QuestResult(QuestResultCode.EquipmentPreparationFailed,equipmentError:ex.Code);}
            catch(OverflowException){return new QuestResult(QuestResultCode.EquipmentPreparationFailed,equipmentError:EquipmentCode.NumericOverflow);}
            catch(Exception){return new QuestResult(QuestResultCode.EquipmentPreparationFailed,equipmentError:EquipmentCode.PreparationFailed);}
        }

        /// <summary>Owning game thread only. No user callbacks or mutations between staging and publication.</summary>
        public QuestResolutionResult TryResolveQuest(string instanceId)
        {
            if (resolving) return new QuestResolutionResult(QuestResolutionCode.Busy);
            if (!PartyManager.NormalizeId(instanceId, out var id))
                return new QuestResolutionResult(QuestResolutionCode.InvalidQuestId);
            if (!registry.TryGet(id, out var quest)) return new QuestResolutionResult(QuestResolutionCode.UnknownQuest);
            if (quest.Status == QuestStatus.Resolved)
                return new QuestResolutionResult(QuestResolutionCode.AlreadyResolved, quest.SimulationResult);
            if (quest.Status != QuestStatus.CompletedPendingResolution)
                return new QuestResolutionResult(QuestResolutionCode.NotPending);
            resolving = true;
            try
            {
                var before = registry.Capture();
                if (!parties.TryGetParty(quest.AssignedPartyId, out var party))
                    return new QuestResolutionResult(QuestResolutionCode.InvalidInput);
                var inputs = new List<QuestSimulationMember>();
                foreach (var memberId in quest.MemberIdsAtStart)
                {
                    if (!adventurers.TryGetById(memberId, out var member) || !adventurers.TryGetClass(member.ClassId, out var definition))
                        return new QuestResolutionResult(QuestResolutionCode.InvalidInput);
                    inputs.Add(new QuestSimulationMember(member, definition.Roles));
                }
                var input = new QuestSimulationInput(quest, party, inputs);
                var result = simulation.Simulate(input);
                // Defensive conflict check; pure production simulation cannot modify these roots.
                if (!ReferenceEquals(before, registry.Capture()) ||
                    !parties.TryGetParty(party.PartyId, out var currentParty) || !ReferenceEquals(party, currentParty))
                    return new QuestResolutionResult(QuestResolutionCode.StaleState);
                var consequences = new Dictionary<string, QuestMemberOutcome>(StringComparer.Ordinal);
                foreach (var outcome in result.MemberResults) consequences.Add(outcome.AdventurerId, outcome);
                var members = new List<AdventurerState>();
                foreach (var member in before.Members)
                    members.Add(consequences.TryGetValue(member.Id, out var consequence)
                        ? member.WithQuestConsequences(consequence.IsDead, consequence.RecoveryUntil) : member);
                var quests = new Dictionary<string, QuestRuntimeState>(before.Quests, StringComparer.Ordinal);
                quests[id] = quest.Resolve(result);
                var staged = before.WithQuests(members, quests, before.ObservedTimestamp);
                var returned=EquipmentManager.PrepareReturns(staged,quest.MemberIdsAtStart,true,true,true);
                var next = returned.Snapshot;
                // Locks/slots are derived from this same root. No release occurs on any failure path.
                if (!registry.TryPublishResolution(this, before, next))
                    return new QuestResolutionResult(QuestResolutionCode.StaleState);
                return new QuestResolutionResult(QuestResolutionCode.Success, result);
            }
            catch (EquipmentRejected) { return new QuestResolutionResult(QuestResolutionCode.EquipmentReturnFailed); }
            catch (OverflowException) { return new QuestResolutionResult(QuestResolutionCode.NumericOverflow); }
            catch (ArgumentException) { return new QuestResolutionResult(QuestResolutionCode.InvalidInputOrRules); }
            catch (Exception) { return new QuestResolutionResult(QuestResolutionCode.SimulationFailed); }
            finally { resolving = false; }
        }

        public bool TryGetQuest(string instanceId, out QuestRuntimeState state) => registry.TryGet(instanceId, out state);
        public QuestBoardModel GetBoardModel() => new QuestBoardModel(registry.GetSnapshot(), registry.OccupiedSlotCount, registry.ObservedTimestamp);

        public QuestPanelModel GetPanelModel(string instanceId)
        {
            var options = new System.Collections.Generic.List<QuestPanelModel.PartyOption>();
            QuestRuntimeState quest = null;
            var selection = !PartyManager.NormalizeId(instanceId, out var id) ? QuestResultCode.InvalidQuestInstanceId
                : !registry.TryGet(id, out quest) ? QuestResultCode.UnknownQuest : QuestResultCode.Success;
            if (selection == QuestResultCode.Success)
                foreach (var party in parties.GetPartiesSnapshot())
                {
                    var startCode = registry.ObservedTimestamp.HasValue
                        ? ValidateStart(id, party.PartyId, registry.ObservedTimestamp.Value, out _, out _, out _)
                        : QuestResultCode.InvalidTimestamp;
                    options.Add(new QuestPanelModel.PartyOption(party, startCode));
                }
            return new QuestPanelModel(quest, selection, options, registry.OccupiedSlotCount, registry.ObservedTimestamp);
        }
    }
}

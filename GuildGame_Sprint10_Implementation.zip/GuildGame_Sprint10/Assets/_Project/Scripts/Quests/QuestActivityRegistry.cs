using System;
using System.Collections.Generic;

namespace GuildGame
{
    /// <summary>One authoritative quest store; locks are derived, never maintained separately.</summary>
    public sealed class QuestActivityRegistry : IPartyEditPolicy
    {
        public const int MaximumActiveGroups = 3;
        private GuildRuntimeStore store;
        private QuestManager owner;
        private GuildRuntimeSnapshot Current => store == null ? empty : store.Current;
        private readonly GuildRuntimeSnapshot empty = new GuildRuntimeSnapshot(Array.Empty<AdventurerState>(),
            new Dictionary<string,QuestRuntimeState>(StringComparer.Ordinal),null);
        public long? ObservedTimestamp => Current.ObservedTimestamp;
        public int OccupiedSlotCount
        {
            get { var count = 0; foreach (var q in Current.Quests.Values) if (q.OccupiesActiveSlot) count++; return count; }
        }
        internal void Attach(QuestManager manager, AdventurerManager adventurers)
        {
            if (owner != null) throw new InvalidOperationException("Registry already has an authoritative QuestManager.");
            if(manager == null) throw new ArgumentNullException(nameof(manager));
            adventurers.RuntimeStore.BindQuestRegistry(this);
            store=adventurers.RuntimeStore;
            owner = manager;
        }
        internal Dictionary<string, QuestRuntimeState> CopyStates() =>
            new Dictionary<string, QuestRuntimeState>(Current.Quests, StringComparer.Ordinal);
        internal void Publish(QuestManager writer, Dictionary<string, QuestRuntimeState> states, long? observed)
        {
            if (!ReferenceEquals(writer, owner)) throw new InvalidOperationException("Unknown registry writer.");
            var before=store.Current;
            if(!store.TryPublish(before,before.WithQuests(before.Members,states,observed)))
                throw new InvalidOperationException("Stale quest publication.");
        }
        internal GuildRuntimeSnapshot Capture() => store.Current;
        internal bool TryPublishResolution(QuestManager writer, GuildRuntimeSnapshot expected, GuildRuntimeSnapshot next)
        {
            if(!ReferenceEquals(writer,owner)) throw new InvalidOperationException("Unknown registry writer.");
            return store.TryPublish(expected,next);
        }
        public bool TryGet(string questId, out QuestRuntimeState state)
        {
            state = null;
            return PartyManager.NormalizeId(questId, out var id) && Current.Quests.TryGetValue(id, out state);
        }
        public IReadOnlyList<QuestRuntimeState> GetSnapshot()
        {
            var list = new List<QuestRuntimeState>(Current.Quests.Values);
            list.Sort((a,b) => string.CompareOrdinal(a.QuestInstanceId,b.QuestInstanceId));
            return Array.AsReadOnly(list.ToArray());
        }
        public bool IsPartyCommitted(string partyId)
        {
            if (!PartyManager.NormalizeId(partyId, out var id)) return false;
            foreach (var q in Current.Quests.Values)
                if (q.OccupiesActiveSlot && q.AssignedPartyId == id) return true;
            return false;
        }
        public bool IsMemberCommitted(string memberId)
        {
            if (!PartyManager.NormalizeId(memberId, out var id)) return false;
            foreach (var q in Current.Quests.Values)
                if (q.OccupiesActiveSlot)
                    foreach (var member in q.MemberIdsAtStart) if (member == id) return true;
            return false;
        }
        public bool CanEdit(string partyId) => PartyManager.NormalizeId(partyId, out _) && !IsPartyCommitted(partyId);

        internal QuestResultCode ValidateReservation(PartyState party)
        {
            if (IsPartyCommitted(party.PartyId)) return QuestResultCode.PartyAlreadyCommitted;
            foreach (var member in party.MemberIds)
                if (IsMemberCommitted(member)) return QuestResultCode.MemberAlreadyCommitted;
            return OccupiedSlotCount >= MaximumActiveGroups ? QuestResultCode.ActiveQuestLimitReached : QuestResultCode.Success;
        }
    }
}

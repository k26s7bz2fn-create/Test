using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class QuestRuntimeState
    {
        public QuestSimulationResult SimulationResult { get; }
        public string QuestInstanceId { get; }
        public string DefinitionId => DefinitionSnapshot.DefinitionId;
        public QuestDefinitionData DefinitionSnapshot { get; }
        public QuestStatus Status { get; }
        public string AssignedPartyId { get; }
        public IReadOnlyList<string> MemberIdsAtStart { get; }
        public string LeaderIdAtStart { get; }
        public long? StartTimestamp { get; }
        public long? CompletionTimestamp { get; }
        public bool OccupiesActiveSlot => Status == QuestStatus.Active || Status == QuestStatus.CompletedPendingResolution;

        private QuestRuntimeState(string id, QuestDefinitionData definition, QuestStatus status, string partyId,
            IEnumerable<string> members, string leaderId, long? start, long? completion, QuestSimulationResult result = null)
        {
            SimulationResult = result;
            QuestInstanceId = id; DefinitionSnapshot = definition; Status = status; AssignedPartyId = partyId;
            MemberIdsAtStart = Array.AsReadOnly(new List<string>(members).ToArray());
            LeaderIdAtStart = leaderId; StartTimestamp = start; CompletionTimestamp = completion;
        }
        internal static QuestRuntimeState Available(string id, QuestDefinitionData definition) =>
            new QuestRuntimeState(id, definition, QuestStatus.Available, null, Array.Empty<string>(), null, null, null);

        internal QuestRuntimeState Start(PartyState party, long start, long completion)
        {
            if (Status != QuestStatus.Available || completion <= start) throw new InvalidOperationException("Invalid start transition.");
            return new QuestRuntimeState(QuestInstanceId, DefinitionSnapshot, QuestStatus.Active, party.PartyId,
                party.MemberIds, party.LeaderId, start, completion);
        }
        internal QuestRuntimeState MarkPending()
        {
            if (Status != QuestStatus.Active) throw new InvalidOperationException("Only active quests become pending.");
            return new QuestRuntimeState(QuestInstanceId, DefinitionSnapshot, QuestStatus.CompletedPendingResolution,
                AssignedPartyId, MemberIdsAtStart, LeaderIdAtStart, StartTimestamp, CompletionTimestamp);
        }
        internal QuestRuntimeState Resolve(QuestSimulationResult result)
        {
            if(Status != QuestStatus.CompletedPendingResolution || result == null || result.QuestInstanceId != QuestInstanceId)
                throw new InvalidOperationException("Invalid resolution transition.");
            return new QuestRuntimeState(QuestInstanceId,DefinitionSnapshot,QuestStatus.Resolved,AssignedPartyId,
                MemberIdsAtStart,LeaderIdAtStart,StartTimestamp,CompletionTimestamp,result);
        }
    }
}

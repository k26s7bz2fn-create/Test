using System;
using System.Collections.Generic;

namespace GuildGame
{
    /// <summary>Validated immutable definition snapshot. Rank/danger are descriptive, not invented gates.</summary>
    public sealed class QuestDefinitionData
    {
        public string DefinitionId { get; }
        public string DisplayName { get; }
        public QuestType Type { get; }
        public string Rank { get; }
        public QuestDistance Distance { get; }
        public long ExpectedDurationSeconds { get; }
        public int RecommendedPartySize { get; }
        public string DangerLabel { get; }
        public int GoldReward { get; }
        public int XpReward { get; }
        public IReadOnlyList<QuestLootContract> PossibleLoot { get; }

        private QuestDefinitionData(string id, string name, QuestType type, string rank, QuestDistance distance,
            long duration, int size, string danger, int gold, int xp, List<QuestLootContract> loot)
        {
            DefinitionId = id; DisplayName = name; Type = type; Rank = rank; Distance = distance;
            ExpectedDurationSeconds = duration; RecommendedPartySize = size; DangerLabel = danger;
            GoldReward = gold; XpReward = xp; PossibleLoot = Array.AsReadOnly(loot.ToArray());
        }

        public static bool TryCreate(string id, string name, QuestType type, string rank, QuestDistance distance,
            long durationSeconds, int recommendedSize, string danger, int gold, int xp,
            IReadOnlyList<QuestLootContract> possibleLoot, out QuestDefinitionData data, out string error)
        {
            data = null; error = string.Empty;
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(rank) || string.IsNullOrWhiteSpace(danger))
            { error = "Definition ID, name, rank and danger label are required."; return false; }
            if (!Enum.IsDefined(typeof(QuestType), type) || !Enum.IsDefined(typeof(QuestDistance), distance))
            { error = "Unknown quest type or distance."; return false; }
            if (durationSeconds <= 0 || recommendedSize < 1 || recommendedSize > 6 || gold < 0 || xp < 0)
            { error = "Invalid duration, recommendation or reward value."; return false; }
            if (possibleLoot == null) { error = "Loot list is required (empty is allowed)."; return false; }
            var copy = new List<QuestLootContract>(possibleLoot);
            foreach (var item in copy)
                if (item == null) { error = "Null loot entry."; return false; }
            data = new QuestDefinitionData(id.Trim(), name.Trim(), type, rank.Trim(), distance, durationSeconds,
                recommendedSize, danger.Trim(), gold, xp, copy);
            return true;
        }
    }

    public sealed class QuestCatalog
    {
        private readonly Dictionary<string, QuestDefinitionData> byId;
        public IReadOnlyList<QuestDefinitionData> Definitions { get; }
        private QuestCatalog(Dictionary<string, QuestDefinitionData> definitions)
        {
            byId = definitions;
            var ordered = new List<QuestDefinitionData>(definitions.Values);
            ordered.Sort((a,b) => string.CompareOrdinal(a.DefinitionId,b.DefinitionId));
            Definitions = Array.AsReadOnly(ordered.ToArray());
        }
        public static bool TryCreate(IReadOnlyList<QuestDefinitionData> definitions, out QuestCatalog catalog, out string error)
        {
            catalog = null; error = string.Empty;
            if (definitions == null) { error = "Definitions required."; return false; }
            var map = new Dictionary<string, QuestDefinitionData>(StringComparer.Ordinal);
            foreach (var item in definitions)
            {
                if (item == null || map.ContainsKey(item.DefinitionId)) { error = "Null or duplicate definition."; return false; }
                map.Add(item.DefinitionId, item);
            }
            catalog = new QuestCatalog(map); return true;
        }
        public bool TryGet(string id, out QuestDefinitionData data)
        {
            data = null;
            return !string.IsNullOrWhiteSpace(id) && byId.TryGetValue(id.Trim(), out data);
        }
    }
}

namespace GuildGame
{
    public enum QuestType { Gathering = 0, Delivery = 1, MonsterHunt = 2, Rescue = 3 }
}

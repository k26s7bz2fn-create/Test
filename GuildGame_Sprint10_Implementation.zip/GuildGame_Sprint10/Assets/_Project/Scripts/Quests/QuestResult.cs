namespace GuildGame
{
    public enum QuestResultCode
    {
        Success = 0, UnknownDefinition, InvalidQuestInstanceId, DuplicateQuestInstance, UnknownQuest,
        QuestNotAvailable, InvalidPartyId, UnknownParty, InvalidPartyComposition, UnknownAdventurer,
        PartyAlreadyCommitted, MemberAlreadyCommitted, ActiveQuestLimitReached,
        InvalidTimestamp, TimestampOverflow, ClockUnavailable, AdventurerUnavailable, EquipmentPreparationFailed, PreparationConflict
    }
    public sealed class QuestResult
    {
        public QuestResultCode StatusCode { get; }
        public bool Success => StatusCode == QuestResultCode.Success;
        public string Message { get; }
        public QuestRuntimeState State { get; }
        public EquipmentCode? EquipmentError { get; }
        public System.Collections.Generic.IReadOnlyList<string> PotionShortages { get; }
        internal QuestResult(QuestResultCode status, QuestRuntimeState state = null,EquipmentCode? equipmentError=null,System.Collections.Generic.IReadOnlyList<string> potionShortages=null)
        { EquipmentError=equipmentError;PotionShortages=System.Array.AsReadOnly(potionShortages==null?System.Array.Empty<string>():new System.Collections.Generic.List<string>(potionShortages).ToArray());StatusCode = status; State = state; Message = Success ? string.Empty : status.ToString(); }
    }
}

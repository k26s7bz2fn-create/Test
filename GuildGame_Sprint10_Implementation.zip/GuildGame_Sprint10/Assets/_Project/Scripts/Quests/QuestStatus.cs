namespace GuildGame
{
    // Resolved is reserved for a later resolution service. Sprint 6 has no transition to it.
    public enum QuestStatus { Available = 0, Active = 1, CompletedPendingResolution = 2, Resolved = 3 }
}

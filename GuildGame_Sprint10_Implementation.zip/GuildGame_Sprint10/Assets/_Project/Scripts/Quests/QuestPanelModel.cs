using System;
using System.Collections.Generic;

namespace GuildGame
{
    public sealed class QuestPanelModel
    {
        public sealed class PartyOption
        {
            public PartyState Party { get; }
            public QuestResultCode StartStatus { get; }
            public bool CanStart => StartStatus == QuestResultCode.Success;
            internal PartyOption(PartyState party, QuestResultCode status) { Party = party; StartStatus = status; }
        }
        public QuestRuntimeState Quest { get; }
        public QuestResultCode SelectionStatus { get; }
        public IReadOnlyList<PartyOption> Parties { get; }
        public long? AsOfTimestamp { get; }
        public long? RemainingMilliseconds { get; }
        public bool AwaitingResolution => Quest != null && Quest.Status == QuestStatus.CompletedPendingResolution;
        public int OccupiedSlotCount { get; }
        public int MaximumActiveGroups => QuestActivityRegistry.MaximumActiveGroups;

        internal QuestPanelModel(QuestRuntimeState quest, QuestResultCode selection, List<PartyOption> parties, int occupied, long? now)
        {
            Quest = quest; SelectionStatus = selection; Parties = Array.AsReadOnly(parties.ToArray());
            OccupiedSlotCount = occupied; AsOfTimestamp = now;
            if (quest != null && quest.CompletionTimestamp.HasValue && now.HasValue)
            {
                if (quest.Status == QuestStatus.Resolved || quest.Status == QuestStatus.CompletedPendingResolution || now.Value >= quest.CompletionTimestamp.Value)
                    RemainingMilliseconds = 0;
                else if (now.Value < quest.StartTimestamp.Value)
                    RemainingMilliseconds = quest.CompletionTimestamp.Value - quest.StartTimestamp.Value;
                else RemainingMilliseconds = quest.CompletionTimestamp.Value - now.Value;
            }
        }
    }
}

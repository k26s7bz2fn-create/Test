using System;

namespace GuildGame
{
    /// <summary>Read-only UTC milliseconds; implementations must not call back into game commands.</summary>
    public interface IQuestClock { long UtcNowMilliseconds { get; } }
    public sealed class SystemQuestClock : IQuestClock
    {
        public long UtcNowMilliseconds => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
    }
}

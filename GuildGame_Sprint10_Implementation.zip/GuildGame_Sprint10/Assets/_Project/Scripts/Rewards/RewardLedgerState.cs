using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class RewardLedgerState
    {
        private readonly Dictionary<string,RewardApplicationReceipt> quests;
        private readonly HashSet<string> resolutions,outputs;
        public static RewardLedgerState Empty { get; }=new RewardLedgerState(new Dictionary<string,RewardApplicationReceipt>(),new HashSet<string>(),new HashSet<string>());
        private RewardLedgerState(Dictionary<string,RewardApplicationReceipt> q,HashSet<string> r,HashSet<string> o){quests=q;resolutions=r;outputs=o;}
        public int Count => quests.Count;
        public bool TryGet(string questId,out RewardApplicationReceipt receipt){receipt=null;return questId!=null&&quests.TryGetValue(questId,out receipt);}
        internal bool HasResolution(string id)=>resolutions.Contains(id);
        internal bool HasOutput(string id)=>outputs.Contains(id);
        internal RewardLedgerState Add(RewardApplicationReceipt receipt,IEnumerable<string> outputIds)
        {
            var q=new Dictionary<string,RewardApplicationReceipt>(quests,StringComparer.Ordinal);
            var r=new HashSet<string>(resolutions,StringComparer.Ordinal);var o=new HashSet<string>(outputs,StringComparer.Ordinal);
            if(q.ContainsKey(receipt.QuestInstanceId)||!r.Add(receipt.ResolutionId))throw new RewardRejectedException(RewardApplicationCode.RewardIdentityConflict);
            foreach(var id in outputIds)if(!o.Add(id))throw new RewardRejectedException(RewardApplicationCode.RewardIdentityConflict);
            q.Add(receipt.QuestInstanceId,receipt);return new RewardLedgerState(q,r,o);
        }
    }
}

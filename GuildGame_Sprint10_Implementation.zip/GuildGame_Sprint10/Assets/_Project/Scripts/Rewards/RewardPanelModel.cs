namespace GuildGame
{
    public sealed class RewardPanelModel
    {
        public QuestSimulationResult Result { get; }
        public RewardApplicationReceipt Receipt { get; }
        public RewardApplicationCode Validation { get; }
        public bool IsApplied => Validation==RewardApplicationCode.AlreadyApplied;
        // Applied means validation succeeded here; reading never publishes a receipt.
        public bool CanApply => Validation==RewardApplicationCode.Applied;
        public bool IsPreview => CanApply && Receipt!=null;
        internal RewardPanelModel(QuestSimulationResult result,RewardApplicationReceipt receipt,RewardApplicationCode validation)
        {Result=result;Receipt=receipt;Validation=validation;}
    }
}

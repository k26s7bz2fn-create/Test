using System;
using System.Collections.Generic;
namespace GuildGame
{
    public sealed class RewardApplicationReceipt
    {
        public string QuestInstanceId => Source.QuestInstanceId;
        public string ResolutionId => Source.ResolutionId;
        public QuestSimulationResult Source { get; }
        public string ProgressionRulesVersion => "s8.progression.v1";
        public string SkillRulesVersion => "s8.skills.v1";
        public IReadOnlyList<ProgressionChange> Members { get; }
        public long GoldBefore { get; }
        public long GoldAfter { get; }
        public long GoldApplied => Source.GoldOutput;
        public IReadOnlyList<QuestLootOutput> LootOutputs { get; }
        public IReadOnlyList<string> CreatedInstanceIds { get; }
        internal RewardApplicationReceipt(QuestSimulationResult source,List<ProgressionChange> members,long before,long after,LootApplicationChange loot)
        {Source=source;Members=Array.AsReadOnly(members.ToArray());GoldBefore=before;GoldAfter=after;LootOutputs=loot.Outputs;CreatedInstanceIds=loot.CreatedInstanceIds;}
    }
}

using System;
using System.Collections.Generic;
namespace GuildGame
{
    /// <summary>Owning game thread only; authoritative source is the roster's shared quest store.</summary>
    public sealed class RewardApplicationManager
    {
        private readonly GuildRuntimeStore store;
        private readonly EquipmentManager equipment;
        private readonly ItemCatalog catalog;
        private readonly ProgressionService progression=new ProgressionService();
        private readonly LootApplicationService loot=new LootApplicationService();
        private bool applying;
        internal Action BeforePublishForTests;
        internal Action BeforeEquipmentForTests;
        public RewardApplicationManager(AdventurerManager adventurers,ItemCatalog catalog=null)
        {store=(adventurers??throw new ArgumentNullException(nameof(adventurers))).RuntimeStore;this.catalog=catalog??ItemCatalog.CreateV01();equipment=new EquipmentManager(adventurers);}
        public GuildEconomyState Economy => store.Current.Economy;
        public GuildStorageState Storage => store.Current.Storage;
        public RewardLedgerState Ledger => store.Current.RewardLedger;

        private RewardApplicationResult Prepare(GuildRuntimeSnapshot before,string questId,out GuildRuntimeSnapshot next)
        {
            next=null;
            if(!PartyManager.NormalizeId(questId,out var id))return new RewardApplicationResult(RewardApplicationCode.InvalidQuestId);
            if(!before.Quests.TryGetValue(id,out var quest))return new RewardApplicationResult(RewardApplicationCode.UnknownQuest);
            if(quest.Status!=QuestStatus.Resolved)return new RewardApplicationResult(RewardApplicationCode.QuestNotResolved);
            var result=quest.SimulationResult;
            if(result==null)return new RewardApplicationResult(RewardApplicationCode.MissingSimulationResult);
            if(result.QuestInstanceId!=id||result.PartyId!=quest.AssignedPartyId||string.IsNullOrWhiteSpace(result.ResolutionId))
                return new RewardApplicationResult(RewardApplicationCode.ResultIdentityMismatch);
            if(before.RewardLedger.TryGet(id,out var old))
                return ReferenceEquals(old.Source,result)?new RewardApplicationResult(RewardApplicationCode.AlreadyApplied,old):new RewardApplicationResult(RewardApplicationCode.RewardIdentityConflict);
            if(before.RewardLedger.HasResolution(result.ResolutionId))return new RewardApplicationResult(RewardApplicationCode.RewardIdentityConflict);
            try
            {
                if(result.GoldOutput<0)throw new RewardRejectedException(RewardApplicationCode.InvalidRewardAmount);
                var outputIds=new HashSet<string>(StringComparer.Ordinal);
                Action<string> addOutput=output=>{
                    if(string.IsNullOrWhiteSpace(output)||!outputIds.Add(output)||before.RewardLedger.HasOutput(output))
                        throw new RewardRejectedException(RewardApplicationCode.RewardIdentityConflict);
                };
                addOutput(result.GoldOutputId);
                var members=new Dictionary<string,AdventurerState>(StringComparer.Ordinal);
                foreach(var a in before.Members)members.Add(a.Id,a);
                var participants=new HashSet<string>(quest.MemberIdsAtStart,StringComparer.Ordinal);
                if(participants.Count!=quest.MemberIdsAtStart.Count)throw new RewardRejectedException(RewardApplicationCode.InvalidRecipientContract);
                var changes=new List<ProgressionChange>();
                foreach(var outcome in result.MemberResults)
                {
                    if(outcome==null||!participants.Remove(outcome.AdventurerId)||outcome.IsDead&&outcome.Xp!=0)
                        throw new RewardRejectedException(RewardApplicationCode.InvalidRecipientContract);
                    if(outcome.Xp<0)throw new RewardRejectedException(RewardApplicationCode.InvalidRewardAmount);
                    addOutput(outcome.XpOutputId);
                    if(!members.TryGetValue(outcome.AdventurerId,out var current))throw new RewardRejectedException(RewardApplicationCode.UnknownRecipient);
                    ProgressionChange change;
                    try{change=progression.Prepare(current,outcome.Xp,outcome.XpOutputId);}
                    catch(ArgumentException){throw new RewardRejectedException(RewardApplicationCode.InvalidSkillAllocation);}
                    changes.Add(change);
                    // P8-12: use CURRENT health, even if death occurred after this receipt was resolved.
                    members[current.Id]=current.WithProgression(change.After);
                }
                if(participants.Count!=0)throw new RewardRejectedException(RewardApplicationCode.InvalidRecipientContract);
                foreach(var output in result.LootOutputs)
                {if(output==null)throw new RewardRejectedException(RewardApplicationCode.InvalidRewardAmount);addOutput(output.OutputId);}
                var economy=before.Economy.Add(result.GoldOutput);
                EquipmentConsistency.Validate(before,false);
                var storage=loot.Prepare(before.Storage,result.LootOutputs,catalog);
                changes.Sort((a,b)=>string.CompareOrdinal(a.AdventurerId,b.AdventurerId));
                var receipt=new RewardApplicationReceipt(result,changes,before.Economy.Gold,economy.Gold,storage);
                var ledger=before.RewardLedger.Add(receipt,outputIds);
                var ordered=new List<AdventurerState>();foreach(var a in before.Members)ordered.Add(members[a.Id]);
                next=before.WithRewards(ordered,economy,storage.After,ledger);
                EquipmentConsistency.Validate(next,false);
                return new RewardApplicationResult(RewardApplicationCode.Applied,receipt);
            }
            catch(EquipmentRejected){return new RewardApplicationResult(RewardApplicationCode.StorageValidationFailed);}
            catch(RewardRejectedException ex){return new RewardApplicationResult(ex.Code);}
            catch(OverflowException){return new RewardApplicationResult(RewardApplicationCode.NumericOverflow);}
            catch(Exception){return new RewardApplicationResult(RewardApplicationCode.PreparationFailed);}
        }
        public RewardApplicationResult TryApply(string questId)
        {
            if(applying)return new RewardApplicationResult(RewardApplicationCode.Busy);
            applying=true;
            try
            {
                var before=store.Current;var prepared=Prepare(before,questId,out var next);
                if(!prepared.HasNewApplication)return prepared;
                BeforePublishForTests?.Invoke();
                if(!store.TryPublish(before,next))return new RewardApplicationResult(RewardApplicationCode.StaleState);
                EquipmentResult post;
                try{BeforeEquipmentForTests?.Invoke();post=equipment.TryReevaluateAll();}
                catch(Exception){post=new EquipmentResult(EquipmentCode.PreparationFailed);}
                return new RewardApplicationResult(prepared.Status,prepared.Receipt,post);
            }
            catch(Exception){return new RewardApplicationResult(RewardApplicationCode.PreparationFailed);}
            finally{applying=false;}
        }
        public RewardPanelModel GetPanelModel(string questId)
        {
            var snapshot=store.Current;var validation=Prepare(snapshot,questId,out _);
            QuestSimulationResult source=null;
            if(PartyManager.NormalizeId(questId,out var id)&&snapshot.Quests.TryGetValue(id,out var q))source=q.SimulationResult;
            return new RewardPanelModel(source,validation.Receipt,validation.Status);
        }
    }
}

using System;
namespace GuildGame
{
    public enum RewardApplicationCode
    {
        Applied, AlreadyApplied, InvalidQuestId, UnknownQuest, QuestNotResolved, MissingSimulationResult,
        ResultIdentityMismatch, RewardIdentityConflict, InvalidRewardAmount, UnknownRecipient,
        InvalidRecipientContract, InvalidProgressionRules, InvalidSkillAllocation, UnknownItemDefinition,
        StorageValidationFailed, NumericOverflow, StaleState, Busy, PreparationFailed
    }
    public sealed class RewardApplicationResult
    {
        public RewardApplicationCode Status { get; }
        public bool HasNewApplication => Status==RewardApplicationCode.Applied;
        public RewardApplicationReceipt Receipt { get; }
        public EquipmentResult EquipmentPostProcessing { get; }
        internal RewardApplicationResult(RewardApplicationCode status,RewardApplicationReceipt receipt=null,EquipmentResult equipmentPostProcessing=null){Status=status;Receipt=receipt;EquipmentPostProcessing=equipmentPostProcessing;}
    }
    internal sealed class RewardRejectedException : Exception
    {
        internal RewardApplicationCode Code { get; }
        internal RewardRejectedException(RewardApplicationCode code):base(code.ToString()){Code=code;}
    }
}

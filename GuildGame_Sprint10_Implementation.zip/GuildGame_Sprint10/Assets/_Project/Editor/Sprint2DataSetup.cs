#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEngine;

namespace GuildGame.Editor
{
    public static class Sprint2DataSetup
    {
        private const string Root = "Assets/_Project/ScriptableObjects/Adventurers";

        [MenuItem("Guild Game/Sprint 2/Create Adventurer Placeholder Data")]
        public static void CreatePlaceholderData()
        {
            EnsureFolder("Assets/_Project", "ScriptableObjects");
            EnsureFolder("Assets/_Project/ScriptableObjects", "Adventurers");

            var warrior = EnsureClass("Class_Warrior.asset", "class.warrior", "Krieger", AdventurerRole.Tank | AdventurerRole.Damage);
            var rogue = EnsureClass("Class_Rogue.asset", "class.rogue", "Schurke", AdventurerRole.Damage);
            var mage = EnsureClass("Class_Mage.asset", "class.mage", "Magier", AdventurerRole.Damage | AdventurerRole.SupportControl);
            var priest = EnsureClass("Class_Priest.asset", "class.priest", "Priester", AdventurerRole.Healing | AdventurerRole.SupportControl);

            var generationPath = Root + "/Generation_Placeholders.asset";
            var existing = AssetDatabase.LoadAssetAtPath<AdventurerGenerationDefinition>(generationPath);
            if (existing != null)
            {
                if (!existing.TryBuildCatalog(out var catalog, out var error) ||
                    catalog.Names.Count != 8 || catalog.Appearances.Count != 3 ||
                    catalog.Names[0] != "Arel" || catalog.Names[7] != "Mira" ||
                    catalog.Appearances[0] != "human.adult.placeholder.01" ||
                    catalog.Appearances[2] != "human.adult.placeholder.03")
                    throw new InvalidOperationException("Existing generation asset conflicts with required Sprint 2 data: " + error);
                Debug.Log("Sprint 2 generation asset already exists and matches the required contract. No overwrite performed.");
                return;
            }

            var generation = ScriptableObject.CreateInstance<AdventurerGenerationDefinition>();
            var so = new SerializedObject(generation);
            so.FindProperty("id").stringValue = AdventurerGenerationDefinition.RequiredId;
            so.FindProperty("displayName").stringValue = "Abenteurer-Platzhalter V0.1";
            SetObjectArray(so.FindProperty("classes"), warrior, rogue, mage, priest);
            SetStringArray(so.FindProperty("names"), "Arel", "Bera", "Corin", "Daria", "Elian", "Fara", "Joren", "Mira");
            SetStringArray(so.FindProperty("appearanceIds"), "human.adult.placeholder.01", "human.adult.placeholder.02", "human.adult.placeholder.03");
            so.ApplyModifiedPropertiesWithoutUndo();
            AssetDatabase.CreateAsset(generation, generationPath);
            AssetDatabase.SaveAssets();
            Debug.Log("Sprint 2 adventurer placeholder definitions created.");
        }

        private static AdventurerClassDefinition EnsureClass(string fileName, string id, string displayName, AdventurerRole roles)
        {
            var path = Root + "/" + fileName;
            var existing = AssetDatabase.LoadAssetAtPath<AdventurerClassDefinition>(path);
            if (existing != null)
            {
                if (!existing.TryValidate(out var error) || existing.Id != id || existing.DisplayName != displayName || existing.Roles != roles)
                    throw new InvalidOperationException("Existing class asset conflicts with required data: " + path + " (" + error + ")");
                return existing;
            }
            var created = ScriptableObject.CreateInstance<AdventurerClassDefinition>();
            var so = new SerializedObject(created);
            so.FindProperty("id").stringValue = id;
            so.FindProperty("displayName").stringValue = displayName;
            so.FindProperty("roles").intValue = (int)roles;
            so.ApplyModifiedPropertiesWithoutUndo();
            AssetDatabase.CreateAsset(created, path);
            return created;
        }

        private static void EnsureFolder(string parent, string child)
        {
            var full = parent + "/" + child;
            if (!AssetDatabase.IsValidFolder(full)) AssetDatabase.CreateFolder(parent, child);
        }

        private static void SetStringArray(SerializedProperty property, params string[] values)
        {
            property.arraySize = values.Length;
            for (var i = 0; i < values.Length; i++) property.GetArrayElementAtIndex(i).stringValue = values[i];
        }

        private static void SetObjectArray(SerializedProperty property, params UnityEngine.Object[] values)
        {
            property.arraySize = values.Length;
            for (var i = 0; i < values.Length; i++) property.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
        }
    }
}
#endif

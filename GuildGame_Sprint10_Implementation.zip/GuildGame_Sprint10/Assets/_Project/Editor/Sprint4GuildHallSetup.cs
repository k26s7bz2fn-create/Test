#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace GuildGame.Editor
{
    public static class Sprint4GuildHallSetup
    {
        private const string ScenePath = "Assets/_Project/Scenes/GuildHall.unity";
        private const string PrefabPath = "Assets/_Project/Prefabs/UI/GuildHallCanvas.prefab";

        [MenuItem("GuildGame/Sprint 4/Create Placeholder Guild Hall")]
        public static void CreatePlaceholderGuildHall()
        {
            EnsureFolders();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("GuildHall");
            var environment = new GameObject("Environment"); environment.transform.SetParent(root.transform);
            CreatePrimitive("Floor", PrimitiveType.Cube, environment.transform, new Vector3(0,-.25f,3), new Vector3(12,.5f,10));
            CreatePrimitive("GuildMasterDesk", PrimitiveType.Cube, environment.transform, new Vector3(0,.5f,0), new Vector3(3,1,1));
            var master = CreatePrimitive("GuildMaster", PrimitiveType.Capsule, root.transform, new Vector3(0,1, -1.2f), new Vector3(.8f,1f,.8f));
            master.transform.rotation = Quaternion.Euler(0,0,0);

            var anchors = new GameObject("CameraAnchors"); anchors.transform.SetParent(root.transform);
            var overview = new GameObject("OverviewAnchor").transform; overview.SetParent(anchors.transform); overview.position=new Vector3(0,2.8f,-5f); overview.rotation=Quaternion.Euler(10,0,0);
            var rig = new GameObject("CameraRig"); rig.transform.SetParent(root.transform);
            var cameraGo = new GameObject("Main Camera"); cameraGo.tag="MainCamera"; cameraGo.transform.SetParent(rig.transform); var cam=cameraGo.AddComponent<Camera>();
            var cameraController=rig.AddComponent<GuildHallCameraController>();

            var facilities = new GameObject("Facilities"); facilities.transform.SetParent(root.transform);
            var positions = new[]{new Vector3(-4,1,2),new Vector3(-2,1,5),new Vector3(0,1,5.5f),new Vector3(2,1,5),new Vector3(4,1,2),new Vector3(4,1,5)};
            var destinations=(GuildHallDestination[])Enum.GetValues(typeof(GuildHallDestination));
            var points=new GuildHallInteractionPoint[destinations.Length];
            for(int i=0;i<destinations.Length;i++)
            {
                var facility=CreatePrimitive(destinations[i]+"Point", PrimitiveType.Cube, facilities.transform, positions[i], new Vector3(1.5f,2f,.5f));
                var anchor=new GameObject(destinations[i]+"CameraAnchor").transform; anchor.SetParent(anchors.transform); anchor.position=positions[i]+new Vector3(0,1,-3); anchor.LookAt(facility.transform.position+Vector3.up*.5f);
                var point=facility.AddComponent<GuildHallInteractionPoint>(); point.Configure(destinations[i],anchor,facility.GetComponent<Collider>()); points[i]=point;
            }

            var canvasGo=CreateCanvas(root.transform); var panelController=canvasGo.AddComponent<GuildHallPanelController>();
            var systems=new GameObject("Systems"); systems.transform.SetParent(root.transform); var nav=systems.AddComponent<GuildHallNavigationController>(); var input=systems.AddComponent<GuildHallInputRouter>(); var sceneController=systems.AddComponent<GuildHallSceneController>();
            var eventGo=new GameObject("EventSystem"); eventGo.AddComponent<EventSystem>(); eventGo.AddComponent<StandaloneInputModule>();

            // Serialized references are intentionally left for the Unity inspector because private fields are protected contracts.
            EditorSceneManager.MarkSceneDirty(scene); EditorSceneManager.SaveScene(scene,ScenePath);
            PrefabUtility.SaveAsPrefabAsset(canvasGo,PrefabPath);
            Selection.activeObject=root;
            Debug.Log("Sprint 4 placeholder scene/prefab created. Wire serialized references in the Inspector, then run EditMode/PlayMode tests.");
        }

        private static GameObject CreateCanvas(Transform parent)
        {
            var go=new GameObject("GuildHallCanvas",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster)); go.transform.SetParent(parent); var c=go.GetComponent<Canvas>(); c.renderMode=RenderMode.ScreenSpaceOverlay;
            var safe=new GameObject("SafeAreaRoot",typeof(RectTransform),typeof(SafeAreaLayout)); safe.transform.SetParent(go.transform,false);
            new GameObject("NavigationBar",typeof(RectTransform)).transform.SetParent(safe.transform,false);
            new GameObject("PanelHost",typeof(RectTransform)).transform.SetParent(safe.transform,false);
            new GameObject("MessageArea",typeof(RectTransform)).transform.SetParent(safe.transform,false);
            return go;
        }
        private static GameObject CreatePrimitive(string name,PrimitiveType type,Transform parent,Vector3 pos,Vector3 scale){var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(parent);go.transform.position=pos;go.transform.localScale=scale;return go;}
        private static void EnsureFolders(){Ensure("Assets/_Project","Scenes");Ensure("Assets/_Project/Prefabs","UI");Ensure("Assets/_Project/Prefabs/UI","GuildHall");}
        private static void Ensure(string parent,string child){var path=parent+"/"+child;if(!AssetDatabase.IsValidFolder(path))AssetDatabase.CreateFolder(parent,child);}
    }
}
#endif

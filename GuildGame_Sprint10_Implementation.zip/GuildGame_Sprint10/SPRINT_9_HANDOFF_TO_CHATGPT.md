# SPRINT_9_HANDOFF_TO_CHATGPT

Sprint 9 ist als C#-Quellstand implementiert und extern begrenzt geprüft; C#/Unity/iOS-Abnahme ausstehend. DoD teilweise erfüllt. Sprint 10 wurde nicht begonnen.

Grundlage: vollständige Sprint-8-Baseline (272 Dateien) und endgültige Freigabe R9-01 bis R9-09. Keine neue Combat-, Simulations-, Reward- oder Progressionsformel; Save weiterhin offen.

Umgesetzt: EquipmentState mit Weapon/UpperBody/Legs, autoritative Standorte, AutoEquipService/EquipmentManager, unveränderliches Panel, strukturierte Fehler, Lagertransfers und Mengenerhaltung. R9-01: freigegebene Auswahlwerte ohne Simulationswirkung. R9-02: Rolleneignung vor Rarity, aktuelle Ausrüstung bei Gleichstand behalten. R9-03: stabile ordinal IDs und Slotreihenfolge. R9-04: nur Lagerkandidaten, ersetzte Items zurück, Durchläufe bis stabil. R9-05: Tote ausgeschlossen, Verletzte idle ausrüstbar, Active/Pending gesperrt.

R9-06: maximal ein Einsatztrank; Healing-Rolle vor Leader vor übrigen IDs, Mangel blockiert nicht. R9-07: beim normalen Questresolve alle ungenutzten Tränke und Equipment Toter zurück; keine Dungeon-Gear-Loss-Regel. Lebensfolgen, Resultat, Rückführungen und Resolved werden gemeinsam veröffentlicht; erst dann sind Sperren/Slot frei. R9-08: Reward-Commit und gildenweiter Equipment-Nachlauf sind getrennt atomar; Nachlauffehler lässt Reward bestehen, Reward-Retry löst keinen zweiten Nachlauf aus. R9-09: nur Zielgruppe vor Start, Equipment/Tränke/Start samt Zeitstatus gemeinsam atomar; fehlende Items erlaubt, Datenkonflikte blockieren.

Architektur: bestehender GuildRuntimeStore/Snapshot, vorhandene Adventurer und ItemInstance-IDs; keine zweite Verwaltung. Instanzen liegen entweder frei im Lager oder genau einem Equipment-Slot. Snapshot-Staging, Konsistenz-/Mengenerhaltungsprüfung und eine erwartete Rootreferenz sichern Veröffentlichung im bestehenden Owning-Game-Thread-Modell.

Neue Dateien: zehn Produktionsdateien unter Scripts/Equipment (EquipmentState, EquipmentItemValues, EquipmentEvaluationRules, EquipmentConsistency, AutoEquipService, EquipmentManager, HealingPotionAssignmentState, HealingPotionAssignmentService, EquipmentResult, EquipmentPanelModel); EquipmentTests.cs mit 37 NUnit-Testinstanzen, verify_sprint9.py, Metadaten, Status, Implementierungsbeschreibung, Prüfprotokolle, Baseline-Diff und Hashmanifest.

Zehn Bestandsänderungen: AdventurerState (Loadout/Zustandserhalt), GuildRuntimeStore (gemeinsames Equipment-Publish), ItemDefinitionData (Auswahldaten), QuestManager (atomare Vor-/Nachbereitung), QuestResult und QuestResolutionResult (Fehler/Trankmangel), RewardApplicationManager und RewardApplicationResult (getrennter Nachlauf), RewardApplicationTests und RewardAtomicityTests (Lager-plus-Equipment-Erwartung statt nur freiem Lager). Jeder technische Grund und vollständiger Diff im Paket.

In diesem Durchlauf ausgeführt und bestanden: 38 neue Python-Fälle plus 128 deterministische Eigenschaftsszenarien; 19 Progressions-, 40 Skill-, 24 Reward-, 63 Party-, 54 Quest-Referenzfälle; 585 Simulationsfälle (9 Beispiele + 576 Seedfälle); Recruitment-Runner 81/81 mit gemischten Referenz-/Quellprüfungen. Begrenzte statische Prüfungen 34/34, lexikalisch 109 C#-Dateien, neun Formeldateien bytegleich. Python ist keine C#-Ausführung. Historische 597 Sprint-7-Prüfungen nicht pauschal erneut behauptet; historische Quell-/Baseline-Gates nicht erneut ausgeführt.

C#-Kompilierung: nicht ausgeführt. NUnit/Unity EditMode/PlayMode: nicht ausgeführt, einschließlich 37 neuer Instanzen. Xcode/iPhone: offen. Save: nicht implementiert. Vollständige Sprint-8-Baseline: 262 Dateien bytegleich, zehn dokumentiert geändert, keine fehlend; Originalordner und Archiv unverändert.

Risiken: externe C#/Unity-Integration und internal-/Assembly-Sichtbarkeit ungeprüft; keine iPhone-Performance-Abnahme; große Lager können mehrere Vergleichsdurchläufe erfordern; Game-Thread-Annahme, keine Neustart-Idempotenz ohne Save. Ungültige globale Itemdaten blockieren Equipmentoperationen. Keine frühere eigenständige Sprint-9-Planungsdatei im Sprint-8-Paket, daher kein behaupteter byteweiser Planvergleich; endgültige Nutzerfreigabe ist maßgeblich.

Lieferung: GuildGame_Sprint9_Implementation.zip und SPRINT_9_STATUS.md; Details und aktuelle Prüfprotokolle im Paket. Kein vollständiger DoD-Abschluss behauptet.

## NÄCHSTER AUFTRAG FÜR CHATGPT

1. Sprint-9-Paket und Status als neuen Quellstand übernehmen; offene Gates beibehalten.
2. Diff und endgültige R9-Regeln gegen externe Projektquellen prüfen.
3. C# in der vorgesehenen Unity-Version kompilieren; Assembly-/internal-Zugriffe prüfen.
4. 37 neue NUnit-Instanzen sowie alle früheren EditMode-/PlayMode-Tests ausführen; Fehler gezielt beheben.
5. Queststart, Pending-Sperren, Wipe-Rückgabe und Reward-Retry in Unity durchspielen.
6. Xcode/iPhone-Abnahme separat ausführen; Save bleibt offen. Sprint 10 erst nach eigenem Auftrag beginnen.

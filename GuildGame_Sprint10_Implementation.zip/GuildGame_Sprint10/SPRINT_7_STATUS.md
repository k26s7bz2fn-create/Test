# SPRINT_7_STATUS

Stand: 2026-09-21. Basis: `GuildGame_Sprint6_Implementation.zip`.

**Sprint 7: als C#-Quellimplementierung umgesetzt und extern begrenzt geprüft; C#-/Unity-/iOS-Abnahme ausstehend. Definition of Done teilweise erfüllt.**

Keine C#-Kompilierung und keine NUnit-/Unity-/Xcode-/iPhone-Ausführung durchgeführt. Sprint 8 nicht begonnen.

## Implementierter Scope

QuestSimulationService, zentral konfigurierbare freigegebene Formeln, seedbare SHA-256-Auswertung, PartyPower/Schwierigkeit/Rollen/Leader/Persönlichkeit, Erfolg/Rückzug, Kampfunfähigkeit, Heiler-Stabilisierung, Verletzung/Tod/Wipe. Strukturierter unveränderlicher Ergebnisvertrag mit getrennten Mitgliederfolgen sowie XP-, Gold- und Loot-Daten.

Minimaler autoritativer Todes-/Verletzungsstatus am bestehenden AdventurerState; tote Mitglieder für neue Gruppenzuweisungen/Leader/Quests gesperrt, Verletzte bis zur Genesungszeit für neue Quests gesperrt. Keine automatische Entfernung, Wiederbelebung oder Gedenktafel.

Nur CompletedPendingResolution kann aufgelöst werden. Resultat, Health-Folgen und Resolved werden über einen gemeinsamen Zustand atomar veröffentlicht. Sperren/Aktivplatz hängen an diesem Zustand und bleiben bei Fehlern bestehen. Wiederholung liefert den vorhandenen Beleg ohne neue Ausgabe. Drei-Aktivplatz-Limit unverändert. XP/Gold/Loot werden **nicht angewendet**.

## Geänderte bestehende Dateien

Alle zehn Änderungen sind technisch für autoritative Folgen, atomare Integration und korrekte Verfügbarkeitsdaten erforderlich. Vollständiger Diff: `Docs/Sprint7_BaselineChanges.patch`.

| Datei unter Assets/_Project/Scripts | Grund |
|---|---|
| `Adventurers/AdventurerState.cs` | Autoritativer Todes-/Genesungsstatus; validierte Leader-/Persönlichkeitsskalare als Simulationseingaben. Alte Factory und F1 unverändert verfügbar. |
| `Adventurers/AdventurerManager.cs` | Bestand aus gemeinsamem RuntimeStore lesen/schreiben; Klassenauflösung für Simulation. Erforderlich für atomare Health-/Quest-Übernahme; keine zweite Mitgliederverwaltung. |
| `Party/PartyManager.cs` | Tote bei neuer Mitglieds-/Leaderzuweisung und Transfer abweisen; Entfernung/Auflösung und bestehende Sperrpolicy erhalten. |
| `Party/PartyResult.cs` | AdventurerDead am Ende ergänzt; bisherige numerische Fehlerwerte erhalten. |
| `Party/PartyPanelModel.cs` | Tod/Genesungszeit read-only anzeigen; tote Kandidaten nicht als hinzufügbar oder als neuer Leiter anbieten. |
| `Quests/QuestActivityRegistry.cs` | Questdaten und Health an gemeinsamen Veröffentlichungszustand binden; interne atomare Resolve-Publikation. Sperren weiterhin ausschließlich aus Queststatus ableiten. |
| `Quests/QuestManager.cs` | Injured/dead Deployment prüfen; pure Simulation integrieren und Folgen/Resultat/Abschluss gemeinsam übernehmen; Retry-/Fehlerverhalten. |
| `Quests/QuestRuntimeState.cs` | Unveränderlichen Resultatbeleg und kontrollierten Pending→Resolved-Übergang ergänzen. |
| `Quests/QuestPanelModel.cs` | Restdauer bei Resolved auf null Sekunden begrenzen; lesender Zugriff bleibt nebenwirkungsfrei. |
| `Quests/QuestResult.cs` | AdventurerUnavailable am Ende ergänzen; alte numerische Codes erhalten. |

## Neue Implementierungs- und Testdateien

| Datei unter Assets/_Project | Zweck |
|---|---|
| `Scripts/Adventurers/GuildRuntimeStore.cs` | Gemeinsamer interner Veröffentlichungszustand; kein paralleler Bestand |
| `Scripts/Quests/Simulation/QuestSimulationRules.cs` | Freigegebene Defaults, Validierung, Konfigurationskopie und Fingerprint |
| `Scripts/Quests/Simulation/QuestSimulationRandom.cs` | Seed-/domänenbasierte reproduzierbare Zufallswerte |
| `Scripts/Quests/Simulation/QuestSimulationInput.cs` | Validierter, kanonischer Input aus vorhandenen Typen |
| `Scripts/Quests/Simulation/QuestSimulationResult.cs` | Unveränderliche Resultat-/Mitglieder-/Loot-Belege |
| `Scripts/Quests/Simulation/QuestSimulationService.cs` | Reine Simulation ohne Zustands- oder Reward-Anwendung |
| `Scripts/Quests/Simulation/QuestResolutionResult.cs` | Strukturierte Resolve-Fehler und Kennzeichnung neuer Belege |
| `Tests/EditMode/Simulation/QuestSimulationTests.cs` | Formel-, Seed-, Stabilisierungstests und feste Beispiele |
| `Tests/EditMode/Simulation/QuestResolutionTests.cs` | Atomare Integration, Sperren, Fehler, Einmaligkeit, Health |
| `Tests/Fixtures/simulation_v01_cases.json` | Neun Beispiele mit festen erwarteten Ergebnissen |

Für diese zehn neuen Assets jeweils eine `.meta`-Datei; zusätzlich `.meta` für die beiden neuen Simulation-Ordner. Neue Werkzeuge/Dokumente: `Tools/verify_sprint7.py`, `Docs/Sprint7_Implementation.md`, `Docs/Sprint7_TestResults.md`, `Docs/Sprint7_Verification.txt`, `Docs/Sprint7_RecruitmentRegression.txt`, `Docs/Sprint7_BaselineChanges.patch`, dieser Status und `PACKAGE_SPRINT7_SHA256.json`.

## Ausgeführte und bestandene Prüfungen

| Tatsächlich ausgeführt | Bestanden |
|---|---:|
| Python-Referenzmodell: feste Rechenbeispiele | 9/9 |
| Python-Referenzmodell: Seed-/Invarianten-Szenarien | 576/576 |
| Weitere Python-Referenzprüfungen | 12/12 |
| Vorhandene Party-Referenzfälle | 63/63 |
| Vorhandene Quest-Referenzfälle | 54/54 |
| Vorhandenes Recruitment-Prüfwerkzeug | 81/81 |
| Begrenzte Struktur-/Integrations-Quellprüfungen | 34/34 |
| Quellprüfung zentraler Konstanten | 42/42 |
| Lexikalische Klammerprüfung aller C#-Dateien | 77/77 Dateien |

Die Referenzmodelle führen **keinen C#-Code** aus. Strukturelle Textprüfungen beweisen weder Typkorrektheit noch Runtime-Verhalten. 38 neue NUnit-Testinstanzen sind vorbereitet, davon **0 ausgeführt**. Auch die historischen NUnit-/PlayMode-Tests wurden nicht ausgeführt.

Der erste Lauf enthielt einen zu breit gefassten Quellcheck; dessen Muster wurde korrigiert und der komplette Prüflauf wiederholt. Einzelheiten und Reproduktionsbefehle stehen in `Docs/Sprint7_TestResults.md`. Finale Logs liegen im Paket.

## Statisch geprüfte Punkte

Pending-Zustandsschranke; gespeicherter Retry-Beleg; genau eine Resolve-Veröffentlichung; gemeinsamer Health-/Quest-Zustand; Fehler-/Reentranz-/Konfliktschranken; Deployment-Prüfung; dauerhafter Tod; inklusive Genesungsgrenze; tote Gruppenmitglieder; Fortbestand der Pending-Sperren; kanonische Reihenfolge; SHA-256-Nutzung; zuerst Kampfunfähigkeit, dann Stabilisierung, dann Tod; nur bewusste Heiler und höchstens ein Versuch; Wipe nur bei allen Toten; an CompletionTimestamp gebundene Genesung; keine Reward-/Save-Anwendung; read-only Panels; kopierte Regeln; XP-Teilung durch Startteilnehmerzahl; alte Enum-Werte erhalten. Metadaten haben 88 eindeutige GUIDs.

Dies sind begrenzte Quellprüfungen und manueller Quellreview, **keine C#-Kompilierung**.

## Baseline-Erhaltung

Alle 182 Dateien des vollständigen Sprint-6-Pakets vorhanden. **172 Dateien bytegleich; ausschließlich die zehn oben dokumentierten Bestandsdateien geändert.** Keine alten Tests, Fixtures, Szenen, Metadaten, Statusberichte oder Prüfwerkzeuge umgeschrieben. Historische Hash-Manifeste bleiben als damalige Momentaufnahmen unverändert; das neue Manifest beschreibt den Sprint-7-Stand.

## Offene Risiken und Gates

- C#-Kompilierung: **nicht ausgeführt/offen**. In dieser Umgebung kein dotnet/csc/mcs/mono/Unity im PATH.
- Unity-Kompilierung, EditMode-/PlayMode-Tests: **nicht ausgeführt/offen**. Testassemblies/interne Sichtbarkeit und Integration in das tatsächliche Unity-Projekt extern prüfen.
- Xcode-/IL2CPP-Build und iPhone-Abnahme: **nicht ausgeführt/offen**. SHA-256-/Reflection-Unterstützung, Performance und Gerätelaufzeit nicht verifiziert.
- Vollständige Save-Integration: **offen und außerhalb des Scopes**. Exactly-once gilt für die aktuelle Laufzeit; keine Persistenzgarantie über Neustarts.
- Deployment/Health/Commit-Verhalten ist durch C#-Tests vorbereitet, aber mangels C#-Ausführung noch nicht dynamisch am Produktionscode nachgewiesen.
- Alle Manager-Aufrufe ausschließlich auf dem besitzenden Game-Thread. Keine allgemeine Mehrthread-Synchronisation hinzugefügt.
- Alte AdventurerState-Referenzen sind historische Snapshots. UI/weitere Konsumenten müssen aktuellen Health-Stand über AdventurerManager beziehen.
- Rang-/Gefahrbezeichnungen müssen explizit konfiguriert sein. Defaults unterstützen F sowie Niedrig/Normal/Hoch. Nicht zugeordnete Kennungen bleiben beim Resolve kontrolliert gesperrt; keine erfundenen Balancewerte für freie Sprint-6-Labels.
- Die Genesung folgt absoluten Zeitstempeln; kein neues System gegen Geräteuhr-Rücksprünge. Verzögerte Auswertung verlängert Genesung nicht.
- Keine ScriptableObject-Assets oder Unity-Szenen wurden erzeugt. Balancing-Spieltests und subjektives Spielgefühl stehen aus.

## Planabweichungen und technische Ergänzungen

Keine zusätzliche fachliche Regel und kein Sprint-8-Scope umgesetzt. Technisch musste die bisher getrennte Veröffentlichung von Roster und Quests durch einen internen gemeinsamen Zustand ersetzt werden: Zwei unabhängige Veröffentlichungen könnten Health und Questabschluss nicht atomar sichtbar machen. Die existierenden Manager bleiben die einzigen fachlichen Zugänge. Die minimale Ergänzung von AdventurerState entspricht der ausdrücklich freigegebenen Anforderung an autoritativen Lebens-/Verletzungsstatus.

Vorhandene QuestDefinition-Rewards bleiben autoritativ. Die freigegebenen Basis-Koeffizienten werden als Autorenrichtwerte dokumentiert; keine bestehenden Questdaten werden nachträglich überschrieben. Zusätzliche Rangkennungen sind konfigurierbar, ohne eine neue Rangarchitektur zu erfinden.

## Definition of Done

| Kriterium | Status |
|---|---|
| Sprint-7-Quellscope umgesetzt | Erfüllt auf Quelltextebene |
| Referenzprüfungen und begrenzte statische Prüfung | Ausgeführt, bestanden |
| Neue C#-Tests und Reproduktionsunterlagen | Vorbereitet |
| Bestandsänderungen begründet, sonst Baseline erhalten | Geprüft |
| C# kompiliert und Runtime-Tests bestanden | Offen |
| Unity-/iOS-Abnahme | Offen |
| Save-Integration | Außerhalb Sprint 7, weiterhin offen |
| Gesamt-DoD | **Teilweise erfüllt** |

Sprint 8 wurde nicht begonnen. Unity bleibt die Zielarchitektur.

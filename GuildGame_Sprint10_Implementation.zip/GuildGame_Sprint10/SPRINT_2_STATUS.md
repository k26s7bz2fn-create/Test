# SPRINT 2 STATUS

Stand: 14.09.2026

**Sprint 2 ist als Quellen-/Testpaket technisch vorbereitet. Unity/iOS-Abnahme ausstehend. Sprint 3 bleibt zurückgestellt.**

## Erledigt

- Drei Projektpakete in ausführbarer Dateiumgebung geprüft und entpackt.
- Sprint-1-Baseline gegen 68 SHA-256-Hashes geprüft: unverändert.
- 13 C#-Dateien für das isolierte Abenteurer-System erstellt.
- Datenvertrag mit 16 Referenzfällen erstellt.
- 3 Unity-EditMode-Testdateien erstellt.
- Editor-Setup für die vier Klassenassets und das Generierungsasset erstellt.
- 16/16 unabhängig ausführbare Python-Referenz-/Scopeprüfungen bestanden.
- Separate Sprint-2-Dokumentation erzeugt.

## Inhalt

- AdventurerClassDefinition
- AdventurerGenerationDefinition
- AdventurerRole
- AdventurerCatalog
- AdventurerState
- RandomGenerator / IRandomSource
- AdventurerGenerator
- AdventurerManager
- AdventurerResult
- Sprint2DataSetup
- Definition-/Generator-/Manager-Tests
- adventurer_v01_cases.json

## Offen

1. **C2:** echter C#-/Unity-Compile, weil hier kein C#-Compiler/Unity installiert ist.
2. **T2/U2:** Unity EditMode Tests und tatsächliche ScriptableObject-Erzeugung.
3. **I2:** Save-/GameState-Anbindung der Abenteurer. Bewusst nicht Teil von Sprint 2.
4. **B1/U1:** offene Sprint-1-Unity-Gates unverändert.
5. **X1/D1:** Xcode, Signierung und echter iPhone-16-Pro-Test.

## Scope

Keine Recruitment-, Quest-, Dungeon-, Combat-, Inventory-, Equipment-, Building-, Party-, Progression-, Relationship-, Tod-/Wiederbelebungs- oder Save-Integration wurde hinzugefügt.

## Bewertung

Die unabhängig ausführbaren Schritte sind abgeschlossen. Es gibt aktuell keine fehlende oder widersprüchliche Produktentscheidung, die eine regelgetreue Sprint-2-Implementierung verhindert. Der nächste fachliche Sprint bleibt dennoch gemäß Vorgabe zurückgestellt, bis Sprint 2 als Paket übergeben und später in Unity kompiliert/getestet wurde.

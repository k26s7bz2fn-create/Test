# SPRINT_8_STATUS

Stand: 2026-09-23. Grundlage: GuildGame_Sprint7_Implementation.zip und Regeln P8-01 bis P8-12, durch „Ausführen“ zur Umsetzung freigegeben.

**Sprint 8 als C#-Quellstand implementiert und extern begrenzt geprüft; C#-/Unity-/iOS-Abnahme ausstehend. Definition of Done teilweise erfüllt.**

## Implementierter Umfang

XP-Anwendung aus autoritativen Resolved-Resultaten; F1–F10 mit Schwellen 0/30/70/120/180/250/330/420/520/630; drei automatisch verteilte Skillpunkte je Level; vier Klassenkataloge mit je neun Skills und drei Rängen. F10-Überschuss dokumentiert, nicht für E1 angespart.

Gold im gemeinsamen Gildenbestand. Sieben freigegebene Itemdefinitionen; Equipment als Einzelinstanzen, Heiltränke im gemeinsamen Stapel. Kein fachliches Lagerlimit, keine Durability, kein Auto-Equipment und kein Trankverbrauch.

Atomare gemeinsame Anwendung von Progression, Gold, Lager und Reward-Ledger. Idempotenter Retry mit bestehendem Receipt. Fehler und Snapshot-Konflikte erzeugen keinen eigenen Teilzustand. Read-only Panel mit ausdrücklich gekennzeichneter Vorschau.

XP aus früherem positivem Resultat bleibt bei späterem Tod gültig; aktueller Health-Status wird erhalten. Bereits im ursprünglichen Resultat Tote erhalten null XP. Aktuelle Level beim Resolve bleiben maßgeblich, auch nach Levelaufstieg während einer laufenden Quest. QuestSimulationService und seine Formeln unverändert.

## Neue Dateien

Produktionsdateien unter Assets/_Project/Scripts:

- `Guild/GuildEconomyState.cs`
- `Inventory/GuildStorageState.cs`
- `Inventory/ItemCatalog.cs`
- `Inventory/ItemDefinitionData.cs`
- `Inventory/LootApplicationService.cs`
- `Progression/AdventurerProgressionState.cs`
- `Progression/ClassSkillAllocationRules.cs`
- `Progression/ProgressionRules.cs`
- `Progression/ProgressionService.cs`
- `Rewards/RewardApplicationManager.cs`
- `Rewards/RewardApplicationReceipt.cs`
- `Rewards/RewardApplicationResult.cs`
- `Rewards/RewardLedgerState.cs`
- `Rewards/RewardPanelModel.cs`

Neue Testdateien unter Assets/_Project/Tests/EditMode:

- `Inventory/LootApplicationTests.cs`
- `Progression/ProgressionTests.cs`
- `Progression/SkillAllocationTests.cs`
- `Rewards/RewardApplicationTests.cs`
- `Rewards/RewardAtomicityTests.cs`
- `Rewards/RewardPanelTests.cs`
- `Rewards/RewardTestContext.cs`

Zusätzlich: reward_application_v01_cases.json, zugehörige eindeutige Unity-Metadaten, Tools/verify_sprint8.py, Docs/Sprint8_Implementation.md, Docs/Sprint8_TestResults.md, drei Prüfprotokolle, Docs/Sprint8_BaselineChanges.patch, dieser Status und PACKAGE_SPRINT8_SHA256.json.

## Geänderte bestehende Dateien und Gründe

| Datei unter Assets/_Project/Scripts | Technische Notwendigkeit |
|---|---|
| Adventurers/AdventurerState.cs | Autoritative Progression/Level; Health-Kopien erhalten Progression, Progressionskopien erhalten aktuellen Health-Status |
| Adventurers/GuildRuntimeStore.cs | Gold/Lager/Ledger im gemeinsamen Veröffentlichungszustand; Kopiermethoden erhalten sämtliche übrigen Felder |
| Quests/QuestActivityRegistry.cs | Quest-/Zeitveröffentlichung verwendet erhaltende Kopiermethode |
| Quests/QuestManager.cs | Questabschluss verwendet erhaltende Kopiermethode; keine Änderung der Simulation oder Reward-Berechnung |

AdventurerManager musste nicht geändert werden: Die vorhandene ReplaceMembers-Weiterleitung erhält die neuen Felder durch die Änderung im RuntimeStore. Keine zweite Mitglieder-, Health- oder Gruppenverwaltung.

## Tatsächlich ausgeführte Prüfungen

| Prüfung | Bestanden |
|---|---:|
| Neue Python-Progressionsfälle | 19/19 |
| Neue Python-Klassen-/Skillfälle | 40/40 |
| Neue Python-Reward-/Atomaritätsprüfungen | 24/24 |
| Sprint-8-Strukturprüfungen am Quelltext | 31/31 |
| Sprint-8-Vertragsprüfungen am Quelltext | 8/8 |
| Lexikalische Prüfung | 98/98 C#-Dateien |
| Vollständiger historischer Sprint-7-Runner: Referenzprüfungen | 597/597 |
| Party-Referenzregression | 63/63 |
| Quest-Referenzregression | 54/54 |
| Recruitment-Prüfwerkzeug | 81/81 |

Der Sprint-7-Runner bestand zusätzlich mit seinen 34 Struktur- und 42 Konstantenprüfungen. Überlappende Prüfungen werden nicht zu einem größeren unabhängigen Gesamtscore addiert. **Keine dieser Python-Prüfungen führt C# aus.**

62 neue NUnit-Testinstanzen vorbereitet, **keine ausgeführt**. Historische NUnit-/PlayMode-Tests ebenfalls nicht ausgeführt.

## Statisch geprüfte Punkte

Resolved-Gate, autoritative Resultatquelle, kein ObjectiveSucceeded-Gate, Ledger vor Vorbereitung, unveränderlicher Retry-Beleg, Output-Konflikte, ursprüngliche Teilnehmermenge, ursprünglicher Tod mit XP 0, keine Neubewertung späteren Todes, wechselseitiger Erhalt von Health/Progression, eine gemeinsame Veröffentlichung, vorgelagerte Ledger-Erzeugung, keine erneute Simulation, Erhalt der Rewards bei Roster-/Quest-/Zeitoperationen, F10-Cap vor Addition, checked Gold-/Trankaddition, deterministische Equipment-IDs, kein Loot-Neuwürfeln, read-only Preview, Reentranz und Snapshot-Prüfung, exakte Schwellen/Skill-IDs/Item-IDs sowie eindeutige Metadaten-GUIDs.

Diese begrenzten Quellprüfungen sind kein Compiler und kein Nachweis ausgeführter C#-Runtime-Semantik.

## Baseline

Alle 212 Dateien der Sprint-7-Basis vorhanden: **208 bytegleich, ausschließlich vier dokumentierte Änderungen.** Alle bestehenden Tests, Fixtures, historischen Berichte und Prüfwerkzeuge unverändert. Die vollständigen Sprint-7-Simulationsdateien bleiben bytegleich. Der neue Hash-Manifest beschreibt den aktuellen Stand; historische Manifeste bleiben historische Momentaufnahmen.

## Offene Gates und Risiken

- **C#-Kompilierung nicht ausgeführt.** dotnet/csc/mcs/mono/Unity in dieser Umgebung nicht im PATH.
- **Unity EditMode-/PlayMode-Tests nicht ausgeführt.** 62 neue Testinstanzen sowie historische Tests extern auszuführen; Assembly-/Internal-Sichtbarkeit prüfen.
- **Xcode-/IL2CPP-/iPhone-Abnahme offen.** Keine Geräte- oder Performance-Abnahme.
- **Save-Integration offen.** Idempotenz gilt im aktuellen gemeinsamen Laufzeitbestand; kein Neustart-/Restore-Versprechen. Der Retry-Vertrag verwendet die gespeicherte Resultatreferenz.
- Owning-Game-Thread-Modell beibehalten; keine allgemeine Mehrthread-Synchronisation.
- Keine produktiven Unity-Assets oder Szenen erzeugt. Standard-Itemkatalog wird als Runtime-Daten geliefert.
- Bestehende Loot-Testkennungen werden nicht automatisch umgebogen. Nicht katalogisierte IDs blockieren die gesamte Reward-Anwendung kontrolliert.
- Keine fachliche Lagergrenze; sehr große Equipment-Mengen benötigen entsprechend Speicher. Preview erzeugt ebenfalls einen vorbereiteten Zustand und sollte nicht pro Frame angefordert werden.
- Skillränge sind Progressionsdaten ohne neue Kampf-/Simulationswirkung. Neue Level wirken bereits über die unveränderte Sprint-7-Levelstärke.
- Die leere Economy ist technisch mit 0 initialisiert; kein zusätzlicher Startgoldbonus oder Reset bestehender Laufzeitbestände eingeführt.

## Planabweichungen

Keine fachliche Erweiterung über P8-01 bis P8-12. Vier statt fünf Bestandsdateien geändert, weil AdventurerManager ohne eigene Änderung über ReplaceMembers korrekt weiterarbeitet. ItemType und Vertragsdaten liegen gemeinsam in ItemDefinitionData.cs; der Testkontext liegt in einer zusätzlichen Testhilfsdatei. Keine zusätzliche Laufzeitarchitektur.

## Definition of Done

| Kriterium | Status |
|---|---|
| Freigegebene Regeln als C#-Quellstand umgesetzt | Erfüllt auf Quelltextebene |
| Externe Referenz-/begrenzte Quellprüfungen | Ausgeführt, bestanden |
| Baselinevergleich und Änderungsbegründungen | Ausgeführt/dokumentiert |
| NUnit-Tests | Vorbereitet, nicht ausgeführt |
| C#-Kompilierung / Unity-Abnahme | Offen |
| Xcode/iPhone | Offen |
| Vollständige Save-Integration | Außerhalb Scope, weiterhin offen |
| Gesamt-DoD | **Teilweise erfüllt** |

Sprint 9 nicht begonnen. Unity/C# bleibt die finale Architektur.

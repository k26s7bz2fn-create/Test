# SPRINT 6 STATUS

Stand: 15.09.2026

**Sprint 6 ist als C#-Quellimplementierung umgesetzt und außerhalb von Unity referenzmodell-/quellvertraglich geprüft. C#-Kompilierung, tatsächliche NUnit-Ausführung und Unity/iOS-Abnahme stehen aus. Definition of Done teilweise erfüllt.**

## Implementiert

- QuestDefinition, validierter unveränderlicher QuestCatalog und QuestRuntimeState.
- Vier Questtypen: Sammeln, Lieferung, Monsterjagd, Rettung.
- Quest-Rang, Nah/Mittel/Weit, erwartete Dauer, Empfehlung, grobe Gefahr, Gold-/XP-Vorschau und mögliche Beute als Datenvertrag.
- Explizite Angebote, genau eine existierende gültige Gruppe pro Start, Teilnehmer-/Leitersnapshot und UTC-Zeitstempel.
- Available -> Active -> CompletedPendingResolution. Resolved nur als späterer Zustandswert, keine Freigabeoperation.
- Maximal drei Active ODER CompletedPendingResolution-Quests zusammen.
- Gruppe, Mitglieder und Leiter bleiben in beiden Zuständen gebunden. Gruppenumbau, Auflösung, Transfers und Leiteränderungen bleiben gesperrt.
- Zeitpunktgleichheit (`now >= CompletionTimestamp`) erkennt Fälligkeit. Kein Ergebnis, keine Belohnung, keine Freigabe.
- Offline-Vorbereitung durch deterministisch prüfbare Zeitstempel auf erhaltenem Laufzeitstand; keine Save-Wiederherstellung.
- Read-only QuestBoard-/QuestPanel-Datenmodelle und strukturierte Runtime-Resultate.

## Neue Dateien

- `Assets/_Project/Scripts/Data/QuestDefinition.cs`
- `Assets/_Project/Scripts/Data/QuestDefinition.cs.meta`
- `Assets/_Project/Scripts/Quests.meta`
- `Assets/_Project/Scripts/Quests/IQuestClock.cs`
- `Assets/_Project/Scripts/Quests/IQuestClock.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestActivityRegistry.cs`
- `Assets/_Project/Scripts/Quests/QuestActivityRegistry.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestBoardModel.cs`
- `Assets/_Project/Scripts/Quests/QuestBoardModel.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestCatalog.cs`
- `Assets/_Project/Scripts/Quests/QuestCatalog.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestDistance.cs`
- `Assets/_Project/Scripts/Quests/QuestDistance.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestLootContract.cs`
- `Assets/_Project/Scripts/Quests/QuestLootContract.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestManager.cs`
- `Assets/_Project/Scripts/Quests/QuestManager.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestPanelModel.cs`
- `Assets/_Project/Scripts/Quests/QuestPanelModel.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestResult.cs`
- `Assets/_Project/Scripts/Quests/QuestResult.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestRuntimeState.cs`
- `Assets/_Project/Scripts/Quests/QuestRuntimeState.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestStatus.cs`
- `Assets/_Project/Scripts/Quests/QuestStatus.cs.meta`
- `Assets/_Project/Scripts/Quests/QuestType.cs`
- `Assets/_Project/Scripts/Quests/QuestType.cs.meta`
- `Assets/_Project/Tests/EditMode/Quests.meta`
- `Assets/_Project/Tests/EditMode/Quests/QuestDefinitionTests.cs`
- `Assets/_Project/Tests/EditMode/Quests/QuestDefinitionTests.cs.meta`
- `Assets/_Project/Tests/EditMode/Quests/QuestManagerTests.cs`
- `Assets/_Project/Tests/EditMode/Quests/QuestManagerTests.cs.meta`
- `Assets/_Project/Tests/EditMode/Quests/QuestPanelModelTests.cs`
- `Assets/_Project/Tests/EditMode/Quests/QuestPanelModelTests.cs.meta`
- `Assets/_Project/Tests/EditMode/Quests/QuestPartyLockTests.cs`
- `Assets/_Project/Tests/EditMode/Quests/QuestPartyLockTests.cs.meta`
- `Assets/_Project/Tests/EditMode/Quests/QuestTimeTests.cs`
- `Assets/_Project/Tests/EditMode/Quests/QuestTimeTests.cs.meta`
- `Assets/_Project/Tests/Fixtures/quest_v01_cases.json`
- `Assets/_Project/Tests/Fixtures/quest_v01_cases.json.meta`
- `Docs/Sprint6_BaselineChange.patch`
- `Docs/Sprint6_Implementation.md`
- `Docs/Sprint6_OpenGates.md`
- `Docs/Sprint6_PartyRegression.txt`
- `Docs/Sprint6_RecruitmentRegression.txt`
- `Docs/Sprint6_TestResults.md`
- `Docs/Sprint6_Verification.txt`
- `Tools/verify_sprint6.py`
- `SPRINT_6_STATUS.md` (dieser Bericht)
- `PACKAGE_SPRINT6_SHA256.json` (neues Gesamtmanifest)

13 neue Produktions-C#-Dateien und 5 neue NUnit-Testdateien. Testwerte sind ausdrücklich Testdaten, keine eigenmächtigen Produktions-/Balancingentscheidungen. Produktive Questassets wurden nicht in Unity erzeugt.

## Geänderte bestehende Dateien

Genau eine: `Assets/_Project/Scripts/Party/PartyManager.cs`.

Ergänzt wurde ausschließlich die interne, seiteneffektfreie Methode `UsesDependencies(AdventurerManager, IPartyEditPolicy)`, die Referenzidentität beider Abhängigkeiten prüft. Technischer Grund: Der QuestManager muss eine abweichende Registry bzw. einen abweichenden Roster sicher ablehnen, damit Questbelegung tatsächlich die vorhandenen Gruppenbefehle sperrt. Keine Änderung an Gruppenregeln oder vorhandenen Operationen.

Exakter Diff: `Docs/Sprint6_BaselineChange.patch`.

Von 132 Dateien des Sprint-5-Eingabepakets sind 131 bytegleich. Die verbleibende Datei entspricht exakt der dokumentierten Ergänzung. Keine unbeabsichtigten Änderungen oder Löschungen. Zusätzlich sind alle 106 Dateien der ursprünglichen Sprint-4-Basis weiterhin bytegleich. Historische Statusberichte/Manifeste bleiben unverändert; dieser Bericht ist der aktuelle Stand.

## Ausgeführte und bestandene Prüfungen

| Prüfung | Ergebnis | Aussagegrenze |
|---|---|---|
| Sprint-6-Referenzszenarien | 54/54 bestanden | Python-Referenzmodell, keine C#-Ausführung |
| Sprint-6-Quellprüfungen | 38/38 bestanden | 18 lexikalische und 20 gezielte Quellprüfungen, kein Compiler |
| Party-Regressionsprüfer | 63/63 Referenzfälle und 19/19 Quellprüfungen bestanden | Unverändertes vorhandenes Python-Werkzeug |
| Recruitment-Regressionsprüfer | 81/81 bestanden | Ohne zwei optionale historische Sprint-2-Basisprüfungen |
| Sprint-5-Baseline | 131 unverändert, 1 exakt erlaubte Ergänzung | Tatsächlicher Bytevergleich mit ZIP |
| Sprint-4-Baseline | 106/106 unverändert | Tatsächlicher Bytevergleich mit ZIP |
| Python-Prüfer-Syntax | Per ast.parse geprüft | Prüfinfrastruktur |

Befehle und vollständige Protokolle unter `Docs/Sprint6_TestResults.md`, `Sprint6_Verification.txt`, `Sprint6_PartyRegression.txt` und `Sprint6_RecruitmentRegression.txt`.

## Statische Durchsicht

Gelesen/geprüft wurden: gemeinsame Policy-/Rosteridentität, einzelner Registry-Schreiber, keine parallele Gruppenverwaltung, Bindung in Active und Pending, Gruppen- und Teilnehmerprüfung, drei Plätze, Checked-Zeitaddition, exklusiver Active->Pending-Übergang, immutable Teilnehmer-/Leitersnapshots, read-only Panelabfragen und fehlende Ergebnis-/Save-/Reward-Operationen.

Diese Prüfungen sind keine vollständige C#-Syntax-/Typanalyse und kein Laufzeitnachweis des tatsächlichen QuestManager.

## Offene C#-/Unity-/Geräteprüfungen

- **C#-Kompilierung: NICHT AUSGEFÜHRT.** dotnet, csc, mcs, mono und Unity nicht verfügbar.
- **90 neue NUnit-Testinstanzen: NICHT AUSGEFÜHRT.** 54 gemeinsame Vertragsfälle plus 36 weitere Fälle. Diese Zahl ist eine Bestandszählung, kein Prüferfolg.
- **Unity-EditMode-/PlayMode: OFFEN.** Ebenso Import, Assembly-Konfiguration und Composition-Root-Verdrahtung.
- **Xcode-/iPhone-Abnahme: OFFEN.** Keine Signierung, kein Build-/Geräte-/Performance-Nachweis.
- **Save-Integration: WEITERHIN OFFEN UND NICHT IMPLEMENTIERT.** Kein Fortsetzen nach Prozessende ohne spätere Wiederherstellung.
- Sprint-4-Szene/Prefab/Inspector-Verdrahtung und produktive ScriptableObject-Assets bleiben offen.

## Offene Risiken

1. C#- und Unity-spezifische Fehler können erst durch die offenen Compile-/Test-Gates ausgeschlossen werden.
2. IQuestClock muss seiteneffektfrei sein. Befehle gehören auf den besitzenden Spielthread; keine generische Thread-Sicherheit.
3. Geräteuhr ist nicht manipulationssicher. Rückwärtslauf setzt Pending nicht zurück; Save-/Serverzeit ist nicht implementiert.
4. Die tatsächliche reguläre PartyManager-Instanz muss bereits beim Aufbau dieselbe Registry erhalten. Falsche Verdrahtung wird abgelehnt, nicht automatisch repariert. Keine Migration einer bereits laufenden anders verdrahteten Session.
5. Pending-Quests belegen Plätze absichtlich dauerhaft in Sprint 6. Nach drei belegten Plätzen ist kein weiterer Start möglich, bis ein späterer Sprint echte Auswertung/Freigabe ergänzt. Kein versteckter Reset.
6. Kein vollständiges ursprüngliches Unity-Projekt mit allen Projektsettings im gelieferten Quellpaket; ältere offene Gates bleiben bestehen.

## Planabweichungen / Präzisierungen

- Die einzige ältere Dateiänderung ist die oben begründete Identitätsprüfung; sie verhindert eine sonst nicht verifizierbare Sperrintegration.
- Autorenvalidierung folgt dem bestehenden bool/out-error-Muster; Runtime-Operationen verwenden QuestResult/QuestResultCode.
- Paneldaten beziehen sich auf den letzten expliziten Refresh (`AsOfTimestamp`), lesen keine Uhr und verändern keinen Status. Vor dem ersten Refresh ist die Startvorschau nicht zeitlich validiert; der tatsächliche Start prüft selbst.
- Kein produktives Balancing erfunden. Keine tatsächlichen Assets oder Hallenverdrahtung vorgetäuscht.
- Keine fachliche Scope-Erweiterung: kein QuestSimulationService, keine Ergebnis-/Loot-Berechnung, keine Belohnungsvergabe, kein Combat, Dungeon, Inventory, Equipment, Buildings, Relationships, Weltkarte, Reise, Save oder zusätzliche 3D-Inhalte.

## Definition of Done

- Freigegebener C#-Quellumfang: umgesetzt.
- Sperrregel für CompletedPendingResolution: implementiert und im Referenzvertrag sowie vorbereiteten C#-Tests abgedeckt.
- Verfügbare externe Prüfungen: ausgeführt und bestanden, mit den dokumentierten Grenzen.
- Baselinekontrolle: durchgeführt; genau eine technisch begründete Ergänzung.
- C#-/Unity-/iOS-Abnahme: offen. Keine vollständige Laufzeitfreigabe.

**Sprint 7 wurde nicht begonnen.**

# SPRINT 3 STATUS

Stand: 14.09.2026

**Sprint 3 ist implementiert und in der verfügbaren Dateiumgebung unabhängig statisch/vertraglich geprüft. Unity/iOS-Abnahme ausstehend. Sprint 4 wurde nicht begonnen.**

## Quellenabgleich

Die zuvor potenziell blockierende Rollenentscheidung wurde anhand der tatsächlichen Sprint-2-Quellen aufgelöst:

- Krieger: Tank + Damage
- Schurke: Damage
- Magier: Damage + SupportControl
- Priester: Healing + SupportControl

F1 ist in Sprint 2 explizit `Rank = F` und `Level = 1`.

**Keine offene Produktentscheidung blockiert Sprint 3.**

## Implementiert

- 7 neue Recruitment-Produktionsdateien
- 3 neue Unity-EditMode-Testdateien
- 1 Recruitment-Datenvertragsfixture
- 1 unabhängiges Python-Prüfwerkzeug
- atomare Batch-Aufnahme als minimale Erweiterung des bestehenden `AdventurerManager`

Fachlich enthalten:

- genau 5 Startkandidaten
- genau 3 auswählbare/zu bestätigende Kandidaten
- seedbasierte deterministische Erzeugung
- vier kanonische Grundklassen
- F1-Vertrag
- konstruktive Rollengarantie für drei unterschiedliche Kandidaten
- Sessionzustände Created / Selecting / Committed
- 12-Mitglieder-Limit mit Recheck beim Commit
- atomare Aufnahme
- strukturierte Fehlercodes
- read-only RecruitmentPanelModel

## Tatsächlich ausgeführte Prüfungen

`Tools/verify_sprint3.py`: **83/83 bestanden**.

Die Sprint-2-Baseline wurde verglichen. Als einzige absichtliche Änderung an einer Sprint-2-Datei wurde `Assets/_Project/Scripts/Adventurers/AdventurerManager.cs` erkannt.

## Nicht als bestanden gewertet

- Unity-Kompilierung
- Unity EditMode Tests
- Xcode/iOS-Build
- iPhone-Abnahme
- vollständige Save-Integration

## Scope

Nicht implementiert: Party, Quests, Combat, Dungeon, Inventory, Equipment, Buildings, Relationships, 3D-Gildenhalle oder vollständige Save-Integration.

## Definition of Done

- Fachlicher Sprint-3-Quellumfang: erfüllt.
- Unabhängig ausführbare Prüfungen: erfüllt, 83/83.
- Unity-/iOS-Abnahme: offen.

Sprint 4 bleibt zurückgestellt, bis dieses Paket übergeben ist. Eine spätere Unity-Abnahme muss die offenen Gates nachholen.

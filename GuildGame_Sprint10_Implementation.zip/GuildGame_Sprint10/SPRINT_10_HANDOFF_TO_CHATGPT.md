# SPRINT_10_HANDOFF_TO_CHATGPT

Sprint10 wurde als isolierter C#-Quellstand umgesetzt und extern begrenzt geprüft. C#/Unity/iOS-Abnahme ausstehend; DoD teilweise erfüllt. Grundlage: endgültige Nutzerfreigaben R10-01 bis R10-18. Sprint11 wurde nicht begonnen.

## 1. Tatsächlicher Umfang und Dateien

Neue Produktionsdateien unter Assets/_Project/Scripts/Combat:
CombatRules.cs, CombatInput.cs, CombatRandom.cs, CombatState.cs,
CombatAbilities.cs, CombatResult.cs, CombatSession.cs,
CombatTimeController.cs, AdventurerCombatAdapter.cs.

Enthalten sind Combatant-/Herkunftstypen, Profile, Fähigkeiten, Targeting,
Effekte, Status-/Lebenszyklus, Fehler, Panel und reine Sessionlogik.

Neue Tests: CombatCoreCases.cs, CombatNUnitTests.cs, CombatAdapterTests.cs,
combat_v01_rng_vectors.json, Tools/verify_sprint10.py sowie
Tools/CombatCore.Tests/CombatCore.Tests.csproj und Program.cs.
Zusätzlich Metadaten, Implementierungs-/Prüfdokumentation, Protokolle,
Status, Übergabe und Hashmanifest. Vollständige Dateiliste im Status.

Bestehende Dateien geändert: KEINE. Vollständiger Vergleich gegen
Sprint9:305/305 Dateien bytegleich, keine fehlend. Originalordner und
Archiv unverändert. Sprint7-, Sprint8- und Sprint9-Fachlogik unverändert.

## 2. R10-01 bis R10-18

R10-01: isolierter Core, keine Gilden-/Dungeon-/Rewardbuchung.
R10-02:250-ms-Ticks ab1, feste ordinale Liste, Linksrotation (T−1)%N,
Ausgeschiedene behalten Position, Fähigkeit T+C und Aktionssperre4.
R10-03: freigegebene Klassenbasiswerte, Alive-StartHP1..MaxHP,
Adapter volle HP; Level/Skills neutral.
R10-04: Equipment neutral, keine Eignungswerte als Stats.
R10-05: freigegebene Aktionen/Kosten/CDs, genereller Staff-Fallback,
Priester Stabilize>Heal>Strike, keine statusbedingte Zielsuche.
R10-06: max(1,Raw−Defense), Krit×2; Heal12 bei≤50%, keine Überheilung.
R10-07: Mana24 für Magier/Priester, Alive +1/Tick, Stun stoppt nicht.
R10-08: Front/Tank/Zielbindung/ID; keine Positionen oder Threat.
R10-09: nur Standard, kein Leaderbonus.
R10-10: SHA-256 nach freigegebenem Bytevertrag, UInt64-Seed x16,
Längenpräfix uint32 Big-Endian, globaler Drawzähler, drei Purpose-Werte.
R10-11: Poison1/Bleed2/Burn2 je4Ticks, Dauer16, letzter Puls inklusive;
Stun4, Reihenfolge/Quelle/Reapplication gemäß Freigabe.
R10-12:0HP kampfunfähig, Frist32Ticks; Stabilisierung6Mana/CD16,
Stabilized1HP und kein Wiedereintritt.
R10-13: Zusammenbruch60% vor normalem25%-Fristwurf; nie beides pro Vorfall;
Wipe nur alle ursprünglichen Abenteurer Dead.
R10-14: Victory/Defeat und Aftermath; Stun kein Defeat, nur Priester
regenerieren in Aftermath; keine Angriffe/normalen Heals.
R10-15: Überlebte Kampfunfähigkeit120s relative Recovery;
Statusinstanzen beim fachlichen Ende beendet, Verlauf erhalten.
R10-16: kein Potion-Verbrauch, ConsumedPotions leer.
R10-17: vier Goblinprofile und freigegebene Spezialprioritäten;
Boss nur Basic Attack, keine Phasen.
R10-18:1–6 je Seite; Tick480 vollständig; danach ggf. terminaler
TechnicalAbort/SimulationLimitReached ohne Resultat oder Zusatzfolgen;
begonnene Nachsorge darf über120s hinauslaufen.

## 3. Architektur und Ergebnis

CombatSession besitzt unveränderlichen veröffentlichten CombatState.
Tick-Staging kopiert auch RNG-Zähler; Fehler publizieren nichts aus dem
fehlerhaften Tick. Ein Advance kann mehrere vollständige Ticks ausführen.
Pause/1x/2x/4x ändern nur Zeitangebot; keine Frame-/Unity-Abhängigkeit.
Der Adapter liest vorhandene Typen und tatsächliche Questbindungen,
reserviert aber nichts und verändert keinen GuildRuntimeStore.

CombatResult: deterministische ResultId/InputFingerprint, Seed/Regelversion,
Victory/Defeat, IsWipe, Gefechts-/Nachsorge-/Gesamtdauer, Teilnehmer mit
HP/Mana/Lebensstatus/Stabilisierung/Todeszeitpunkt/Recovery; keine XP,
Gold oder Lootdaten. TechnicalAbort enthält ausdrücklich kein CombatResult.
Panel read-only. Keine Item-/Potion-/Progressionsmutation.

## 4. Tatsächliche neue Prüfergebnisse

Python:41 Referenzfälle +128 Eigenschaftsszenarien =169 bestanden.
Vorhandener Sprint9-Runner und Recruitment-Runner erneut bestanden:
166 Equipment,19 Progression,40 Skills,24 Reward,63 Party,54 Quest,
585 Simulationsfälle; Recruitment81 gemischte Prüfungen.
Überlappende Prüfungen nicht als unabhängigen Gesamtscore addieren.

Statisch:35 neue begrenzte Quell-/Metadatenprüfungen bestanden;
121 C#-Dateien lexikalisch geprüft. Historischer Sprint9-Runner bestand
zusätzlich mit seinen34 Quellprüfungen. Das ist keine C#-Kompilierung.

C#-Kompilierung: NICHT ausgeführt; kein Compiler verfügbar.
57 gemeinsame Core-C#-Fälle vorbereitet, inkl.4 Python-Golden-Vektoren.
NUnit/Unity:65 neue Instanzen vorbereitet (57 Core+8 Adapter),0 ausgeführt.
Ältere NUnit-/PlayMode-Tests bleiben ebenfalls offen.
Xcode/IL2CPP/iPhone: NICHT ausgeführt.
Save: nicht implementiert, ausdrücklich außerhalb Scope.

Alle genannten Python-/Quellprüfungen stammen aus diesem Durchlauf.
Historische Statusdateien bleiben historische Nachweise. Insbesondere
werden die früheren597 Sprint7-Prüfungen nicht als neu ausgeführt behauptet.
Protokolle im Paket. Der zusätzliche .NET8-Runner kann ohne Unity-Szene
57 tatsächliche Core-C#-Fälle ausführen, wurde hier aber nicht ausgeführt.

## 5. Abweichungen, Risiken und DoD

Keine beabsichtigte fachliche Regelabweichung. Technische Konsolidierung:
9 statt17 vorläufig geplanten Produktionsdateien. Kein zusätzliches
Session-Registry-/produktives SessionId-System. Faction-Kodierung ist
Adventurer/Enemy, Gegnerrollenmaske0. V1-Regeln zentral eingefroren.

C#-Typ-/Runtimekorrektheit, Golden-Abgleich und Unity-Assemblyintegration
bleiben ungeprüft. Snapshotkopien/SHA-Puffer erzeugen Allokationen;
kein Performanceversprechen. Nur besitzender Thread. Adapter ist kein
produktiver Dungeonstart. Equipment-IDs ändern gemäß genehmigtem
Fingerprint ggf. RNG trotz neutraler Stats. Keine Save-/Commit-Idempotenz.

DoD teilweise erfüllt: Quellstand, externe Referenz-/begrenzte statische
Prüfung und Baselinevergleich vorhanden; tatsächliche C#/Unity/iOS-Gates
fehlen. Sprint11 wurde nicht begonnen.

## NÄCHSTER AUFTRAG FÜR CHATGPT

1. Sprint10-Paket/Status als neuen Quellstand übernehmen, offene Gates beibehalten.
2. Endgültige R10-Freigaben gegen Core und Bytevertrag prüfen.
3. Standalone-C#-Runner mit dotnet run --project Tools/CombatCore.Tests/CombatCore.Tests.csproj ausführen.
4.65 neue NUnit-Instanzen und vorhandene Unity-Regressionsprüfungen ausführen; konkrete Compiler-/Testfehler beheben.
5. RNG-Golden-Vektoren, Tick480, Zusammenbruchsvorrang und Aftermath besonders prüfen.
6. Unity/IL2CPP-/iPhone-Abnahme und Allokationsprofiling separat vornehmen; Save bleibt offen.
7. Keine produktive Dungeonintegration oder Sprint11 ohne neuen Auftrag beginnen.

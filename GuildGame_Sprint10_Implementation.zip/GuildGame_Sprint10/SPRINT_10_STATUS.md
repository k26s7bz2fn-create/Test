# SPRINT_10_STATUS

Stand: 2026-09-25. Basis: GuildGame_Sprint9_Implementation.zip mit305 Dateien; ausdrückliche Freigabe R10-01 bis R10-18 inklusive endgültiger Präzisierungen.

**Sprint10 als isolierter C#-Quellstand umgesetzt und extern begrenzt geprüft. C#/Unity/iOS-Abnahme ausstehend. Definition of Done teilweise erfüllt.**

## Tatsächlich implementiert

CombatSession mit unveränderlichen Eingaben und atomarem Tick-Staging; AdventurerCombatant/EnemyCombatant und gemeinsamer CombatantState; zentrale Klassen-/Gegner-/Abilityprofile; 250-ms-Ticks, Linksrotation, Cooldowns/Aktionssperre; Pause/1x/2x/4x; SHA-256-RNG nach freigegebenem Bytevertrag; Targeting/Front/Tank/Zielbindung; automatische Aktionen; Damage/Defense/Krit/Heal/Mana; vier Statusarten; Incapacitated/Stabilized/Dead; 25%-Fristwurf und vorrangiger60%-Zusammenbruch; Victory/Defeat/Wipe/Aftermath; terminaler TechnicalAbort nach vollständigem Tick480; CombatResult und read-only Panel; lesender Adapter.

Kein produktiver GuildRuntimeStore-Commit, kein permanenter Gildentod, keine Quest-/Rewardbuchung, keine Item-/Potion-Mutation. Equipment, Level und Skills bleiben combatneutral. Sprint11 nicht begonnen.

## Geänderte bestehende Dateien

**Keine.** Alle305 Dateien der vollständigen Sprint9-Baseline sind bytegleich geblieben, keine fehlt. Originalordner und ZIP ebenfalls unverändert. Keine Sprint7-Simulations-, Sprint8-Reward-/Progressions- oder Sprint9-Equipmentlogik geändert.

## Prüfstatus – getrennt

| Kategorie | Tatsächliches Ergebnis dieses Durchlaufs |
|---|---|
| Neue Python-Referenzprüfungen | 41/41 bestanden |
| Neue Python-Eigenschaftsszenarien | 128/128 bestanden |
| Vorhandene Referenzregressionen | Sprint9-Runner sowie Recruitment-Runner neu ausgeführt, bestanden; genaue Kategorien in Docs/Sprint10_TestResults.md |
| Neue begrenzte statische Prüfungen | 35/35 bestanden |
| Lexikalische C#-Quellprüfung | 121/121 Dateien geprüft, bestanden; kein Compiler |
| Vollständiger Baselinevergleich | 305/305 bytegleich |
| C#-Kompilierung | Nicht ausgeführt; kein Compiler verfügbar |
| Standalone-C#-Tests | 57 vorbereitet, nicht ausgeführt |
| NUnit-/Unity-Tests | 65 neue Instanzen vorbereitet (57 Core +8 Adapter), keine ausgeführt; ältere Tests ebenfalls offen |
| Xcode-/iPhone-Abnahme | Nicht ausgeführt, offen |
| Save-Integration | Nicht implementiert, außerhalb Scope |

169 neue Python-Szenarien sind keine C#-Runtimeprüfung. Referenzregressionen:166 Equipment,19 Progression,40 Skills,24 Reward,63 Party,54 Quest,585 Simulation sowie Recruitment-Runner81. Überlappungen nicht zusammengezählt. Historische Prüfungen klar von neuen Protokollen getrennt.

## Statisch geprüfte Punkte

Versionen, Tick-/Frist-/Recoverykonstanten, vollständige Teilnehmerrotation, kopiertes Tick-Staging, Zusammenbruch vor Fristwurf, Priester-only Aftermath-Regeneration, Statusreihenfolge und Quellen-/Pulserhalt, inklusive Endpulse, kein Status auf Ausgefallene, kein Spezialzielwechsel, vollständiger Tick480 vor Limitprüfung, Statusbereinigung, SHA/Seed/Big-Endian/Längenpräfix/UInt64-Wahrscheinlichkeitsvergleich, RNG-Zähler, Pause, keine Systemzeit/Unity-Abhängigkeit, kein Guild-Publish im Adapter, tatsächliche Questbindung, Adapter-MaxHP und Combatneutralität sowie eindeutige Metadaten-GUIDs.

## Abweichungen und technische Konkretisierung

Keine beabsichtigte fachliche Abweichung von den endgültigen R10-Freigaben. Die vorläufige Dateiaufteilung wurde von17 auf9 Produktionsdateien zusammengefasst. Arbeitszustände sind interne Kopien; die Veröffentlichungseinheit ist ein Tick. Ein einzelner Advance-Aufruf darf mehrere vollständig atomare Ticks veröffentlichen. Regeln/Profile sind eingefrorene v1-Konfiguration; Balanceänderungen benötigen Versionspflege. Faction wird kanonisch als Adventurer/Enemy serialisiert; Gegnerrollenmaske0. Kein zusätzliches Session-Registry-/produktives SessionId-System, da ausschließlich isolierte Sessions ohne Commit.

## Bekannte Risiken und offene Gates

- C#-Syntax-/Typprüfung durch echten Compiler und sämtliche tatsächlichen C#-Tests fehlen.
- Unity-Assembly-/internal-Sichtbarkeit und Testintegration extern prüfen.
- Vier RNG-Golden-Vektoren stammen aus Python; C#-Übereinstimmung noch offen.
- Snapshots/Listen/Hashpuffer erzeugen Allokationen; keine GC-/60-FPS-/iPhone-Abnahme behauptet.
- Besitzt-ein-Thread-Modell; keine allgemeine Nebenläufigkeitsgarantie.
- Adapter ist keine Dungeonreservation. Keine produktive Nutzung als Dungeonstart ohne gesonderte spätere Integration.
- Equipment-IDs sind ausdrücklich Teil des genehmigten Fingerprints: unveränderte Stats bedeuten bei geändertem Input nicht dieselbe Zufallsfolge.
- Kein Save/Restore, keine dauerhafte Commit-Idempotenz, keine Verletzungszeitbuchung.
- TechnicalAbort behält den letzten vollständig ausgeführten Tick, erzeugt kein fachliches Abschlussresultat und keine zusätzlichen Folgen.

## Definition of Done

| Kriterium | Stand |
|---|---|
| Freigegebene Combatregeln als Quellimplementierung | Umgesetzt |
| Pythonreferenzen / begrenzte Quellprüfungen | Ausgeführt, bestanden |
| Bestehende Baseline unverändert | Nachgewiesen |
| Tatsächliche C#-Ausführung | Offen |
| NUnit/Unity-Abnahme | Offen |
| Xcode/iPhone | Offen |
| Save | Ausgeschlossen, weiterhin offen |
| Gesamt | **Teilweise erfüllt** |

## Neue Dateien

- `Assets/_Project/Scripts/Combat.meta`
- `Assets/_Project/Scripts/Combat/AdventurerCombatAdapter.cs`
- `Assets/_Project/Scripts/Combat/AdventurerCombatAdapter.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatAbilities.cs`
- `Assets/_Project/Scripts/Combat/CombatAbilities.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatInput.cs`
- `Assets/_Project/Scripts/Combat/CombatInput.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatRandom.cs`
- `Assets/_Project/Scripts/Combat/CombatRandom.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatResult.cs`
- `Assets/_Project/Scripts/Combat/CombatResult.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatRules.cs`
- `Assets/_Project/Scripts/Combat/CombatRules.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatSession.cs`
- `Assets/_Project/Scripts/Combat/CombatSession.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatState.cs`
- `Assets/_Project/Scripts/Combat/CombatState.cs.meta`
- `Assets/_Project/Scripts/Combat/CombatTimeController.cs`
- `Assets/_Project/Scripts/Combat/CombatTimeController.cs.meta`
- `Assets/_Project/Tests/EditMode/Combat.meta`
- `Assets/_Project/Tests/EditMode/Combat/CombatAdapterTests.cs`
- `Assets/_Project/Tests/EditMode/Combat/CombatAdapterTests.cs.meta`
- `Assets/_Project/Tests/EditMode/Combat/CombatCoreCases.cs`
- `Assets/_Project/Tests/EditMode/Combat/CombatCoreCases.cs.meta`
- `Assets/_Project/Tests/EditMode/Combat/CombatNUnitTests.cs`
- `Assets/_Project/Tests/EditMode/Combat/CombatNUnitTests.cs.meta`
- `Assets/_Project/Tests/Fixtures/combat_v01_rng_vectors.json`
- `Assets/_Project/Tests/Fixtures/combat_v01_rng_vectors.json.meta`
- `Docs/Sprint10_Implementation.md`
- `Docs/Sprint10_RecruitmentRegression.txt`
- `Docs/Sprint10_Sprint9Regression.txt`
- `Docs/Sprint10_TestResults.md`
- `Docs/Sprint10_Verification.txt`
- `PACKAGE_SPRINT10_SHA256.json`
- `SPRINT_10_HANDOFF_TO_CHATGPT.md`
- `SPRINT_10_STATUS.md`
- `Tools/CombatCore.Tests/CombatCore.Tests.csproj`
- `Tools/CombatCore.Tests/Program.cs`
- `Tools/verify_sprint10.py`

#!/usr/bin/env python3
"""Independent Python model and LIMITED source checks. Never compiles or executes C#."""
import copy, json, pathlib, random, re, sys, zipfile, importlib.util, argparse
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parents[1]; COUNTS={}; MAX=2**63-1
ROLES={'warrior':(0,1),'priest':(2,3),'rogue':(1,),'mage':(1,3)}
def check(ok,name,cat='equipment_reference'):
 if not ok: raise AssertionError(name)
 COUNTS[cat]=COUNTS.get(cat,0)+1;print('PASS',cat,name)
def item(i,score=4,rarity=0,slot='Weapon',classes=('warrior',),definition=None,values=None):
 return dict(id=i,definition=definition or i,values=values or (score,0,score,0),rarity=rarity,slot=slot,classes=classes)
def quality(i,cls):return (-1,-1) if i is None else (sum(i['values'][r] for r in ROLES[cls]),i['rarity'])
def member(cls='warrior',dead=False,injured=False):return dict(cls=cls,dead=dead,injured=injured,gear={},potion=0)
def state():return dict(members={'a':member(),'b':member('priest'),'c':member()},stock={},potions=0,quests={},gold=0,ledger=set(),post=0)
def locked(s,a):return any(a in q['members'] and q['status'] in ('Active','Pending') for q in s['quests'].values())
def inventory(s):
 ids=list(s['stock']);ids += [i['id'] for m in s['members'].values() for i in m['gear'].values()]
 assert len(ids)==len(set(ids)), 'duplicate instance'
 return sorted(ids),s['potions']+sum(m['potion'] for m in s['members'].values())
def validate(s):
 inventory(s)
 for m in s['members'].values():
  assert 0<=m['potion']<=1
  for slot,i in m['gear'].items():assert i['slot']==slot and m['cls'] in i['classes']
 assert 0<=s['potions']<=MAX
 for i in list(s['stock'].values())+[i for m in s['members'].values() for i in m['gear'].values()]:
  assert i['values'] is not None and len(i['values'])==4 and min(i['values'])>=0
  assert i['rarity'] in (0,1,2) and i['slot'] in ('Weapon','UpperBody','Legs')
def equip(s,targets):
 validate(s);n=copy.deepcopy(s)
 for a in targets:assert a in n['members'] and not n['members'][a]['dead'] and not locked(n,a)
 changed=True
 while changed:
  changed=False
  for a in sorted(targets):
   m=n['members'][a]
   for slot in ('Weapon','UpperBody','Legs'):
    old=m['gear'].get(slot);candidates=[i for i in n['stock'].values() if i['slot']==slot and m['cls'] in i['classes'] and quality(i,m['cls'])>quality(old,m['cls'])]
    if not candidates:continue
    best=sorted(candidates,key=lambda i:(-quality(i,m['cls'])[0],-i['rarity'],i['definition'],i['id']))[0]
    del n['stock'][best['id']]
    if old:n['stock'][old['id']]=old
    m['gear'][slot]=best;changed=True
 validate(n);assert inventory(n)==inventory(s);return n
class World:
 def __init__(self):self.root=state()
 def start(self,ids,leader=None,fail=False):
  b=self.root
  try:
   assert len(ids)==len(set(ids)) and 1<=len(ids)<=6
   assert sum(q['status'] in ('Active','Pending') for q in b['quests'].values())<3
   assert all(not b['members'][a]['dead'] and not b['members'][a]['injured'] and not locked(b,a) for a in ids)
   n=equip(b,ids)
   order=sorted(ids,key=lambda a:(0 if n['members'][a]['cls']=='priest' else 1 if a==leader else 2,a))
   for a in order:
    if n['members'][a]['potion']==0 and n['potions']>0:n['members'][a]['potion']=1;n['potions']-=1
   n['quests'][str(len(n['quests']))]={'status':'Active','members':ids}
   assert not fail;validate(n);assert inventory(n)==inventory(b);self.root=n;return True
  except (AssertionError,KeyError,TypeError):return False
 def resolve(self,qid,deaths=(),fail=False):
  b=self.root
  try:
   q=b['quests'][qid];assert q['status']=='Pending';n=copy.deepcopy(b)
   for a in q['members']:
    m=n['members'][a];m['dead'] |= a in deaths
    if m['dead']:n['stock'].update((i['id'],i) for i in m['gear'].values());m['gear']={}
    n['potions']+=m['potion'];m['potion']=0
   assert n['potions']<=MAX and not fail
   n['quests'][qid]['status']='Resolved';validate(n);assert inventory(n)==inventory(b);self.root=n;return True
  except (AssertionError,KeyError):return False
 def reward(self,qid,failpost=False):
  b=self.root
  if qid in b['ledger']:return 'AlreadyApplied'
  n=copy.deepcopy(b);n['gold']+=40;n['ledger'].add(qid);self.root=n
  self.root['post']+=1
  if failpost:return 'AppliedPostFailed'
  self.root=equip(self.root,[a for a,m in self.root['members'].items() if not m['dead'] and not locked(self.root,a)])
  return 'Applied'
def run_reference():
 def choose(items,current=None):
  s=state();s['stock']={i['id']:i for i in items}
  if current:s['members']['a']['gear']['Weapon']=current
  return equip(s,['a'])
 check(choose([item('rare',2,2),item('common',4)])['members']['a']['gear']['Weapon']['id']=='common','suitability_before_rarity')
 check(choose([item('common'),item('rare',4,2)])['members']['a']['gear']['Weapon']['id']=='rare','rarity_at_equal_score')
 check(choose([item('a')],item('z'))['members']['a']['gear']['Weapon']['id']=='z','current_kept_at_tie')
 check(choose([item('z',definition='a'),item('a',definition='z')])['members']['a']['gear']['Weapon']['id']=='z','definition_tie')
 check(choose([item('z',definition='same'),item('a',definition='same')])['members']['a']['gear']['Weapon']['id']=='a','instance_tie')
 check(quality(item('x',values=(0,5,0,0)),'warrior')>quality(item('y',values=(4,0,0,0)),'warrior'),'no_obsolete_dimension_veto')
 check(choose([item('bad',99,classes=('priest',))])['members']['a']['gear']=={},'class_incompatible')
 s=state();s['stock']={str(i):item(str(i),slot=slot) for i,slot in enumerate(('Weapon','UpperBody','Legs'))};n=equip(s,['a']);check(len(n['members']['a']['gear'])==3,'three_slots')
 n=choose([item('new',5)],item('old',1));check('old' in n['stock'] and n['members']['a']['gear']['Weapon']['id']=='new','return_replaced')
 s=state();s['members']['c']['gear']['Weapon']=item('old');n=equip(s,['a']);check(n['members']['a']['gear']=={},'no_steal')
 # A can use armor returned by later C only on the next pass; C's replacement is class-exclusive.
 s=state();s['members']['c']['cls']='mage';s['members']['c']['gear']['UpperBody']=item('old',slot='UpperBody',classes=('warrior','mage'),values=(1,1,1,1));s['stock']['new']=item('new',slot='UpperBody',classes=('mage',),values=(2,2,2,2));n=equip(s,['a','c']);check(n['members']['a']['gear']['UpperBody']['id']=='old','repeat_pass_for_returned_item')
 s=state();s['members']['a']['injured']=True;s['stock']['x']=item('x');check(bool(equip(s,['a'])['members']['a']['gear']),'injured_idle_equips')
 for condition in ('dead','Active','Pending'):
  s=state();s['stock']['x']=item('x')
  if condition=='dead':s['members']['a']['dead']=True
  else:s['quests']['q']={'status':condition,'members':['a']}
  try:equip(s,['a']);ok=False
  except AssertionError:ok=True
  check(ok,'equip_reject_'+condition)
 for amount,expected in [(0,()),(1,('b',)),(2,('b','c')),(3,('b','c','a')),(20,('b','c','a'))]:
  w=World();w.root['potions']=amount;ok=w.start(['a','b','c'],'c');assigned={a for a,m in w.root['members'].items() if m['potion']};check(ok and assigned==set(expected),'potion_priority_'+str(amount))
 w=World();w.root['potions']=2;w.start(['a','b'],'b');check(w.root['members']['a']['potion']==w.root['members']['b']['potion']==1,'healer_leader_once')
 w=World();w.root['potions']=3;w.root['stock']['x']=item('x');w.start(['b']);check(not w.root['members']['a']['gear'] and not w.root['members']['a']['potion'],'target_only')
 for field in ('dead','injured'):
  w=World();w.root['members']['a'][field]=True;w.root['potions']=3;b=w.root;check(not w.start(['a']) and w.root is b,'no_start_'+field)
 w=World();w.root['stock']['x']=item('x');b=w.root;check(not w.start(['a'],fail=True) and w.root is b,'start_failure_atomic')
 for status in ('Active','Pending'):
  w=World();w.root['quests']={str(i):{'status':status,'members':['other'+str(i)]} for i in range(3)};b=w.root;check(not w.start(['a']) and w.root is b,'fourth_blocked_'+status)
 for dead in ((),('a',),('a','b')):
  w=World();w.root['potions']=2;w.root['stock']['x']=item('x');w.start(['a','b']);w.root['quests']['0']['status']='Pending';b=w.root;check(w.resolve('0',dead) and inventory(w.root)==inventory(b) and not locked(w.root,'a') and all(w.root['members'][a]['dead'] for a in dead),'resolve_conservation_'+str(dead))
  after=w.root;check(not w.resolve('0',dead) and w.root is after,'resolve_retry_'+str(dead))
 w=World();w.root['potions']=2;w.start(['a','b']);w.root['quests']['0']['status']='Pending';w.root['potions']=MAX;b=w.root;check(not w.resolve('0',('a',)) and w.root is b and locked(b,'a'),'resolve_overflow_retains_locks')
 w=World();w.start(['a']);w.root['quests']['0']['status']='Pending';b=w.root;check(not w.resolve('0',('a',),True) and w.root is b,'resolve_fault_retains_health')
 w=World();w.root['stock']['x']=item('x');check(w.reward('q',True)=='AppliedPostFailed' and w.root['gold']==40 and not w.root['members']['a']['gear'],'reward_success_post_failure');b=w.root;check(w.reward('q')=='AlreadyApplied' and w.root is b and w.root['post']==1,'reward_retry_no_post')
 s=state();i=item('dup');s['stock']['dup']=i;s['members']['a']['gear']['Weapon']=i
 try:validate(s);ok=False
 except AssertionError:ok=True
 check(ok,'duplicate_location')
 # Random insertion orders, assignments and class restrictions: conservation, determinism, monotonicity, idempotence.
 for seed in range(128):
  rng=random.Random(seed);s=state();items=[item(str(i),rng.randrange(1,8),rng.randrange(3),rng.choice(('Weapon','UpperBody','Legs')),rng.choice((('warrior',),('priest',),('warrior','priest')))) for i in range(12)];s['stock']={i['id']:i for i in items};n=equip(s,list(s['members']));p=copy.deepcopy(s);p['stock']=dict(reversed(list(p['stock'].items())));p['members']=dict(reversed(list(p['members'].items())))
  check(n==equip(p,list(p['members'])) and n==equip(n,list(n['members'])) and inventory(n)==inventory(s),'seed/'+str(seed),'equipment_property_scenarios')
def load(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/'Tools'/f'{name}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def regressions():
 # Re-execute ONLY the historical model section, not obsolete source-text or baseline gates.
 # The archived complete verifier remains byte-identical. No C# execution is implied.
 path=ROOT/'Tools/verify_sprint8.py';source=path.read_text();prefix=source.split(' lexical=module(\'verify_sprint6\').lexical')[0]
 scope={'__file__':str(path),'__name__':'historical_model_only'};exec(compile(prefix,'historical_sprint8_reference_section','exec'),scope)
 args=sys.argv;sys.argv=['verify_sprint8.py','--baseline','not-used-in-model-section']
 try:scope['main']()
 finally:sys.argv=args
 for category,count in scope['COUNTS'].items():COUNTS['regression_'+category]=count
 print('Historical models re-executed; historical source/baseline gates intentionally excluded.')
def static(baseline):
 src=ROOT/'Assets/_Project/Scripts';read=lambda p:(src/p).read_text();e=read('Equipment/AutoEquipService.cs');q=read('Quests/QuestManager.cs');r=read('Rewards/RewardApplicationManager.cs');s=read('Adventurers/AdventurerState.cs');rules=read('Equipment/EquipmentEvaluationRules.cs');p=read('Equipment/HealingPotionAssignmentService.cs');m=read('Equipment/EquipmentManager.cs')
 checks={
 'score_before_rarity':rules.index('left.CompareTo(right)')<rules.index('(int)a.Definition.Rarity'),
 'strict_improvement':'CompareQuality(candidate,current,cls.Roles)<=0' in e,
 'stable_stock_order':'CandidateOrder(candidate,best)<0' in e,
 'ordinal_member_order':'ids.Sort(StringComparer.Ordinal)' in e,
 'fixed_point':'while(passChanged)' in e,
 'stock_only':'foreach(var candidate in stock.Values)' in e,
 'return_old':'stock.Add(current.InstanceId,current)' in e,
 'slots':['Weapon','UpperBody','Legs']==re.findall(r'EquipmentSlot\.(\w+)',e),
 'class_slot_guard':'Compatible(candidate,member,slot)' in e,
 'dead_guard':'if(a.IsDead)' in e,
 'lock_guard':'EquipmentConsistency.Locked(before,id)' in e,
 'healer_then_leader':'AdventurerRole.Healing)!=0?0:a.Id==party.LeaderId?1:2' in p,
 'potion_ordinal':'string.CompareOrdinal(a.Id,b.Id)' in p,
 'potion_eligibility':'a.CanDeployAt(now)' in p,
 'potion_max_one':'if(held>=1)continue' in p and '{{key,1}}' in p,
 'shortage_not_failure':'missing.Add(a.Id);continue' in p,
 'equipment_preserved_health':'Progression,Equipment,Potions' in s,
 'equipment_preserved_progression':'progression,Equipment,Potions' in s,
 'return_checked':'checked(n+p.Value)' in m,
 'conservation_auto':'EquipmentConsistency.Conservation(before,after)' in e,
 'conservation_potion':'EquipmentConsistency.Conservation(before,after)' in p,
 'conservation_return':'EquipmentConsistency.Conservation(before,after)' in m,
 'read_only_panel':'TryPublish' not in m.split('public EquipmentPanelModel GetPanelModel')[1],
 'start_no_early_refresh':'RefreshAt(now)' not in q.split('public QuestResult TryStartQuest')[1].split('public QuestResolutionResult')[0],
 'start_target_only':'Prepare(before,party.MemberIds,adventurers)' in q,
 'start_single_publish':q.split('public QuestResult TryStartQuest')[1].split('public QuestResolutionResult')[0].count('TryPublishResolution')==1,
 'resolve_return_before_publish':q.index('PrepareReturns(staged')<q.rindex('TryPublishResolution'),
 'reward_post_after_commit':r.index('store.TryPublish')<r.index('equipment.TryReevaluateAll'),
 'reward_retry_before_post':r.index('if(!prepared.HasNewApplication)return prepared')<r.index('equipment.TryReevaluateAll'),
 'reward_global_identity':'EquipmentConsistency.Validate(next,false)' in r,
 'reward_post_failure_separate':'catch(Exception){post=new EquipmentResult' in r,
 'snapshot_cas':'ReferenceEquals(Current,expected)' in read('Adventurers/GuildRuntimeStore.cs'),
 }
 for name,ok in checks.items():check(ok,name,'bounded_source_checks')
 for path in sorted((ROOT/'Assets').rglob('*.cs')):check(load('verify_sprint6').lexical(path),str(path.relative_to(ROOT)),'lexical_source_files')
 allowed={'Assets/_Project/Scripts/'+p for p in ['Adventurers/AdventurerState.cs','Adventurers/GuildRuntimeStore.cs','Inventory/ItemDefinitionData.cs','Quests/QuestManager.cs','Quests/QuestResult.cs','Quests/Simulation/QuestResolutionResult.cs','Rewards/RewardApplicationManager.cs','Rewards/RewardApplicationResult.cs']}
 allowed.update('Assets/_Project/Tests/EditMode/Rewards/'+p for p in ['RewardApplicationTests.cs','RewardAtomicityTests.cs'])
 changed=set();rows=[]
 with zipfile.ZipFile(baseline) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=n.split('/',1)[1];path=ROOT/rel;same=path.exists() and path.read_bytes()==z.read(n)
   if not same:changed.add(rel)
   check(same or rel in allowed,rel,'baseline_unchanged' if same else 'baseline_documented_change');rows.append(rel)
  for directory in ['Quests/Simulation','Progression']:
   for path in (src/directory).glob('*.cs'):
    if path.name=='QuestResolutionResult.cs':continue
    rel=path.relative_to(ROOT).as_posix();name=next(n for n in z.namelist() if n.endswith('/'+rel));check(path.read_bytes()==z.read(name),rel,'formula_files_unchanged')
 check(changed==allowed,'exact_changed_set','bounded_source_checks')
 guids=[re.search(r'^guid: (\w+)',p.read_text(),re.M).group(1) for p in (ROOT/'Assets').rglob('*.meta')];check(len(guids)==len(set(guids)),'unique_meta_guids','bounded_source_checks')
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--baseline',required=True);args=parser.parse_args();run_reference();regressions();static(args.baseline);print('RESULT '+json.dumps(COUNTS,sort_keys=True));print('C# compilation, NUnit, Unity, Xcode, iPhone: NOT EXECUTED')

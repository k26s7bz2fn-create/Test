using System;
using GuildGame.Tests;
public static class Program
{
    public static int Main()
    {
        int passed=0,failed=0;
        foreach(var name in CombatCoreCases.Names)
        {try{CombatCoreCases.Run(name);Console.WriteLine("PASS "+name);passed++;}catch(Exception ex){Console.WriteLine("FAIL "+name+": "+ex);failed++;}}
        Console.WriteLine("C# cases: "+passed+" passed, "+failed+" failed");return failed==0?0:1;
    }
}

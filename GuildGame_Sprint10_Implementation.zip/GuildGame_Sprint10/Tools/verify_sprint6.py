#!/usr/bin/env python3
"""Independent executable specification and LIMITED source checks. Does not compile/run C#.
Run: python Tools/verify_sprint6.py --baseline /path/GuildGame_Sprint5_Implementation.zip
"""
import argparse,copy,hashlib,json,pathlib,re,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
MAX=2**63-1
COUNTS={'reference_scenarios':0,'source_checks':0,'baseline_unchanged':0,'baseline_intentional':0}
def check(ok,name,category):
 if not ok:raise AssertionError(name)
 COUNTS[category]+=1;print('PASS '+category+' '+name)
class Model:
 def __init__(self,c):
  self.groups={i+1:{'members':list(g['members']),'leader':g['members'][0]} for i,g in enumerate(c['groups'])}
  self.quests={i:{'status':'Available','party':None,'members':[],'leader':None,'start':None,'completion':None} for i in range(1,5)}
  self.now=1000;self.broken=False;self.observed=None;self.duration=c['duration']
 def occupied(self):return [q for q in self.quests.values() if q['status'] in ('Active','CompletedPendingResolution')]
 def bound(self,p):return any(q['party']==p for q in self.occupied())
 def time_error(self):return 'ClockUnavailable' if self.broken else 'InvalidTimestamp' if self.now<0 else None
 def refresh(self):
  e=self.time_error()
  if e:return e
  for q in self.quests.values():
   if q['status']=='Active' and self.now>=q['completion']:q['status']='CompletedPendingResolution'
  self.observed=self.now;return 'Success'
 def action(self,a):
  op=a['op'];q=a['quest'];p=a['party'];m=a['member'];target=a['target']
  if op=='time':self.now=a['now'];return 'Success'
  if op=='clock_error':self.broken=True;return 'Success'
  if op in ('read','panel'):return 'Success'
  if op=='refresh':return self.refresh()
  if op=='register':return 'DuplicateQuestInstance' if q in self.quests else 'Success'
  if op=='start':
   error=self.refresh()
   if error!='Success':return error
   if q<0:return 'InvalidQuestInstanceId'
   if q not in self.quests:return 'UnknownQuest'
   quest=self.quests[q]
   if quest['status']!='Available':return 'QuestNotAvailable'
   if p<0:return 'InvalidPartyId'
   if p not in self.groups:return 'UnknownParty'
   group=self.groups[p]
   if not 1<=len(group['members'])<=6:return 'InvalidPartyComposition'
   if self.bound(p):return 'PartyAlreadyCommitted'
   booked={m for running in self.occupied() for m in running['members']}
   if booked.intersection(group['members']):return 'MemberAlreadyCommitted'
   if len(self.occupied())>=3:return 'ActiveQuestLimitReached'
   if self.duration*1000>MAX or self.now+self.duration*1000>MAX:return 'TimestampOverflow'
   self.quests[q]={'status':'Active','party':p,'members':list(group['members']),'leader':group['leader'],'start':self.now,'completion':self.now+self.duration*1000}
   return 'Success'
  if self.bound(p) or op=='transfer' and self.bound(target):return 'PartyNotEditable'
  if op=='party_add':self.groups[p]['members'].append(m);return 'Success'
  raise AssertionError('Unexpected unlocked fixture operation '+op)

def run_case(c):
 model=Model(c)
 for a in c['actions']:
  groups_before=copy.deepcopy(model.groups);quests_before=copy.deepcopy(model.quests);observed=model.observed
  status=model.action(a)
  assert status==a['expected'],(c['name'],a,status)
  if status!='Success':
   assert model.groups==groups_before
   for k,q in model.quests.items():
    for field in ('party','members','leader','start','completion'):assert q[field]==quests_before[k][field]
  if a['op'] in ('read','panel'):assert model.quests==quests_before and model.observed==observed
 for i,expected in enumerate(c['expectedStatuses'],1):assert model.quests[i]['status']==expected
 assert len(model.occupied())==c['expectedOccupied']
 groups=[];members=[]
 for q in model.occupied():
  groups.append(q['party']);members.extend(q['members'])
  assert model.bound(q['party']) and q['members']==model.groups[q['party']]['members']
  assert q['leader']==model.groups[q['party']]['leader']
 assert len(groups)==len(set(groups))<=3 and len(members)==len(set(members))

def lexical(p):
 s=p.read_text();s=re.sub(r'//[^\n]*|/\*.*?\*/|@"(?:""|[^"])*"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'','',s,flags=re.S)
 stack=[];pairs={')':'(',']':'[','}':'{'}
 for char in s:
  if char in '([{':stack.append(char)
  elif char in pairs:
   if not stack or stack.pop()!=pairs[char]:return False
 return not stack

def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);args=p.parse_args()
 cases=json.loads((ROOT/'Assets/_Project/Tests/Fixtures/quest_v01_cases.json').read_text())['cases']
 assert len({c['name'] for c in cases})==len(cases)
 for c in cases:run_case(c);check(True,c['name'],'reference_scenarios')
 src=ROOT/'Assets/_Project/Scripts/Quests';tests=ROOT/'Assets/_Project/Tests/EditMode/Quests'
 paths=sorted(src.glob('*.cs'))+sorted(tests.glob('*.cs'))+[ROOT/'Assets/_Project/Scripts/Data/QuestDefinition.cs']
 for path in paths:check(lexical(path),path.name+' lexical balance','source_checks')
 text=lambda name:(src/name).read_text()
 manager=text('QuestManager.cs');registry=text('QuestActivityRegistry.cs');runtime=text('QuestRuntimeState.cs');catalog=text('QuestCatalog.cs')
 starts=manager[manager.index('public QuestResult TryStartQuest'):manager.index('public bool TryGetQuest')]
 panels=manager[manager.index('public QuestBoardModel GetBoardModel'):]
 checks={
  'same_party_policy_and_roster_required':'parties.UsesDependencies(adventurers, registry)' in manager,
  'single_registry_writer':'Registry already has an authoritative QuestManager' in registry,
  'pending_and_active_both_hold_slot':'Status == QuestStatus.Active || Status == QuestStatus.CompletedPendingResolution' in runtime,
  'limit_three':'MaximumActiveGroups = 3' in registry,
  'leader_and_members_snapshot':'party.MemberIds, party.LeaderId' in runtime,
  'independent_member_reservation_guard':'IsMemberCommitted(member)' in registry,
  'checks_existing_group':'parties.TryGetParty' in manager and 'parties.ValidateComposition' in manager,
  'checks_existing_adventurers':'adventurers.TryGetById' in manager,
  'checked_timestamp_arithmetic':'checked(now + checked(quest.DefinitionSnapshot.ExpectedDurationSeconds * 1000L))' in manager,
  'completion_inclusive':'now >= q.CompletionTimestamp.Value' in manager,
  'only_active_to_pending':'q.Status == QuestStatus.Active' in manager and 'q.MarkPending()' in manager,
  'no_resolved_construction':'QuestStatus.Resolved' not in runtime and 'QuestStatus.Resolved' not in manager,
  'start_reads_clock_once':starts.count('ReadTime(out var now)')==1,
  'start_one_publish':starts.count('registry.Publish(')==1,
  'read_models_do_not_refresh':'RefreshAt(' not in panels and 'ReadTime(' not in panels,
  'no_roster_or_party_mutation':not re.search(r'parties.Try(Add|Remove|Set|Transfer|Dissolve)|adventurers.TryAdd',manager),
  'no_simulation_or_save':not re.search(r'QuestSimulationService|SaveManager|PlayerPrefs|InventoryManager|CombatManager',manager),
  'immutable_data_copy':'Array.AsReadOnly(loot.ToArray())' in catalog,
  'duration_and_rewards_validated':'durationSeconds <= 0' in catalog and 'gold < 0 || xp < 0' in catalog,
  'four_types':len(re.findall(r'\b(?:Gathering|Delivery|MonsterHunt|Rescue)\s*=',text('QuestType.cs')))==4,
 }
 for name,ok in checks.items():check(ok,name,'source_checks')
 changed='Assets/_Project/Scripts/Party/PartyManager.cs'
 needle='        public int Count => parties.Count;'
 addition='\n\n        // Sprint 6: reject mismatched quest/party composition roots; no gameplay mutation.\n        internal bool UsesDependencies(AdventurerManager members, IPartyEditPolicy policy) =>\n            ReferenceEquals(adventurers, members) && ReferenceEquals(editPolicy, policy);'
 with zipfile.ZipFile(args.baseline) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=n.split('/',1)[1];original=z.read(n);current=(ROOT/rel).read_bytes()
   if rel==changed:
    check(current==original.decode().replace(needle,needle+addition).encode(),rel+' exact allowed addition','baseline_intentional')
   else:check(current==original,rel,'baseline_unchanged')
 print('RESULT '+json.dumps(COUNTS,sort_keys=True))
 print('C# compilation / NUnit / Unity: NOT EXECUTED by this verifier.')
if __name__=='__main__':main()

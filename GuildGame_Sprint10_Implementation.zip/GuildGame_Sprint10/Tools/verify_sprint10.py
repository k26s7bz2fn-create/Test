#!/usr/bin/env python3
"""Independent Python reference, golden RNG vectors and bounded source checks. NOT C# execution."""
import copy,hashlib,json,pathlib,struct,sys,re,zipfile,argparse,importlib.util
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parents[1];COUNT={}
# hp,mana,attack,defense,crit,front,roles,basic cooldown ticks
P={'class.warrior':(60,0,8,3,1000,True,3,8),'class.rogue':(40,0,10,1,2000,True,2,8),'class.mage':(36,24,9,1,1000,False,10,8),'class.priest':(42,24,5,1,1000,False,12,8),'enemy.goblin.melee':(24,0,6,1,1000,True,0,8),'enemy.goblin.ranged':(18,0,5,0,1000,False,0,8),'enemy.goblin.brute':(48,0,9,2,1000,True,0,12),'enemy.goblin.boss':(96,0,11,3,1000,True,0,12)}
# id suffix, cooldown, mana, effect, raw override
A={'class.warrior':[('shield_bash',24,0,'Stun',None),('strike',8,0,None,None)],'class.rogue':[('bleeding_cut',24,0,'Bleed',None),('strike',8,0,None,None)],'class.mage':[('burning_bolt',24,6,'Burn',None),('bolt',8,4,None,None),('staff_strike',8,0,None,3)],'class.priest':[('stabilize',16,6,'stabilize',None),('heal',8,6,'heal',None),('strike',8,0,None,None)]}
for d in P:
 if d.startswith('enemy.'):
  A[d]=([('poison_shot',24,0,'Poison',None)] if d.endswith('ranged') else [('stunning_blow',24,0,'Stun',None)] if d.endswith('brute') else [])+[('basic_attack',P[d][7],0,None,None)]
def check(ok,name,category='python_reference'):
 if not ok:raise AssertionError(name)
 COUNT[category]=COUNT.get(category,0)+1;print('PASS',category,name)
def encode(fields):
 return b''.join(struct.pack('>I',len(v.encode('utf-8')))+v.encode('utf-8') for v in fields)
def digest(fields):return hashlib.sha256(encode(fields)).hexdigest()
def member(id,d,hp=None):
 return dict(id=id,d=d,ally=d.startswith('class.'),hp=P[d][0] if hp is None else hp,mana=P[d][1],life='Alive',target=None,ready={},action=0,status={},history=set(),incap=False,reason='None',due=None,death=None)
def input_fields(members,seed):
 f=['combat.input.v1','combat.rules.v1',str(len(members))]
 for m in sorted(members,key=lambda x:x['id']):f += [m['id'],'Adventurer' if m['ally'] else 'Enemy',m['id'] if m['ally'] else '',m['d'],str(P[m['d']][6]),str(m['hp']),str(m['mana'])]+['']*6
 return f+[f'{seed:016x}']
def hit(draw,p):return draw*10000<p*(2**32)
class Model:
 def __init__(self,members=None,seed=7):
  self.m=sorted(members or [member('a','class.warrior'),member('b','class.priest'),member('x','enemy.goblin.brute'),member('y','enemy.goblin.ranged')],key=lambda m:m['id']);self.seed=seed;self.fp=digest(input_fields(self.m,seed));self.tick=0;self.seq=0;self.phase='Running';self.victory=None;self.outcome=None;self.events=[]
 def draw(self,m,purpose):
  h=hashlib.sha256(encode(['combat.rng.sha256.v1','combat.rules.v1',f'{self.seed:016x}',self.fp,str(self.tick),m['id'],str(self.seq),purpose])).digest();self.seq+=1;return int.from_bytes(h[:4],'big')
 def damage(self,m,amount):
  m['hp']=max(0,m['hp']-amount)
  if m['hp']==0 and m['life']=='Alive':
   m['status']={}
   if m['ally']:m['life']='Incapacitated';m['incap']=True;m['due']=self.tick+32
   else:m['life']='Dead';m['death']=self.tick
 def status(self,m,kind,source):
  if m['life']!='Alive':return
  old=m['status'].get(kind);m['status'][kind]=dict(source=old['source'] if old else source,end=self.tick+(4 if kind=='Stun' else 16),next=old['next'] if old else 0 if kind=='Stun' else self.tick+4);m['history'].add(kind)
 def death(self,m,collapse):
  purpose='death.collapse' if collapse else 'death.normal';dead=hit(self.draw(m,purpose),6000 if collapse else 2500);m['due']=None;m['status']={};m['hp']=0 if dead else 1;m['life']='Dead' if dead else 'Stabilized'
  if dead:m['death']=self.tick
  else:m['reason']='UnaidedSurvival'
  self.events.append((purpose,m['id']))
 def target(self,a):
  c=[m for m in self.m if m['ally']!=a['ally'] and m['life']=='Alive']
  if any(P[m['d']][5] for m in c):c=[m for m in c if P[m['d']][5]]
  if any(m['ally'] and P[m['d']][5] and P[m['d']][6]&1 for m in c):c=[m for m in c if P[m['d']][6]&1]
  return next((m for m in c if m['id']==a['target']),c[0] if c else None)
 def action(self,a):
  target=self.target(a) if self.phase=='Running' else None
  if self.phase=='Running':a['target']=target['id'] if target else None
  for name,cd,cost,effect,raw in A[a['d']]:
   if self.phase=='Aftermath' and effect!='stabilize':continue
   if a['ready'].get(name,0)>self.tick or cost>a['mana']:continue
   if effect=='stabilize':c=sorted([m for m in self.m if m['ally'] and m['life']=='Incapacitated'],key=lambda m:(m['due'],m['id']));t=c[0] if c else None
   elif effect=='heal':
    from fractions import Fraction
    c=sorted([m for m in self.m if m['ally'] and m['life']=='Alive' and m['hp']*2<=P[m['d']][0]],key=lambda m:(Fraction(m['hp'],P[m['d']][0]),m['id']));t=c[0] if c else None
   else:t=target
   if t is None or effect in t['status']:continue
   if effect=='stabilize':t.update(life='Stabilized',hp=1,due=None,reason='Healer',status={})
   elif effect=='heal':t['hp']=min(P[t['d']][0],t['hp']+12)
   else:
    crit=hit(self.draw(a,'critical'),P[a['d']][4]);self.damage(t,max(1,(P[a['d']][2] if raw is None else raw)-P[t['d']][3])*(2 if crit else 1))
    if effect:self.status(t,effect,a['id'])
   a['mana']-=cost;a['ready'][name]=self.tick+cd;a['action']=self.tick+4;self.events.append((name,a['id'],t['id']));return
 def step(self,fail=False):
  if self.phase not in ('Running','Aftermath'):return False
  n=copy.deepcopy(self);n._tick()
  if fail:return False
  self.__dict__=n.__dict__;return True
 def _tick(self):
  self.tick+=1;self.events=[]
  if self.phase=='Running':
   for m in self.m:
    for k in ['Poison','Bleed','Burn']:
     if m['life']!='Alive':break
     st=m['status'].get(k)
     if st and st['next']<=self.tick<=st['end']:
      self.damage(m,1 if k=='Poison' else 2);self.events.append(('status.'+k,m['id']))
      if m['life']=='Alive':st['next']+=4
   for m in self.m:m['status']={k:v for k,v in m['status'].items() if v['end']>self.tick}
  for m in self.m:
   if m['life']=='Alive' and (self.phase=='Running' or m['d']=='class.priest'):m['mana']=min(P[m['d']][1],m['mana']+1)
  off=(self.tick-1)%len(self.m)
  for a in self.m[off:]+self.m[:off]:
   if a['life']=='Alive' and a['action']<=self.tick and 'Stun' not in a['status'] and (self.phase=='Running' or a['d']=='class.priest'):self.action(a)
  if not any(m['ally'] and m['life']=='Alive' for m in self.m):
   for m in self.m:
    if m['ally'] and m['life']=='Incapacitated':self.death(m,True)
   self.complete('Defeat');return
  for m in self.m:
   if m['ally'] and m['life']=='Incapacitated' and m['due']<=self.tick:self.death(m,False)
  if not any(not m['ally'] and m['life']=='Alive' for m in self.m):
   if self.victory is None:self.victory=self.tick
   if not any(m['ally'] and m['life']=='Incapacitated' for m in self.m):self.complete('Victory');return
   self.phase='Aftermath'
   for m in self.m:m['status']={}
  if self.phase=='Running' and self.tick>=480:self.phase='TechnicalAbort'
 def complete(self,outcome):
  self.phase='Completed';self.outcome=outcome
  for m in self.m:m['status']={}
 def signature(self):
  wipe=all(m['life']=='Dead' for m in self.m if m['ally']);result='' if self.outcome is None else self.outcome+'/'+str(wipe)
  return f'{self.tick}|{self.phase}|{self.seq}|{result}|'+ ';'.join(f"{m['id']},{m['hp']},{m['mana']},{m['life']},{m['reason']},{m['death'] if m['death'] is not None else ''}" for m in self.m)
 def finish(self):
  while self.step():pass
  return self.signature()
def held(m):
 for x in m.m:x['action']=999
 return m
def tests():
 check(encode(['a','']).hex()=='000000016100000000','length_prefix')
 check(hit(0,1000) and not hit(2**32-1,1000) and not hit(0,0) and hit(2**32-1,10000),'probability_boundaries')
 for seed in [0,1,7,2**64-1]:
  m=Model(seed=seed);n=Model(list(reversed(copy.deepcopy(m.m))),seed);check(m.fp==n.fp and m.finish()==n.finish(),'seed_and_order_'+str(seed))
 m=held(Model());m.m[0]['hp']=30;m.m[1]['action']=0;m.step();check(m.events[0][0]=='heal' and m.m[0]['hp']==42,'heal_exact_half')
 m=held(Model());m.m[0].update(life='Incapacitated',hp=0,incap=True,due=1);m.m[1]['action']=0;m.step();check(m.events[0][0]=='stabilize' and m.seq==0 and m.m[0]['life']=='Stabilized','stabilize_deadline_priority')
 m=held(Model());
 for x in m.m[:2]:x.update(life='Incapacitated',hp=0,incap=True,due=1)
 m.step();check(m.outcome=='Defeat' and m.seq==2 and all(e[0]=='death.collapse' for e in m.events),'collapse_not_double_roll')
 m=held(Model());m.m[0].update(life='Incapacitated',hp=0,incap=True,due=1);m.step();seq=m.seq;m.step();check(seq==1 and m.seq==1,'normal_once')
 for status,damage in [('Poison',1),('Bleed',2),('Burn',2)]:
  m=held(Model());m.status(m.m[0],status,'x');hp=m.m[0]['hp'];pulses=[]
  for i in range(16):m.step();pulses += [m.tick for e in m.events if e[0]=='status.'+status]
  check(pulses==[4,8,12,16] and m.m[0]['hp']==hp-4*damage and not m.m[0]['status'],'dot_'+status)
 m=held(Model());m.m[0]['hp']=1
 for k in ['Burn','Bleed','Poison']:m.status(m.m[0],k,'x')
 for i in range(4):m.step()
 check(len(m.events)==1 and m.events[0][0]=='status.Poison','status_order')
 m=Model();m.status(m.m[0],'Bleed','first');m.tick=2;m.status(m.m[0],'Bleed','second');check(m.m[0]['status']['Bleed']==dict(source='first',end=18,next=4),'reapplication')
 m=held(Model());m.tick=479;m.m[0]['action']=480;m.step();check(m.phase=='TechnicalAbort' and m.tick==480 and len(m.events)>0,'tick480_full_then_abort');sig=m.signature();check(not m.step() and m.signature()==sig,'abort_terminal')
 m=held(Model());m.tick=479;m.m[0].update(life='Incapacitated',hp=0,incap=True,due=511)
 for x in m.m[2:]:x.update(life='Dead',hp=0)
 m.step();check(m.phase=='Aftermath','provisional_at480');m.finish();check(m.tick==511 and m.outcome=='Victory','aftermath_after_limit')
 m=held(Model([member('a','class.warrior'),member('b','class.priest'),member('c','class.mage'),member('x','enemy.goblin.melee')]));m.phase='Aftermath';m.victory=0;m.m[0].update(life='Incapacitated',hp=0,due=32,incap=True);m.m[1]['mana']=m.m[2]['mana']=0;m.m[3].update(life='Dead',hp=0);m.step();check(m.m[1]['mana']==1 and m.m[2]['mana']==0,'aftermath_priest_only')
 m=Model();before=copy.deepcopy(m.__dict__);check(not m.step(fail=True) and m.__dict__==before,'fault_atomic')
 # Wall-clock adapter reference: speeds/partitions never alter the tick stream.
 expected=Model().finish()
 for speed in (1,2,4):
  for chunk in (1,17,250,1000):
   m=Model();pending=0
   for _ in range(130000):
    if m.phase not in ('Running','Aftermath'):break
    pending += chunk*speed
    while pending>=250 and m.phase in ('Running','Aftermath'):m.step();pending-=250
   check(m.signature()==expected,'speed/'+str(speed)+'/chunk/'+str(chunk))
 for probability in (1000,2000,2500,6000):
  first_failure=(probability*(2**32)+9999)//10000
  check(hit(first_failure-1,probability) and not hit(first_failure,probability),'exact_probability_boundary/'+str(probability))
 m=held(Model());m.m[0]['hp']=31;m.m[1]['action']=0;m.step();check(m.events[0][0]=='strike','above_heal_threshold')
 m=held(Model());m.m[0]['action']=0;m.m[0]['ready']={'shield_bash':999,'strike':9};m.tick=7;m.step();before=len(m.events);m.step();check(before==0 and m.events[0][0]=='strike' and m.m[0]['ready']['strike']==17,'cooldown_tick9')
 m=held(Model([member('a','class.mage'),member('x','enemy.goblin.boss')]));m.m[0]['action']=0;m.m[0]['ready']={'bolt':99,'burning_bolt':99};m.step();check(m.events[0][0]=='staff_strike','staff_cooldown_fallback')
 m=held(Model([member('a','class.mage'),member('x','enemy.goblin.melee'),member('y','enemy.goblin.melee')]));m.m[0]['action']=0;m.m[0]['target']='y';m.status(m.m[2],'Burn','a');m.step();check(m.events[0]==('bolt','a','y'),'no_status_retarget')
 # Independent bounded property runs across all classes, enemy types and varied seeds.
 for seed in range(32):
  for cls in ['class.warrior','class.rogue','class.mage','class.priest']:
   enemy=['enemy.goblin.melee','enemy.goblin.ranged','enemy.goblin.brute','enemy.goblin.boss'][seed%4]
   m=Model([member('a',cls),member('x',enemy)],seed);other=copy.deepcopy(m);sig=m.finish()
   assert sig==other.finish();assert m.tick<=512
   assert all(0<=x['hp']<=P[x['d']][0] and 0<=x['mana']<=P[x['d']][1] for x in m.m)
   assert m.phase=='TechnicalAbort' or all(not x['status'] for x in m.m)
   check(True,cls+'/'+str(seed),'python_property_scenarios')
def static(baseline):
 src=ROOT/'Assets/_Project/Scripts/Combat';read=lambda name:(src/name).read_text();session=read('CombatSession.cs');rng=read('CombatRandom.cs');inp=read('CombatInput.cs');rules=read('CombatRules.cs');adapter=read('AdventurerCombatAdapter.cs');time=read('CombatTimeController.cs')
 checks={
 'tick250':'TickMilliseconds=250' in rules,'tick480':'LimitTicks=480' in rules,'incap32':'IncapacitatedTicks=32' in rules,'recovery120':'RecoverySeconds=120' in rules,
 'rule_version':'combat.rules.v1' in rules,'rng_version':'combat.rng.sha256.v1' in rules,'schema':'combat.input.v1' in rules,
 'rotation':'(tick-1)%members.Count' in session,'no_removal':'members.Remove' not in session,
 'staged_publication':session.index('var next=Advance(before)')<session.index('State=next'),
 'collapse_before_normal':session.index('if(!anyAlive)')<session.index('Death(m,tick,false'),
 'healer_aftermath_only':'phase==CombatPhase.Running||m.IsPriest' in session,
 'status_order':'CombatStatusKind.Poison,CombatStatusKind.Bleed,CombatStatusKind.Burn' in session,
 'source_preserved':'kind,old.SourceCombatantId' in session,
 'pulses_end_inclusive':'tick<=s.ExpiresAtTick' in session,
 'no_status_on_downed':'if(target.Life!=CombatLife.Alive)return' in session,
 'no_independent_special_retarget':session.count('CombatTargeting.Attack(')==1,
 'limit_after_actions':session.index('Act(actor')<session.index('tick>=CombatRules.LimitTicks'),
 'limit_running_only':'phase==CombatPhase.Running&&tick>=' in session,
 'end_clears_status':'foreach(var m in members)m.Statuses.Clear()' in session,
 'rng_sha':'SHA256.Create()' in rng,'seed_hex16':'ToString("x16",CultureInfo.InvariantCulture)' in rng,
 'uint32_big_endian':'((uint)b[0]<<24)' in rng,'uint64_probability':'(ulong)draw*10000UL' in rng,
 'length_prefix':'stream.WriteByte((byte)(n>>24))' in rng,'sequence_increment':'checked(sequence+1UL)' in session,
 'pause_no_advance':'if(Speed==0)return' in time,'clock_no_systemtime':all('DateTime' not in p.read_text() for p in src.glob('*.cs')),
 'no_unity':all('using UnityEngine' not in p.read_text() and 'UnityEngine.Random' not in p.read_text() for p in src.glob('*.cs')),
 'no_guild_publish':'TryPublish' not in adapter and 'ReplaceMembers' not in adapter,
 'adapter_quest_lock':'EquipmentConsistency.Locked(snapshot,a.Id)' in adapter,
 'adapter_full_hp':'CombatRules.Profile(a.ClassId).MaxHP' in adapter,
 'neutral_profile':'EquipmentValues' not in inp+rules+session,
 'empty_consumption':'Array.AsReadOnly(Array.Empty<string>())' in read('CombatResult.cs'),
 }
 for k,v in checks.items():check(v,k,'bounded_source_checks')
 spec=importlib.util.spec_from_file_location('s6',ROOT/'Tools/verify_sprint6.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 for p in sorted((ROOT/'Assets').rglob('*.cs')):check(m.lexical(p),p.relative_to(ROOT).as_posix(),'lexical_source_files')
 with zipfile.ZipFile(baseline) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=n.split('/',1)[1];check((ROOT/rel).read_bytes()==z.read(n),rel,'baseline_byte_identical')
 if (ROOT/'Assets/_Project/Scripts/Combat.meta').exists():
  guids=[re.search(r'^guid: (\w+)',p.read_text(),re.M).group(1) for p in (ROOT/'Assets').rglob('*.meta')];check(len(guids)==len(set(guids)),'meta_guids_unique','bounded_source_checks')
def vectors():
 result=[]
 for seed in (0,1,7,2**64-1):
  m=Model(seed=seed);first=int.from_bytes(hashlib.sha256(encode(['combat.rng.sha256.v1','combat.rules.v1',f'{seed:016x}',m.fp,'1','a','0','critical'])).digest()[:4],'big');result.append(dict(seed=str(seed),fingerprint=m.fp,draw=first,signature=m.finish()))
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);p.add_argument('--vectors',action='store_true');args=p.parse_args()
 tests();static(args.baseline)
 if args.vectors:print('VECTORS '+json.dumps(vectors()))
 print('RESULT '+json.dumps(COUNT,sort_keys=True));print('C#/NUnit/Unity/Xcode/iPhone NOT EXECUTED')

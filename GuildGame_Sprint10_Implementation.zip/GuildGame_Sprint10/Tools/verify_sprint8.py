#!/usr/bin/env python3
"""Python reference rules + bounded C# source checks. DOES NOT execute C# or Unity."""
import argparse,copy,hashlib,importlib.util,json,pathlib,re,sys,zipfile
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parents[1]
COUNTS={}
THRESHOLDS=[0,30,70,120,180,250,330,420,520,630]
MAX=2**63-1
SKILLS={
 'warrior':['steadfastness','weapon_training','endurance','guard','precision','armor_training','resilience','striking_power','discipline'],
 'rogue':['weapon_training','precision','agility','timing','dexterity','focus','weak_point_study','coordination','attack_discipline'],
 'mage':['spell_training','focus','spell_precision','channeling','control','arcane_study','spell_power','composure','casting_discipline'],
 'priest':['healing_study','focus','support_training','care','composure','healing_precision','healing_power','vigilance','support_discipline']}
POTION='item.potion.healing.basic';SWORD='item.weapon.training_sword.common'
ITEMS={f'item.weapon.training_{x}.common':'Instance' for x in ('sword','dagger','staff','mace')}
ITEMS.update({'item.armor.training_upper.common':'Instance','item.armor.training_legs.common':'Instance',POTION:'Stack'})
def check(ok,name,category='reward_reference'):
 if not ok:raise AssertionError(name)
 COUNTS[category]=COUNTS.get(category,0)+1;print('PASS',category,name)
def progression(old,xp,cls):
 if not 0<=old<=630 or not 0<=xp<=MAX or cls not in SKILLS:raise ValueError('progression')
 used=min(xp,630-old);total=old+used;level=sum(t<=total for t in THRESHOLDS)
 points=3*(level-1);ranks=[points//9+(i<points%9) for i in range(9)]
 return {'xp':total,'level':level,'used':used,'overflow':xp-used,'ranks':ranks}
class Reject(Exception):pass
class Model:
 def __init__(self):
  self.root={'members':{1:{'xp':0,'dead':False,'recovery':None},2:{'xp':0,'dead':False,'recovery':None}},'gold':0,'equipment':{},'potions':{},'ledger':{},'outputs':set(),'time':2000}
  self.receipt={'quest':'q1','resolution':'r1','status':'Resolved','members':[(1,30,False,'xp1'),(2,30,False,'xp2')],'gold':40,'goldId':'gold','loot':[('loot1',POTION,2),('loot2',SWORD,2)]}
 def apply(self,fail=False,conflict=False):
  before=self.root;r=self.receipt
  try:
   if r['status']!='Resolved':raise Reject('QuestNotResolved')
   if r['quest'] in before['ledger']:
    if before['ledger'][r['quest']]!=r:raise Reject('RewardIdentityConflict')
    return 'AlreadyApplied'
   nxt=copy.deepcopy(before);seen=set();recipients=set()
   def output(o):
    if not o or o in seen or o in before['outputs']:raise Reject('RewardIdentityConflict')
    seen.add(o)
   output(r['goldId'])
   for who,xp,dead,oid in r['members']:
    if who in recipients or who not in (1,2) or dead and xp!=0:raise Reject('InvalidRecipientContract')
    recipients.add(who)
    if xp<0:raise Reject('InvalidRewardAmount')
    output(oid)
    if who not in nxt['members']:raise Reject('UnknownRecipient')
    m=nxt['members'][who];m['xp']=progression(m['xp'],xp,'warrior')['xp']
   if recipients!={1,2}:raise Reject('InvalidRecipientContract')
   if r['gold']<0:raise Reject('InvalidRewardAmount')
   nxt['gold']+=r['gold']
   if nxt['gold']>MAX:raise Reject('NumericOverflow')
   for oid,item,quantity in r['loot']:
    output(oid)
    if quantity<=0:raise Reject('InvalidRewardAmount')
    if item not in ITEMS:raise Reject('UnknownItemDefinition')
    if ITEMS[item]=='Stack':
     nxt['potions'][item]=nxt['potions'].get(item,0)+quantity
     if nxt['potions'][item]>MAX:raise Reject('NumericOverflow')
    else:
     for i in range(quantity):
      iid=f'{oid}/instance/{i}'
      if iid in nxt['equipment']:raise Reject('RewardIdentityConflict')
      nxt['equipment'][iid]=item
   nxt['ledger'][r['quest']]=copy.deepcopy(r);nxt['outputs'].update(seen)
   if fail:raise Reject('PreparationFailed')
   if conflict:
    external=copy.deepcopy(before);external['time']=3000;self.root=external
   if self.root is not before:raise Reject('StaleState')
   self.root=nxt;return 'Applied'
  except Reject as e:return str(e)
def module(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/'Tools'/f'{name}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--baseline',required=True);args=parser.parse_args()
 fixture=json.loads((ROOT/'Assets/_Project/Tests/Fixtures/reward_application_v01_cases.json').read_text())
 for c in fixture['progression']:
  r=progression(c['old'],c['grant'],'warrior')
  for k,v in c['expected'].items():assert r[k]==v,(c['name'],k,r[k],v)
  check(True,c['name'],'progression_reference')
 for cls in SKILLS:
  for level,xp in enumerate(THRESHOLDS,1):
   r=progression(0,xp,cls);assert r['level']==level and sum(r['ranks'])==(level-1)*3 and max(r['ranks'])<=3
   direct=r;total=0
   for step in range(1,level):total=progression(total,THRESHOLDS[step]-THRESHOLDS[step-1],cls)['xp']
   assert progression(0,total,cls)['ranks']==direct['ranks']
   check(True,f'{cls}/F{level}/batched_equals_stepped','skill_reference')
 # Each rejection also checks exact prior root identity and value, not only a return code.
 def rejection(name,setup,expected):
  m=Model();setup(m);before=m.root;saved=copy.deepcopy(before);actual=m.apply()
  check(actual==expected and m.root is before and m.root==saved,name)
 for status in ['Available','Active','CompletedPendingResolution']:
  rejection('reject_'+status,lambda m,s=status:m.receipt.update(status=s),'QuestNotResolved')
 rejection('negative_xp',lambda m:m.receipt.update(members=[(1,-1,False,'xp1'),(2,30,False,'xp2')]),'InvalidRewardAmount')
 rejection('dead_original_positive_xp',lambda m:m.receipt.update(members=[(1,30,True,'xp1'),(2,30,False,'xp2')]),'InvalidRecipientContract')
 rejection('duplicate_recipient',lambda m:m.receipt.update(members=[(1,30,False,'xp1'),(1,30,False,'xp2')]),'InvalidRecipientContract')
 rejection('missing_recipient',lambda m:m.root['members'].pop(1),'UnknownRecipient')
 rejection('negative_gold',lambda m:m.receipt.update(gold=-1),'InvalidRewardAmount')
 rejection('gold_overflow',lambda m:m.root.update(gold=MAX),'NumericOverflow')
 rejection('potion_overflow',lambda m:m.root['potions'].update({POTION:MAX}),'NumericOverflow')
 rejection('unknown_item',lambda m:m.receipt.update(loot=[('x','unknown',1)]),'UnknownItemDefinition')
 rejection('zero_loot',lambda m:m.receipt.update(loot=[('x',POTION,0)]),'InvalidRewardAmount')
 rejection('negative_loot',lambda m:m.receipt.update(loot=[('x',POTION,-1)]),'InvalidRewardAmount')
 rejection('duplicate_output',lambda m:m.receipt.update(loot=[('xp1',POTION,1)]),'RewardIdentityConflict')
 m=Model();before=m.root;check(m.apply(fail=True)=='PreparationFailed' and m.root is before,'failure_after_preparation')
 check(m.apply()=='Applied' and m.root['gold']==40 and len(m.root['equipment'])==2 and m.root['potions'][POTION]==2,'atomic_complete_application')
 before=m.root;check(m.apply()=='AlreadyApplied' and m.root is before,'retry_no_mutation')
 m.receipt['gold']=41;check(m.apply()=='RewardIdentityConflict' and m.root is before,'changed_receipt_conflict')
 m=Model();check(m.apply(conflict=True)=='StaleState' and m.root['time']==3000 and m.root['gold']==0 and not m.root['ledger'],'snapshot_conflict')
 m=Model();m.root['members'][1]['dead']=True;m.root['members'][2]['recovery']=90000;m.apply()
 check(m.root['members'][1]['dead'] and m.root['members'][1]['xp']==30 and m.root['members'][2]['recovery']==90000,'later_death_and_injury_preserved')
 m=Model();m.receipt.update(members=[(1,0,True,'xp1'),(2,30,False,'xp2')]);m.root['members'][1]['dead']=True;m.apply()
 check(m.root['members'][1]['xp']==0 and m.root['members'][1]['dead'],'original_death_zero_xp')
 m=Model();m.receipt.update(gold=0,loot=[],members=[(1,0,False,'xp1'),(2,0,False,'xp2')]);check(m.apply()=='Applied' and len(m.root['ledger'])==1 and m.apply()=='AlreadyApplied','zero_rewards_recorded')
 m=Model();m.receipt['loot']=[('a',POTION,1000000),('b',POTION,1000000)];m.apply();check(m.root['potions'][POTION]==2000000,'unlimited_gameplay_stack')
 # Current-level-at-resolve rule (unchanged S7 formula, exact Decimal arithmetic).
 from decimal import Decimal as D
 check(D(20)*(1+D('.10'))*D('1.20')==D('26.4'),'P8_11_current_level_power')
 # Historical reference models are re-executed, not presented as C# regressions.
 for name,filename,category in [('verify_sprint5','party_v01_cases.json','party_reference_regression'),('verify_sprint6','quest_v01_cases.json','quest_reference_regression')]:
  old=module(name)
  for c in json.loads((ROOT/'Assets/_Project/Tests/Fixtures'/filename).read_text())['cases']:old.run_case(c);check(True,c['name'],category)
 old=module('verify_sprint7');cases=json.loads((ROOT/'Assets/_Project/Tests/Fixtures/simulation_v01_cases.json').read_text())['cases']
 for c in cases:
  result=old.simulate(c)
  assert all(result[k]==(D(v) if k in ('power','difficulty') else v) for k,v in c['expected'].items())
  check(True,c['name'],'simulation_reference_examples')
  for seed in range(64):
   a=old.simulate(c,seed);assert a==old.simulate(c,seed)
   assert all(s==0 or 60<=s<=300 for s in a['recovery'])
   assert a['wipe']==(len(a['dead'])==len(c['roles']))
   assert all(a['xp'][i]==0 and a['recovery'][i]==0 for i in range(len(c['roles'])) if i+1 in a['dead'])
   check(True,c['name']+'/'+str(seed),'simulation_seed_scenarios')
 lexical=module('verify_sprint6').lexical
 for p in sorted((ROOT/'Assets').rglob('*.cs')):check(lexical(p),str(p.relative_to(ROOT)),'lexical_source_files')
 src=ROOT/'Assets/_Project/Scripts';read=lambda p:(src/p).read_text()
 r=read('Rewards/RewardApplicationManager.cs');state=read('Adventurers/AdventurerState.cs');store=read('Adventurers/GuildRuntimeStore.cs')
 checks={
  'resolved_gate':'quest.Status!=QuestStatus.Resolved' in r,
  'authoritative_result':'var result=quest.SimulationResult' in r,
  'no_objective_success_gate':'ObjectiveSucceeded' not in r,
  'ledger_before_preparation':r.index('before.RewardLedger.TryGet')<r.index('progression.Prepare'),
  'strict_retry_receipt':'ReferenceEquals(old.Source,result)' in r,
  'output_id_conflicts':'before.RewardLedger.HasOutput(output)' in r,
  'all_original_participants':'participants.Remove(outcome.AdventurerId)' in r and 'participants.Count!=0' in r,
  'original_dead_zero':'outcome.IsDead&&outcome.Xp!=0' in r,
  'no_current_dead_filter':'current.IsDead' not in r,
  'current_health_copy':'current.WithProgression(change.After)' in r,
  'health_preserves_progression':'PersonalityBoldness,Progression);' in state,
  'progression_preserves_health':'AppearanceId,IsDead,RecoveryUntil' in state,
  'one_publication':r.count('store.TryPublish(')==1,
  'ledger_staged':'before.RewardLedger.Add(receipt,outputIds)' in r,
  'single_staged_root':'next=before.WithRewards(ordered,economy,storage.After,ledger)' in r,
  'no_reward_application_in_simulation':'RewardApplication' not in read('Quests/Simulation/QuestSimulationService.cs'),
  'no_simulation_recompute':'Simulate(' not in r,
  'roster_copy_preserves':'before.WithMembers(members)' in store,
  'quest_copy_preserves':'before.WithQuests' in read('Quests/QuestActivityRegistry.cs') and 'before.WithQuests' in read('Quests/QuestManager.cs'),
  'snapshot_members_preserve_all':'members,Quests,ObservedTimestamp,Economy,Storage,RewardLedger' in store,
  'snapshot_quests_preserve_all':'members,quests,observed,Economy,Storage,RewardLedger' in store,
  'xp_cap_before_add':'Math.Min(xp,rules.Cap-before.TotalAppliedXp)' in read('Progression/ProgressionService.cs'),
  'gold_checked':'checked(Gold+amount)' in read('Guild/GuildEconomyState.cs'),
  'potion_checked':'checked(count+o.Quantity)' in read('Inventory/LootApplicationService.cs'),
  'deterministic_equipment_id':'index.ToString(CultureInfo.InvariantCulture)' in read('Inventory/LootApplicationService.cs'),
  'no_loot_random':'Random' not in read('Inventory/LootApplicationService.cs'),
  'preview_no_publish':'TryPublish' not in r.split('public RewardPanelModel GetPanelModel')[1],
  'reentrancy':'if(applying)' in r and 'finally{applying=false;}' in r,
  'stable_root_check':'ReferenceEquals(Current,expected)' in store,
 }
 for name,ok in checks.items():check(ok,name,'bounded_source_checks')
 rules=read('Progression/ProgressionRules.cs');check([int(n) for n in re.search(r'new long\[\]\{([^}]+)',rules).group(1).split(',')]==THRESHOLDS,'approved_xp_thresholds','contract_source_checks')
 check('PointsPerLevel = 3' in rules,'three_points','contract_source_checks')
 skills=read('Progression/ClassSkillAllocationRules.cs')
 for cls,names in SKILLS.items():
  actual=re.findall(r'new SkillDefinition\("(skill\.'+cls+r'\.[^"]+)"',skills)
  check(actual==['skill.'+cls+'.'+n for n in names],cls+'/ordered_skill_ids','contract_source_checks')
 check('MaximumRank => 3' in skills,'skill_rank_three','contract_source_checks')
 items=read('Inventory/ItemCatalog.cs');check(set(re.findall(r'new ItemDefinitionData\("([^"]+)"',items))==set(ITEMS),'seven_item_ids','contract_source_checks')
 allowed={'Assets/_Project/Scripts/'+p for p in ['Adventurers/AdventurerState.cs','Adventurers/GuildRuntimeStore.cs','Quests/QuestManager.cs','Quests/QuestActivityRegistry.cs']}
 changed=set()
 with zipfile.ZipFile(args.baseline) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=n.split('/',1)[1];same=(ROOT/rel).read_bytes()==z.read(n)
   if not same:changed.add(rel)
   check(same or rel in allowed,rel,'baseline_unchanged' if same else 'baseline_documented_change')
 check(changed==allowed,'exact_change_allowlist','bounded_source_checks')
 metas=list((ROOT/'Assets').rglob('*.meta'));guids=[re.search(r'^guid: (\w+)',p.read_text(),re.M).group(1) for p in metas]
 check(len(guids)==len(set(guids)),'unique_meta_guids','bounded_source_checks')
 print('RESULT '+json.dumps(COUNTS,sort_keys=True))
 print('C# / NUnit / Unity / Xcode / iPhone: NOT EXECUTED.')
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Independent Decimal reference model + bounded source checks, NOT C# execution.
Usage: python Tools/verify_sprint7.py --baseline /path/GuildGame_Sprint6_Implementation.zip
"""
import argparse,copy,hashlib,importlib.util,json,pathlib,re,struct,sys,zipfile
from decimal import Decimal as D, ROUND_FLOOR, ROUND_CEILING
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parents[1]
COUNTS={}
def check(ok,name,category='reference'):
 if not ok: raise AssertionError(name)
 COUNTS[category]=COUNTS.get(category,0)+1
 print('PASS',category,name)
def clamp(x,a,b):return max(D(a),min(D(b),x))
def digest(*parts):
 data=b''
 for p in parts:
  b=str(p).encode('utf8');data+=struct.pack('>I',len(b))+b
 return hashlib.sha256(data).digest()
def unit(seed,quest,domain):return D(int.from_bytes(digest(seed,quest,'s7.v1',domain)[:8],'big')>>11)/D(2**53)
def simulate(c,seed=None,bold=0):
 draws={x['domain']:D(x['value']) for x in c['draws']}
 def u(key):
  if seed is not None:return unit(seed,'test.quest',key)
  return draws.get(key,D('.5') if key in ('power','objective') else D('.9'))
 n=len(c['roles']); assert 1<=n<=6
 roles=''.join(c['roles'])
 power=D(10*n)*(1+sum((D(b) for r,b in [('T','.08'),('H','.08'),('D','.04')] if r in roles),D(0)))
 difficulty=D(10*c['recommended'])*D('1.5')**c['rank']*{'Niedrig':D('.8'),'Normal':D(1),'Hoch':D('1.25')}[c['danger']]
 ratio=power/difficulty*(1+D('.05')*(2*u('power')-1));h=clamp((1-ratio)/D('.5'),0,1)
 pr=clamp(h*(D('.45')+D('.40')*D(c['leader'])-D('.03')*D(bold)),0,'.90')
 ps=clamp(D('.10')+D('.80')*ratio,'.05','.98')
 retreat=u('retreat')<pr;success=not retreat and u('objective')<ps
 pk=clamp(D('.45')*(1-ratio),0,'.45')*(D('.35') if retreat else 1)
 pi=clamp(D('.10')+D('.30')*(1-ratio),0,'.40')*(D('.60') if retreat else 1)
 incap=[u('incapacitation/'+str(i+1))<pk for i in range(n)]
 healers=[i for i in range(n) if not incap[i] and 'H' in c['roles'][i]];targets=[i for i in range(n) if incap[i]]
 stabilized=[False]*n
 for healer,target in zip(healers,targets):stabilized[target]=u(f'stabilization/{healer+1}/{target+1}')<D('.65')
 pd=clamp(D('.15')+D('.50')*h+(D('.20') if all(incap) else 0),0,'.90')
 dead=[incap[i] and not stabilized[i] and u('death/'+str(i+1))<pd for i in range(n)]
 injured=[not dead[i] and (incap[i] or u('injury/'+str(i+1))<pi) for i in range(n)]
 wipe=all(dead);factor=D(0) if wipe else D(1) if success else D('.35') if retreat else D('.20')
 share=int((c['baseXp']*factor/n).to_integral_value(rounding=ROUND_FLOOR))
 xp=[0 if dead[i] else share for i in range(n)];gold=c['baseGold'] if success and not wipe else 0
 recovery=[int(clamp(60+180*h+(60 if incap[i] else 0),60,300).to_integral_value(rounding=ROUND_CEILING)) if injured[i] else 0 for i in range(n)]
 loot=1+int((u('lootQuantity')*2).to_integral_value(rounding=ROUND_FLOOR)) if success and not wipe and u('lootDrop')<D('.35') else 0
 return dict(power=power,difficulty=difficulty,ratio=ratio,h=h,pr=pr,ps=ps,retreat=retreat,success=success,
  dead=[i+1 for i in range(n) if dead[i]],recovery=recovery,xp=xp,gold=gold,loot=loot,wipe=wipe,incap=incap,stabilized=stabilized)
def load_module(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/'Tools'/f'{name}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);args=p.parse_args()
 cases=json.loads((ROOT/'Assets/_Project/Tests/Fixtures/simulation_v01_cases.json').read_text())['cases']
 for c in cases:
  out=simulate(c)
  for k,v in c['expected'].items():assert out[k]==(D(v) if k in ('power','difficulty') else v),(c['name'],k,out[k],v)
  check(True,c['name'],'approved_examples')
 # These are Python property scenarios; they never execute the production C# implementation.
 for c in cases:
  for seed in range(64):
   a=simulate(c,seed);b=simulate(c,seed)
   assert a==b
   assert all(s==0 or 60<=s<=300 for s in a['recovery'])
   assert a['wipe']==(len(a['dead'])==len(c['roles']))
   assert not any(a['stabilized'][i] and i+1 in a['dead'] for i in range(len(c['roles'])))
   assert all(a['xp'][i]==0 and a['recovery'][i]==0 for i in range(len(c['roles'])) if i+1 in a['dead'])
   assert not a['wipe'] or (a['gold']==0 and a['loot']==0 and sum(a['xp'])==0)
   assert not a['retreat'] or (a['gold']==0 and a['loot']==0)
   check(True,c['name']+'/seed/'+str(seed),'seed_property_scenarios')
 check(unit(1,'q','power')!=unit(2,'q','power'),'distinct_seed_noise')
 check(digest('a','bc')!=digest('ab','c'),'length_prefix_avoids_ambiguous_inputs')
 check(unit(1,'q','power')!=unit(1,'q','injury/1'),'domain_separation')
 a=simulate(cases[5],bold=-1);b=simulate(cases[5],bold=1)
 check(a['pr']-b['pr']==D('.048') and a['power']==b['power'],'small_personality_only_retreat')
 check(simulate(cases[3])['retreat'] and not simulate(cases[4])['retreat'],'good_leader_earlier_retreat')
 check(simulate(cases[6])['incap']==[True,True] and not simulate(cases[6])['wipe'],'collapse_is_not_wipe')
 # Recovery and authoritative commit specification, with explicit fault injection before publication.
 class Store:
  def __init__(self):self.root={'status':'CompletedPendingResolution','health':{'dead':False,'until':None},'result':None}
  def locked(self):return self.root['status'] in ('Active','CompletedPendingResolution')
  def resolve(self,outcome,fail=False):
   if self.root['status']=='Resolved':return False,self.root['result']
   if self.root['status']!='CompletedPendingResolution':raise ValueError('not pending')
   staged=copy.deepcopy(self.root);staged['health']=outcome;staged['result']={'xp':30};staged['status']='Resolved'
   if fail:raise ValueError('injected failure')
   self.root=staged;return True,staged['result']
 s=Store();before=s.root
 try:s.resolve({'dead':True,'until':None},True)
 except ValueError:pass
 check(s.root is before and s.locked(),'reference_failed_commit_keeps_state_and_slot')
 new,result=s.resolve({'dead':True,'until':None})
 check(new and not s.locked() and s.root['health']['dead'],'reference_health_result_and_status_same_publish')
 before=s.root;new,retry=s.resolve({'dead':False,'until':None})
 check(not new and retry is result and s.root is before,'reference_retry_no_duplicate_or_resurrection')
 for now,allowed in [(61999,False),(62000,True),(999999,True)]:
  check((now>=62000)==allowed,'recovery_boundary/'+str(now))
 # Execute unchanged historical reference cases without historical source gates forbidding simulation.
 for module,fixture,category in [('verify_sprint5','party_v01_cases.json','party_reference_regression'),('verify_sprint6','quest_v01_cases.json','quest_reference_regression')]:
  m=load_module(module);data=json.loads((ROOT/'Assets/_Project/Tests/Fixtures'/fixture).read_text())['cases']
  for c in data:m.run_case(c);check(True,c['name'],category)
 lexical=load_module('verify_sprint6').lexical
 for path in sorted((ROOT/'Assets').rglob('*.cs')):check(lexical(path),str(path.relative_to(ROOT)),'lexical_source_files')
 src=ROOT/'Assets/_Project/Scripts';read=lambda p:(src/p).read_text()
 manager=read('Quests/QuestManager.cs');service=read('Quests/Simulation/QuestSimulationService.cs');store=read('Adventurers/GuildRuntimeStore.cs')
 runtime=read('Quests/QuestRuntimeState.cs');state=read('Adventurers/AdventurerState.cs');party=read('Party/PartyManager.cs')
 resolve=manager.split('public QuestResolutionResult TryResolveQuest',1)[1].split('public bool TryGetQuest',1)[0]
 checks={
 'pending_guard':'quest.Status != QuestStatus.CompletedPendingResolution' in resolve,
 'retry_returns_stored_receipt':'QuestResolutionCode.AlreadyResolved, quest.SimulationResult' in resolve,
 'one_resolution_publish':resolve.count('TryPublishResolution(')==1,
 'no_explicit_unlock_mutation':not re.search(r'Unlock|ReleaseSlot|ReleaseParty',resolve),
 'one_root_for_health_and_quests':'Members' in store and 'Quests' in store and 'Current=next;' in store,
 'no_old_roster_list':not re.search(r'private\s+(?:readonly\s+)?List<AdventurerState>\s+members\s*=',read('Adventurers/AdventurerManager.cs')),
 'stage_health_before_publication':resolve.index('WithQuestConsequences')<resolve.index('TryPublishResolution('),
 'stage_receipt_before_publication':resolve.index('quest.Resolve(result)')<resolve.index('TryPublishResolution('),
 'snapshot_conflict_check':'ReferenceEquals(before, registry.Capture())' in resolve,
 'reentrancy_guard':'if (resolving)' in resolve and 'finally { resolving = false; }' in resolve,
 'deploy_guard':'!member.CanDeployAt(now)' in manager,
 'dead_permanent':'IsDead || dead' in state,
 'recovery_inclusive':'now < RecoveryUntil.Value' in state,
 'dead_group_guards':party.count('PartyStatus.AdventurerDead')==4,
 'pending_keeps_slot':'Status == QuestStatus.Active || Status == QuestStatus.CompletedPendingResolution' in runtime,
 'result_immutable':'SimulationResult { get; }' in runtime,
 'canonical_member_sort':'list.Sort(' in read('Quests/Simulation/QuestSimulationInput.cs'),
 'canonical_loot_sort':'loot.Sort(' in service and 'lootEntries.Sort(' in read('Quests/Simulation/QuestSimulationInput.cs'),
 'seeded_sha256':'SHA256.Create()' in read('Quests/Simulation/QuestSimulationRandom.cs'),
 'incap_before_stabilization':service.index('incap[i]=')<service.index('stabilized[t]='),
 'stabilization_before_death':service.index('stabilized[t]=')<service.index('dead[i]='),
 'conscious_healers_only':'else if((input.Members[i].Roles&AdventurerRole.Healing)!=0)' in service,
 'one_attempt_per_healer_target':'targets.Dequeue()' in service and 'healers.Dequeue()' in service,
 'wipe_all_dead':'var wipe=deadCount==n;' in service,
 'completion_anchored_recovery':'input.Quest.CompletionTimestamp.Value+checked(seconds*1000L)' in service,
 'no_reward_application':not re.search(r'InventoryManager|AddGold|AddXp|GrantReward|SaveManager|PlayerPrefs',service+resolve),
 'read_only_panels':not re.search(r'RefreshAt\(|ReadTime\(',manager.split('public QuestBoardModel GetBoardModel')[1]),
 'snapshot_rules':'r=rules.Freeze()' in service,
 'xp_start_count_not_survivors':'decimal.Floor(d.XpReward*factor/n)' in service,
 'dead_xp_zero':'dead[i]?0:xp' in service,
 }
 for name,ok in checks.items():check(ok,name,'bounded_source_checks')
 # Literal defaults: limited source check, not proof that compiled C# executes them correctly.
 rules=read('Quests/Simulation/QuestSimulationRules.cs')
 constants={'DefaultLeaderQuality':'.5','DefaultBoldness':'0','XpBaseCoefficient':'30','GoldBaseCoefficient':'20','BasePower':'10','LevelStep':'.10','RankFactor':'1.5','TankBonus':'.08','HealingBonus':'.08','DamageBonus':'.04',
 'PowerRandom':'.05','OverloadScale':'.5','RetreatBase':'.45','LeaderRetreat':'.40','PersonalityRetreat':'.03','RetreatMax':'.90',
 'SuccessBase':'.10','SuccessSlope':'.80','SuccessMin':'.05','SuccessMax':'.98','IncapSlope':'.45','IncapMax':'.45',
 'RetreatIncap':'.35','InjuryBase':'.10','InjurySlope':'.30','InjuryMax':'.40','RetreatInjury':'.60','StabilizeChance':'.65',
 'DeathBase':'.15','DeathOverload':'.50','CollapseDeath':'.20','DeathMax':'.90','SuccessXp':'1','RetreatXp':'.35','FailureXp':'.20',
 'WipeXp':'0','LootChance':'.35','RecoveryBase':'60','RecoveryOverload':'180','RecoveryIncap':'60','RecoveryMin':'60','RecoveryMax':'300'}
 for name,value in constants.items():
  match=re.search(r'\b'+name+r'\s*=\s*([.0-9]+)m',rules)
  check(match is not None and D(match.group(1))==D(value),'approved_default/'+name,'constant_source_checks')
 allowed={'Adventurers/AdventurerState.cs','Adventurers/AdventurerManager.cs','Party/PartyManager.cs','Party/PartyResult.cs','Party/PartyPanelModel.cs',
 'Quests/QuestManager.cs','Quests/QuestActivityRegistry.cs','Quests/QuestRuntimeState.cs','Quests/QuestPanelModel.cs','Quests/QuestResult.cs'}
 allowed={'Assets/_Project/Scripts/'+p for p in allowed};changes=[]
 with zipfile.ZipFile(args.baseline) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=n.split('/',1)[1];current=(ROOT/rel).read_bytes();same=current==z.read(n)
   if not same:changes.append(rel)
   check(same or rel in allowed,rel,'baseline_unchanged' if same else 'baseline_documented_change')
  # Preserve numeric values of every existing result enum; new errors append only.
 for rel,enum in [('Party/PartyResult.cs','PartyStatus'),('Quests/QuestResult.cs','QuestResultCode')]:
  def names(text):return re.search(r'enum '+enum+r'\s*\{([^}]+)',text).group(1).replace('= 0','').replace('\n','').replace(' ','').split(',')
  with zipfile.ZipFile(args.baseline) as z:
   old=next(n for n in z.namelist() if n.endswith('/Scripts/'+rel));previous=names(z.read(old).decode())
  current=names(read(rel));check(current[:len(previous)]==previous,enum+'/existing_numeric_order','bounded_source_checks')
 metas=list((ROOT/'Assets').rglob('*.meta'));guids=[re.search(r'^guid: (\w+)',p.read_text(),re.M).group(1) for p in metas]
 check(len(guids)==len(set(guids)),'unique_asset_metadata_guids','bounded_source_checks')
 check(set(changes)==allowed,'exact_existing_file_change_allowlist','bounded_source_checks')
 print('RESULT '+json.dumps(COUNTS,sort_keys=True))
 print('C# compilation / NUnit / Unity / Xcode / iPhone: NOT EXECUTED.')
if __name__=='__main__':main()

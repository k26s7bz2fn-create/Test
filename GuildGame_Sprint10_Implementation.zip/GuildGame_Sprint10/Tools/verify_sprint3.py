from pathlib import Path
import hashlib, json, re, sys
ROOT = Path(__file__).resolve().parents[1]
BASE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None
checks=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))

def text(rel): return (ROOT/rel).read_text(encoding='utf-8')
fixture=json.loads(text('Assets/_Project/Tests/Fixtures/recruitment_v01_cases.json'))

# Contract facts from Sprint 2 source.
gen=text('Assets/_Project/Scripts/Data/AdventurerGenerationDefinition.cs')
state=text('Assets/_Project/Scripts/Adventurers/AdventurerState.cs')
role=text('Assets/_Project/Scripts/Adventurers/AdventurerRole.cs')
check('contract_four_canonical_classes', all(x in gen for x in ['class.warrior','class.rogue','class.mage','class.priest']))
check('contract_roles_warrior', 'AdventurerRole.Tank | AdventurerRole.Damage' in gen)
check('contract_roles_rogue', 'case "class.rogue": return AdventurerRole.Damage;' in gen)
check('contract_roles_mage', 'AdventurerRole.Damage | AdventurerRole.SupportControl' in gen)
check('contract_roles_priest', 'AdventurerRole.Healing | AdventurerRole.SupportControl' in gen)
check('contract_f1_rank', 'InitialRank = "F"' in state)
check('contract_f1_level', 'InitialLevel = 1' in state)
check('contract_capacity_12', 'public const int Capacity = 12;' in text('Assets/_Project/Scripts/Adventurers/AdventurerManager.cs'))

# Required new files.
new_sources=[
'Assets/_Project/Scripts/Recruitment/RecruitmentManager.cs',
'Assets/_Project/Scripts/Recruitment/RecruitmentCandidate.cs',
'Assets/_Project/Scripts/Recruitment/RecruitmentSession.cs',
'Assets/_Project/Scripts/Recruitment/RecruitmentState.cs',
'Assets/_Project/Scripts/Recruitment/RecruitmentResult.cs',
'Assets/_Project/Scripts/Recruitment/StartCandidateGenerator.cs',
'Assets/_Project/Scripts/Recruitment/RecruitmentPanelModel.cs']
for f in new_sources: check('exists_'+Path(f).stem, (ROOT/f).is_file())

sg=text('Assets/_Project/Scripts/Recruitment/StartCandidateGenerator.cs')
rm=text('Assets/_Project/Scripts/Recruitment/RecruitmentManager.cs')
pm=text('Assets/_Project/Scripts/Recruitment/RecruitmentPanelModel.cs')
sess=text('Assets/_Project/Scripts/Recruitment/RecruitmentSession.cs')
manager=text('Assets/_Project/Scripts/Adventurers/AdventurerManager.cs')

check('generator_exactly_five_constant', 'CandidateCount = 5' in sg)
check('selection_exactly_three', 'selectedCandidateIds.Count == 3' in sess and 'states = new AdventurerState[3]' in rm)
check('generator_seeded_random', 'new RandomGenerator(seed)' in sg)
check('generator_deterministic_ids', 'SHA256.Create()' in sg and 'sessionId + "|candidate|" + position' in sg)
check('role_guarantee_tank', 'AdventurerRole.Tank' in sg)
check('role_guarantee_healing', 'AdventurerRole.Healing' in sg)
check('role_guarantee_damage', 'AdventurerRole.Damage' in sg)
check('role_guarantee_distinct_candidates', 'ReferenceEquals(data, front) || ReferenceEquals(data, healer)' in sg)
check('only_canonical_classes', all(x in sg for x in ['class.warrior','class.rogue','class.mage','class.priest']))
check('f1_validated', 'AdventurerState.InitialRank' in sg and 'AdventurerState.InitialLevel' in sg)
check('session_no_regeneration', 'if (session != null)' in rm)
check('selection_limit_three', 'session.SelectedCount >= 3' in rm)
check('commit_rechecks_capacity', 'adventurerManager.Count > AdventurerManager.Capacity - 3' in rm)
check('commit_atomic_batch', 'TryAddBatch(states)' in rm and 'public AdventurerResult TryAddBatch' in manager)
check('panel_read_only_projection', 'CandidateView' in pm and 'GetPanelModel()' in rm and 'RandomGenerator' not in pm)
check('no_save_in_recruitment', 'SaveManager' not in '\n'.join(text(f) for f in new_sources))
check('no_out_of_scope_managers', not any(x in '\n'.join(text(f) for f in new_sources) for x in ['QuestManager','CombatManager','DungeonManager','InventoryManager','EquipmentManager','BuildingManager','RelationshipManager','PartyManager']))

# Planned tests exist and cover core names.
test_text='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'Assets/_Project/Tests/EditMode/Recruitment').glob('*.cs'))
expected_tests=['Generate_ExactlyFiveCandidates','Generate_AllCandidatesAreF1','Generate_OnlyBasicClasses','Generate_RequiredRolesAvailable','Generate_ImpossibleCoverageFails','Generate_InvalidDefinitionFails','Generate_SameInputsSameOutput','Generate_DifferentSessionsUniqueIds','Initialize_TwiceKeepsCandidates','Generate_WrongCountRejected','Generate_DuplicateIdsRejected','Select_BeforeInitializeIsSessionNotReady','Deselect_NotSelectedRejected','Initialize_EmptySessionIdRejected','Select_UnknownIdRejected','Select_DuplicateRejected','Select_FourthRejected','Deselect_AllowsReplacement','Confirm_WrongCountRejected','Confirm_ExactlyThreeAccepted','Confirm_NineMembersAllowsTwelve','Confirm_TenOrMoreRejected','Confirm_RechecksCapacity','Confirm_IsAtomicOnFailure','Confirm_SecondCallDoesNotDuplicate','Committed_SelectionLocked','Preview_DoesNotRegisterMembers','Panel_ReflectsSelectionAndCapacity','Panel_ReadDoesNotChangeState','Contract_UsesExistingAdventurerData']
for n in expected_tests: check('test_declared_'+n, n in test_text)

# Simple structural source sanity.
for rel in new_sources + ['Assets/_Project/Scripts/Adventurers/AdventurerManager.cs']:
    s=text(rel)
    check('brace_balance_'+Path(rel).stem, s.count('{') == s.count('}'))
    check('namespace_'+Path(rel).stem, 'namespace GuildGame' in s)

# Baseline: all Sprint-2 hashed files unchanged except AdventurerManager.cs, which is intentionally extended.
if BASE:
    manifest=json.loads((BASE/'PACKAGE_SHA256.json').read_text())
    intentional={'Assets/_Project/Scripts/Adventurers/AdventurerManager.cs'}
    unchanged=True
    changed=[]
    missing=[]
    for rel, expected in manifest.items():
        p=ROOT/rel
        if not p.exists(): missing.append(rel); unchanged=False; continue
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        if actual != expected:
            changed.append(rel)
            if rel not in intentional: unchanged=False
    check('sprint2_baseline_only_intentional_change', unchanged, 'changed='+','.join(changed)+' missing='+','.join(missing))
    check('adventurer_manager_intentionally_changed', changed == ['Assets/_Project/Scripts/Adventurers/AdventurerManager.cs'], 'changed='+','.join(changed))

# Independent contract reasoning.
roles=fixture['classes']
front=[c for c,r in roles.items() if 'Tank' in r]
heal=[c for c,r in roles.items() if 'Healing' in r]
dmg=[c for c,r in roles.items() if 'Damage' in r and c not in front and c not in heal]
check('fixture_distinct_role_solution_exists', bool(front and heal and dmg), f'{front},{heal},{dmg}')
check('fixture_nine_plus_three_is_capacity', 9+fixture['selection_count']==fixture['guild_capacity'])
check('fixture_ten_plus_three_exceeds', 10+fixture['selection_count']>fixture['guild_capacity'])

failed=[x for x in checks if not x[1]]
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+': '+name+((' :: '+detail) if detail else ''))
print(f'\nTOTAL={len(checks)} PASS={len(checks)-len(failed)} FAIL={len(failed)}')
sys.exit(1 if failed else 0)

#!/usr/bin/env python3
"""Independent contract model + limited lexical/source checks, NOT C# execution.
Usage: python Tools/verify_sprint5.py --baseline path/to/Sprint4.zip
"""
import argparse,copy,hashlib,json,pathlib,re,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
counts={'contract':0,'source':0,'baseline_files':0}
def check(value,label,kind):
 if not value: raise AssertionError(label)
 counts[kind]+=1
 print('PASS '+kind+' '+label)
class Rejected(Exception):pass
def reject(code): raise Rejected(code)
def run_case(c):
 # Independent executable specification. Test expectations are stored explicitly in the fixture.
 before={g['id']:copy.deepcopy(g) for g in c['initial']}; groups=copy.deepcopy(before)
 def group(id):
  if id=='invalid':reject('InvalidPartyId')
  if id not in groups:reject('UnknownParty')
  return groups[id]
 def editable(id):
  if c['brokenPolicy']:reject('PolicyUnavailable')
  if id in c['blocked']:reject('PartyNotEditable')
 def member(x):
  x=int(x)
  if x<=0:reject('InvalidMemberId')
  if x>12:reject('UnknownAdventurer')
  return x
 def owner(x):return next((k for k,g in groups.items() if x in g['members']),None)
 def batch(xs,allowed):
  if xs is None:reject('InvalidInput')
  if not 1<=len(xs)<=6:reject('InvalidMemberCount')
  result=[]
  for x in xs:
   x=member(x)
   if x in result:reject('DuplicateMemberId')
   if owner(x) not in (None,allowed):reject('MemberAssignedElsewhere')
   result.append(x)
  return result
 a=c['args']; id=a[0]; op=c['operation']; status='Success'
 try:
  if op in ('create','create_null'):
   if id=='invalid':reject('InvalidPartyId')
   if id in groups:reject('PartyAlreadyExists')
   groups[id]={'id':id,'members':batch(None if op=='create_null' else a[1:],None),'leader':0}
  else:
   g=group(id)
   if op=='transfer':
    target=group(a[1])
    if id==a[1]:reject('SameParty')
    editable(id);editable(a[1]);m=member(a[2])
    if m not in g['members']:reject('MemberNotAssigned')
    if len(target['members'])>=6:reject('PartyCapacityReached')
    if len(g['members'])<=1:reject('InvalidMemberCount')
    g['members'].remove(m);target['members'].append(m)
    if g['leader']==m:g['leader']=0
   elif op=='validate':batch(g['members'],id)
   else:
    editable(id)
    if op=='dissolve': del groups[id]
    elif op=='clear':g['leader']=0
    elif op in ('set','set_null'):
     ms=batch(None if op=='set_null' else a[1:],id)
     g['members']=ms
     if g['leader'] not in ms:g['leader']=0
    else:
     m=member(a[1])
     if op in ('add','add_alias'):
      o=owner(m)
      if o is not None:reject('MemberAlreadyAssigned' if o==id else 'MemberAssignedElsewhere')
      if len(g['members'])>=6:reject('PartyCapacityReached')
      g['members'].append(m)
     elif op=='remove':
      if m not in g['members']:reject('MemberNotAssigned')
      if len(g['members'])<=1:reject('InvalidMemberCount')
      g['members'].remove(m)
      if g['leader']==m:g['leader']=0
     elif op=='leader':
      if m not in g['members']:reject('MemberNotAssigned')
      g['leader']=m
     else:raise AssertionError('unknown operation '+op)
 except Rejected as ex:
  status=str(ex)
  assert groups==before, 'reference model partial mutation'
 assert status==c['expectedStatus'],(status,c['expectedStatus'])
 expected=before if status!='Success' else {g['id']:g for g in c['expected']}
 assert groups==expected,(groups,expected)
 ids=[]
 for g in groups.values():
  assert 1<=len(g['members'])<=6
  assert not g['leader'] or g['leader'] in g['members']
  ids.extend(g['members'])
 assert len(ids)==len(set(ids))

def lexical(path):
 # Lexical balance only; does NOT establish C# grammar or type correctness.
 s=path.read_text(); cleaned=re.sub(r'//[^\n]*|/\*.*?\*/|@"(?:""|[^"])*"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', '',s,flags=re.S)
 stack=[]; pairs={')':'(',']':'[','}':'{'}
 for char in cleaned:
  if char in '([{':stack.append(char)
  elif char in pairs:
   assert stack and stack.pop()==pairs[char],str(path)
 assert not stack,str(path)
 return True

def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);args=p.parse_args()
 cases=json.loads((ROOT/'Assets/_Project/Tests/Fixtures/party_v01_cases.json').read_text())['cases']
 assert len({c['name'] for c in cases})==len(cases)
 for c in cases:run_case(c);check(True,c['name'],'contract')
 paths=list((ROOT/'Assets/_Project/Scripts/Party').glob('*.cs'))+list((ROOT/'Assets/_Project/Tests/EditMode/Party').glob('*.cs'))
 for path in paths:check(lexical(path),path.name+' lexical delimiter balance','source')
 manager=(ROOT/'Assets/_Project/Scripts/Party/PartyManager.cs').read_text()
 state=(ROOT/'Assets/_Project/Scripts/Party/PartyState.cs').read_text()
 panel=(ROOT/'Assets/_Project/Scripts/Party/PartyPanelModel.cs').read_text()
 checks={
  'uses_existing_adventurer_lookup':'adventurers.TryGetById' in manager,
  'no_adventurer_creation_or_roster_writes':not re.search(r'TryAddBatch|adventurers.TryAdd|AdventurerState.TryCreate',manager),
  'one_to_six_constants':'MinimumMembers = 1' in state and 'MaximumMembers = 6' in state,
  'no_total_three_party_cap':not re.search(r'parties.Count\s*[>=]+\s*3',manager),
  'canonical_guid_ids':'value.ToString("D")' in manager,
  'transfer_stages_removal_before_add':manager.index('sourceMembers.Remove(id)')<manager.index('targetMembers = new List'),
  'transfer_single_publication':manager[manager.index('public PartyResult TryTransferMember'):manager.index('public PartyResult TrySetLeader')].count('parties = next;')==1,
  'transfer_both_policies_checked':'CheckEditable(source.PartyId)' in manager and 'CheckEditable(target.PartyId)' in manager,
  'leader_cleared_on_departure':'source.LeaderId == id ? null : source.LeaderId' in manager,
  'detached_readonly_collections':'Array.AsReadOnly' in state and 'Array.AsReadOnly' in panel,
  'no_mission_save_or_out_of_scope_dependencies':not re.search(r'QuestManager|SaveManager|PlayerPrefs|CombatManager|InventoryManager|EquipmentManager',manager+panel),
  'unity_fixture_drives_actual_manager_tests':'[TestCaseSource(nameof(Cases))]' in (ROOT/'Assets/_Project/Tests/EditMode/Party/PartyManagerTests.cs').read_text(),
 }
 for label,ok in checks.items():check(ok,label,'source')
 with zipfile.ZipFile(args.baseline) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('/'):continue
   rel=pathlib.Path(*pathlib.PurePosixPath(n).parts[1:]); current=ROOT/rel
   check(current.is_file() and current.read_bytes()==z.read(n),str(rel),'baseline_files')
 print('RESULT '+json.dumps(counts,sort_keys=True))
 print('C# compilation / Unity execution: NOT EXECUTED by this tool.')
if __name__=='__main__':main()

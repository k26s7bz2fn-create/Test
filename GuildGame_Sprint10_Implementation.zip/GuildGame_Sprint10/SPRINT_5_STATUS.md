# SPRINT 5 STATUS

Stand: 15.09.2026

**Sprint 5 ist als C#-Quellimplementierung fertiggestellt und außerhalb von Unity referenzmodell-/quellvertraglich geprüft. C#-Kompilierung, tatsächliche C#-Tests und Unity/iOS-Abnahme stehen aus. Definition of Done teilweise erfüllt.**

## Implementiert

Mehrere Gruppen, je 1–6 Mitglieder; globale eindeutige Zuordnung; Erstellen, Auflösen, Hinzufügen, Entfernen, atomarer Ersatz und Transfer; optionaler einzelner Leiter; Leeren des Leader-Slots beim Austritt; read-only Panelmodell; strukturierte Fehler; testbare Bearbeitbarkeitsschnittstelle für spätere Missionen.

Eine Gruppe wird nicht automatisch aus Startrekruten erzeugt. Leere Gruppen werden nicht registriert. Letztes Mitglied nicht isoliert entfernen/verschieben; stattdessen zulässige Gruppe ausdrücklich auflösen. Keine Begrenzung auf drei bestehende Gruppen und keine implementierten Quests.

## Neue Dateien

- `Assets/_Project/Scripts/Party.meta`
- `Assets/_Project/Scripts/Party/IPartyEditPolicy.cs`
- `Assets/_Project/Scripts/Party/IPartyEditPolicy.cs.meta`
- `Assets/_Project/Scripts/Party/PartyManager.cs`
- `Assets/_Project/Scripts/Party/PartyManager.cs.meta`
- `Assets/_Project/Scripts/Party/PartyPanelModel.cs`
- `Assets/_Project/Scripts/Party/PartyPanelModel.cs.meta`
- `Assets/_Project/Scripts/Party/PartyResult.cs`
- `Assets/_Project/Scripts/Party/PartyResult.cs.meta`
- `Assets/_Project/Scripts/Party/PartyState.cs`
- `Assets/_Project/Scripts/Party/PartyState.cs.meta`
- `Assets/_Project/Tests/EditMode/Party.meta`
- `Assets/_Project/Tests/EditMode/Party/PartyManagerTests.cs`
- `Assets/_Project/Tests/EditMode/Party/PartyManagerTests.cs.meta`
- `Assets/_Project/Tests/EditMode/Party/PartyPanelModelTests.cs`
- `Assets/_Project/Tests/EditMode/Party/PartyPanelModelTests.cs.meta`
- `Assets/_Project/Tests/Fixtures/party_v01_cases.json`
- `Assets/_Project/Tests/Fixtures/party_v01_cases.json.meta`
- `Docs/Sprint5_Implementation.md`
- `Docs/Sprint5_OpenGates.md`
- `Docs/Sprint5_RecruitmentRegression.txt`
- `Docs/Sprint5_TestResults.md`
- `Docs/Sprint5_Verification.txt`
- `Tools/verify_sprint5.py`
- `SPRINT_5_STATUS.md` (dieser Bericht)
- `PACKAGE_SPRINT5_SHA256.json` (Gesamtmanifest, nach Abschluss erzeugt)

## Geänderte bestehende Dateien

**Keine.** Alle 106 Dateien aus dem Sprint-4-Eingabepaket sind bytegleich erhalten. Keine parallele Abenteurerverwaltung. Historische Statusberichte und das historische Manifest wurden nicht aktualisiert; dieser Statusbericht ist die aktuelle Übergabe.

## Ausgeführte und bestandene Prüfungen

| Prüfung | Ergebnis | Aussagegrenze |
|---|---|---|
| Sprint-5-Vertragsfälle | 63/63 bestanden | Unabhängiges Python-Referenzmodell, keine C#-Ausführung |
| Statische automatisierte Quellprüfungen | 19/19 bestanden | Lexikalisch und gezielte Quellmerkmale, kein Compiler |
| Recruitment-Regressionsprüfer | 81/81 bestanden | Ohne die zwei optionalen historischen Sprint-2-Hashprüfungen |
| Sprint-4-Dateibaseline | 106/106 bytegleich | Vergleich mit tatsächlich geliefertem ZIP |
| Python-Syntax / JSON-Fixtureformat | Erfolgreich geprüft | Prüfinfrastruktur |

Zusätzlich statisch durchgesehen: GUID-Identität, Besitzerzuordnung, Quellenentnahme vor Zielzugang im temporären Transferzustand, gemeinsame Veröffentlichung, Leiterentfernung, Sperrfehler, Snapshotkopien und Scopeabhängigkeiten. Vollständige Protokolle und Grenzen stehen unter `Docs/Sprint5_TestResults.md`.

## Offene Prüfungen und Risiken

- **Unity-Kompilierung: NICHT AUSGEFÜHRT.** Auch kein anderer C#-Compiler verfügbar.
- **Unity-EditMode-Tests: NICHT AUSGEFÜHRT.** 70 NUnit-Testinstanzen vorbereitet.
- **Unity-PlayMode-Tests: NICHT AUSGEFÜHRT.** Keine neue 3D-/Paneloberfläche erstellt.
- **Xcode-/iPhone-Abnahme: OFFEN.** Kein Build, Signierungs- oder Gerätenachweis.
- **Vollständige Save-Integration: OFFEN, nicht implementiert.** Nur Laufzeitgruppen.
- Sprint-4-Szenenerzeugung, Verdrahtung und produktive ScriptableObject-Assets bleiben offen.
- Atomarität gilt für synchrone Befehle auf dem besitzenden Spielthread; keine beliebige nebenläufige Nutzung.
- IPartyEditPolicy muss später an das autoritative Einsatzsystem gebunden werden. Ausfall sperrt Änderungen. Standardanbieter behandelt Gruppen mangels Quest-System als inaktiv.
- Das Paket ist die gelieferte Sprint-4-Quellbasis plus Ergänzung; nicht enthaltene ältere Projektdateien/Unity-Settings wurden nicht rekonstruiert.

## Minimale Schnittstelle und Planpräzisierungen

`IPartyEditPolicy` ist erforderlich, um die freigegebene Regel „Transfers nur zwischen nicht aktiven Gruppen“ jetzt testbar zu machen, ohne Queststatus zu erfinden. Es wurden keine Schnittstellen bestehender Systeme geändert.

Die bestätigte Mehrgruppen-Ergänzung ersetzt die frühere Idee einer leeren registrierten Gruppe: Erzeugung und Ersatz akzeptieren nur 1–6; Auflösen entfernt den Registereintrag und gibt Mitglieder frei. Höchstens ein optionaler Leader gemäß expliziter Fachregel. Fehler werden in PartyResult geliefert, nicht als globale letzte Fehlermeldung gespeichert; Panel-Lesen bleibt seiteneffektfrei. Keine sichtbare Hallennavigation hinzugefügt.

Keine fachliche Scope-Erweiterung. Feste Teams, Team-Boni, Autofill und drei parallele Quests nur als spätere Anschlussanforderungen dokumentiert, nicht implementiert.

## Definition of Done

- Freigegebener Quellumfang: umgesetzt.
- Automatisierbare C#-Tests: angelegt, Ausführung offen.
- Verfügbare externe Prüfungen: ausgeführt und bestanden, mit begrenzter Aussagekraft.
- Baselineerhalt: nachgewiesen gegenüber Sprint-4-ZIP.
- C#-/Unity-/iOS-Abnahme: offen; keine vollständige Laufzeitfreigabe.

**Sprint 6 wurde nicht begonnen.**

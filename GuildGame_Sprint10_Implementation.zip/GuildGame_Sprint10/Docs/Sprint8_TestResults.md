# Sprint 8 – Prüfergebnisse

Stand 2026-09-23. Alle hier als bestanden aufgeführten Prüfungen wurden tatsächlich in Python ausgeführt. Keine C#-Ausführung.

| Prüfgruppe | Ergebnis |
|---|---:|
| Neue Progressions-Referenzfälle | 19/19 |
| Neue Klassen-/Skill-Referenzfälle | 40/40 |
| Neue Reward-/Atomaritäts-Referenzprüfungen | 24/24 |
| Neue Struktur-Quellprüfungen | 31/31 |
| Neue Vertrags-Quellprüfungen | 8/8 |
| Lexikalische C#-Klammerprüfung | 98/98 Dateien |
| Vorhandener Sprint-7-Runner: Beispiele + Seedfälle + weitere Referenzprüfungen | 597/597 |
| Vorhandene Party-Referenzfälle | 63/63 |
| Vorhandene Quest-Referenzfälle | 54/54 |
| Vorhandener Recruitment-Prüfer | 81/81 |
| Vergleich zu Sprint 7 | 208 bytegleich, 4 dokumentiert geändert |
| Neue NUnit-Testinstanzen | 62 vorbereitet, 0 ausgeführt |
| C#-Kompilierung | Nicht ausgeführt |
| Unity EditMode/PlayMode | Nicht ausgeführt |
| Xcode/iPhone | Nicht ausgeführt |

83 neue Python-Referenzprüfungen = 19 + 40 + 24. Kein zusammenaddierter „C#-Testscore“. Der Sprint-8-Runner führt einige historische Referenzfälle erneut aus; diese werden nicht doppelt als zusätzliche unabhängige Tests gezählt.

Der vollständige unveränderte verify_sprint7.py wurde zusätzlich am Sprint-8-Baum ausgeführt und bestand einschließlich seiner 34 Struktur- und 42 Konstantenprüfungen. Sein historischer Vergleich richtet sich gegen Sprint 6 (172 unverändert/10 erlaubte Änderungen); für Sprint 8 ist ausschließlich der zusätzliche Vergleich gegen das Sprint-7-ZIP maßgeblich (208/4).

## Reproduktion

```bash
python Tools/verify_sprint8.py --baseline /pfad/GuildGame_Sprint7_Implementation.zip
python Tools/verify_sprint7.py --baseline /pfad/GuildGame_Sprint6_Implementation.zip
python Tools/verify_sprint3.py
```

Logs: Sprint8_Verification.txt, Sprint8_SimulationRegression.txt, Sprint8_RecruitmentRegression.txt.

## Grenzen

Python prüft ein unabhängiges Referenzmodell, nicht die C#-Implementierung. Text- und Klammerprüfungen sind keine Syntax-, Typ-, Assembly- oder Kompilierungsprüfung. Keine Bestätigung der C#-Atomarität durch ausgeführte Runtime-Tests.

Vorbereitete NUnit-Tests decken ab: XP-Schwellen, Mehrfachaufstieg, F10-Cap und Int64-Maximalbetrag; alle Klassenverteilungen; Invalid-/Read-only-Fälle; Resolved-Gate, echte S7-Auswertung, ursprünglichen/späteren Tod, veränderte Gruppen, fehlende Empfänger/Items, doppelte Outputs/Empfänger, Null-Rewards, Gold-/Tranküberlauf, Receipt-Konflikte, Fault-Injection vor Veröffentlichung, Reentranz, Snapshot-Konflikte, zweiter Manager, Erhalt bei Recruitment/Refresh/Resolve, Levelwirkung bei bereits laufender Quest, read-only Panels, Raritäten, Einzelinstanzen und Stapel.

Für tatsächliche C#- und Unity-Ausführung stehen diese 62 Instanzen sowie alle historischen NUnit-/PlayMode-Tests noch aus. Die vorhandene Umgebung stellt dotnet/csc/mcs/mono/Unity nicht im PATH bereit.

# Sprint 3 – Offene Gates

1. **C3:** Unity-/C#-Kompilierung der Sprint-3-Quellen.
2. **T3:** Ausführung der neuen EditMode/NUnit-Tests im Unity Test Runner.
3. **A2/A3:** produktive ScriptableObject-Assets weiterhin erst in Unity erzeugen/prüfen.
4. **I2/I3:** vollständige Save-/GameState-Anbindung bleibt bewusst offen.
5. **B1/U1:** ältere offene Unity-Gates aus Sprint 1 bleiben offen.
6. **X1/D1:** Xcode, iOS-Signierung und echter Test auf iPhone 16 Pro.

Diese Gates sind Umgebungs-/Integrationsgates, keine offenen Produktentscheidungen.

# Sprint 5 – Prüfergebnisse

## Tatsächlich ausgeführt

1. Sprint-4-ZIP wurde gelesen und CRC-validiert.
2. `python Tools/verify_sprint5.py --baseline <Sprint4-ZIP>`: Exit 0.
   - 63/63 unabhängige Python-Referenzmodell-/Datenvertragsfälle bestanden.
   - 19/19 begrenzte statische Quellprüfungen bestanden (7 lexikalische Klammerprüfungen und 12 gezielte Quellvertragsprüfungen).
   - Alle 106 Sprint-4-Dateien bytegleich, keine fehlenden oder veränderten Basisdateien.
3. Unverändertes `python Tools/verify_sprint3.py` ohne optionalen Baselinepfad: 81/81 bestanden, Exit 0. Dies ist eine neue Ausführung der verfügbaren Recruitment-Quell-/Vertragsprüfungen, kein erneuter vollständiger historischer 83er-Lauf. Die zwei alten Sprint-2-Basisprüfungen wurden hier nicht ausgeführt.
4. Python-Syntax des neuen Prüfers mittels `ast.parse` geprüft.
5. JSON-Fixture eingelesen und Argumenttypen sowie explizite Erfolgserwartungen geprüft.

Protokolle: `Sprint5_Verification.txt`, `Sprint5_RecruitmentRegression.txt`.

## Statische C#-Durchsicht

- Keine Aufnahmen/Entfernungen im AdventurerManager durch Party-Code.
- GUID-Normalisierung vor Besitzprüfung; globale Besitzprüfung über eine Registry.
- Gruppen 1–6; kein künstliches Gesamtlimit drei.
- Vollständige Batchprüfung vor Veröffentlichung.
- Beide Transfer-Sperren vor Veränderung, ein gemeinsamer Registerwechsel.
- Quelle verliert Leiterreferenz bei Austritt; Zielführung bleibt unverändert.
- Read-only Arraykopien und immutable Gruppen-Snapshots.
- Keine Quest-, Save-, Combat-, Inventory- oder Equipment-Abhängigkeit.
- Panel besitzt keine veränderbare Managerreferenz.

Diese Durchsicht und lexikalische Prüfungen sind keine semantische C#-Compileranalyse.

## Nicht ausgeführt

- C#-Kompilierung oder Ausführung des C#-PartyManager.
- 63 parametrisierte NUnit-Vertragstests und 7 weitere direkte NUnit-Tests.
- Unity EditMode/PlayMode, Szenenintegration, Xcode und iPhone-Abnahme.

Das Python-Referenzmodell führt die JSON-Fälle aus, NICHT den C#-Quellcode. Die gemeinsame Fixture verhindert unterschiedliche Sollwerte, beweist aber keine korrekte Ausführung des C#-Managers. Diese Grenze bleibt offen.

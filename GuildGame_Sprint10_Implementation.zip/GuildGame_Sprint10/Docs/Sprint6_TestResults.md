# Sprint 6 – Tatsächliche Prüfergebnisse

## Ausgeführt

- Eingabepaket Sprint 5 geöffnet und ZIP-CRC geprüft.
- `Tools/verify_sprint6.py --baseline <Sprint5-ZIP>`: Exit 0.
  - 54/54 unabhängige Python-Referenzszenarien bestanden.
  - 38/38 begrenzte statische Quellprüfungen bestanden: 18 lexikalische Klammerprüfungen, 20 gezielte Quellvertragsprüfungen.
  - 131/132 Basisdateien bytegleich; eine Basisdatei exakt um die erlaubte Identitätsprüfung ergänzt. Keine sonstige Änderung oder Löschung.
- Unverändertes `Tools/verify_sprint5.py --baseline <Sprint4-ZIP>` auf dem Sprint-6-Stand: Exit 0; 63/63 Party-Referenzfälle, 19/19 begrenzte Quellprüfungen und 106/106 unveränderte Sprint-4-Dateien.
- Unverändertes `Tools/verify_sprint3.py` ohne optionalen Sprint-2-Basispfad: Exit 0; 81/81 bestanden. Die zwei historischen optionalen Sprint-2-Vergleiche wurden nicht erneut ausgeführt.
- Python-Syntax des neuen Prüfers per ast.parse validiert.
- Anzahl deklarierter neuer NUnit-Instanzen ermittelt: 90. Das ist keine Testausführung.

Protokolle: `Sprint6_Verification.txt`, `Sprint6_PartyRegression.txt`, `Sprint6_RecruitmentRegression.txt`.

## Was diese Prüfungen belegen

Die Referenzszenarien prüfen explizite Sollzustände für Starts, Kapazität, Zeitfortschreibung, Sperren in Active und Pending, Transfers, Leaderänderungen, fehlgeschlagene Starts und read-only Abfragen. Sie führen ein unabhängiges Python-Modell aus. Der gemeinsame JSON-Vertrag wird auch durch die vorbereiteten C#-Tests verwendet.

Die Quellprüfungen prüfen ausgewählte Codeeigenschaften und lexikalische Klammerbalance, keine vollständige C#-Grammatik, Typauflösung oder Laufzeit.

Zusätzliche statische Durchsicht: gemeinsame Registry/Policy-Identität, einzelner Registry-Schreiber, unveränderliche Snapshots, Gruppen-/Mitgliederdeduplizierung, Checked-Zeitaddition, exklusiver Active->Pending-Übergang, keine Resolved-Erzeugung, keine Rewards/Save-Zugriffe, gleiche Sperrquelle für Start und Gruppenbefehle.

## Nicht ausgeführt

- C#-Kompilierung und tatsächliche C#-Quest-/Party-Ausführung.
- 90 neue NUnit-Testinstanzen: QuestManagerTests 56, QuestDefinitionTests 21, QuestPartyLockTests 6, QuestTimeTests 3, QuestPanelModelTests 4.
- Unity-EditMode-/PlayMode-Tests, Asseterzeugung und Szenenintegration.
- Xcode-Build und iPhone-Abnahme.

## Grenzen

Ein bestandener Python-Test ist kein bestandener NUnit-Test. Das Paket ist quellen-/referenzvertraglich geprüft, aber noch nicht in Unity abgenommen. Datenvertragswerte sind ausdrücklich Testwerte und keine neue Produktbalance.

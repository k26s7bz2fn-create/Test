# Sprint 8 – Implementierung

Stand: 2026-09-23. Die Anweisung „Ausführen“ nach SPRINT_8_RULE_PROPOSAL wurde als Freigabe P8-01 bis P8-12 und Implementierungsauftrag behandelt. Keine weiteren Produktregeln hinzugefügt. Sprint 9 nicht begonnen.

## Regeln und Verantwortlichkeiten

- XP-Schwellen: 0, 30, 70, 120, 180, 250, 330, 420, 520, 630. F1 bis F10; drei Punkte je Aufstieg. Mehrfachaufstiege in einem Commit.
- Progressions-XP bei 630 begrenzt. Receipt unterscheidet ResultXp, AppliedXp und CapOverflow. Kein Ansparen für E1.
- Vier Kataloge mit je neun stabilen Skill-IDs; Rang höchstens drei. Vergabe Reihenfolge 1–9 dreimal. Gleiche Klasse und Level ergeben gleiche Belegung. F1 hat null investierte Levelpunkte. Keine neuen Skillwirkungen in der Simulation.
- Sieben konkrete Itemdefinitionen gemäß freigegebenem Vorschlag: vier klassenbezogene Common-Waffen, zwei universelle Common-Rüstungen und ein Heiltrank. Vertragsraritäten Common/Uncommon/Rare; bei Heiltränken Rarity und Slot null. Keine Epic-/Legendary-/Unique-/SoulStone-Verarbeitung.
- Equipment als Einzelinstanzen, stabile ID aus Loot-Output-ID und Einzelindex. Heiltränke als gemeinsamer Mengenstapel. Keine fachliche Lager-/Stapelgrenze. Numerischer Überlauf führt zum vollständigen Abbruch; keine stille Begrenzung.
- Keine Angriffs-, Verteidigungs-, Heil-, Preis- oder Equipment-Score-Werte. Keine Ausrüstungsauswahl, kein Trankverbrauch und keine Durability.
- Positive XP im gespeicherten Resolve-Beleg bleiben auch nach späterem Tod berechtigt. Progression wird auf den aktuellen Abenteurer kopiert und erhält Tod/Genesung. Im ursprünglichen Resultat tote Teilnehmer müssen null XP haben.
- Aktuelle Level beim Resolve bleiben maßgeblich: ältere angewendete Rewards können eine bereits laufende Quest beeinflussen. Das ist die freigegebene Regel P8-11. Die Sprint-7-Simulationsdateien sind bytegleich.

## Anwendung und Atomarität

RewardApplicationManager erhält den vorhandenen AdventurerManager und optional einen ItemCatalog. Er verwendet dessen gemeinsamen GuildRuntimeStore. Keine zweite Mitglieder- oder Questverwaltung.

TryApply(questId) liest ausschließlich den gespeicherten QuestRuntimeState. Nur Resolved mit gültigem SimulationResult ist zulässig. ObjectiveSucceeded ist kein zusätzliches Gate; Rückzugs-/Misserfolgs-XP bleiben maßgeblich.

Vorbereitung: Identitäten, Teilnehmer, Beträge, Skills und Items validieren; Progression, Gold, Lager, Receipt und Ledger vollständig erzeugen. Genau ein TryPublish veröffentlicht alles. Fehler, rekursive Anwendung und Snapshot-Konflikte erzeugen keinen eigenen Teilzustand. Das interne BeforePublishForTests erlaubt Fault-Injection; es ist keine öffentliche Plugin-Schnittstelle.

Ledger-Schlüssel sind Quest-ID, Resolution-ID und sämtliche Output-IDs, auch Null-XP-/Null-Gold-Ausgaben. Wiederholung liefert AlreadyApplied mit demselben Receipt. Widersprüchliche gespeicherte Resultate werden abgewiesen. Ohne Save gilt diese Einmaligkeit nur innerhalb des aktuellen Laufzeitbestands. Der Retry-Vergleich verwendet die gespeicherte unveränderliche Resultatreferenz; für eine spätere Save-/Restore-Integration muss dieser Vertrag ausdrücklich erweitert werden.

Der gemeinsame Snapshot enthält Economy, Storage und RewardLedger. WithMembers und WithQuests erhalten diese Felder; WithRewards erhält Quests und beobachtete Zeit. AdventurerState.WithQuestConsequences erhält Progression; WithProgression erhält den aktuellen Health-Stand. Alte Snapshots bleiben unverändert.

Die zuvor nicht vorhandene Economy startet als leerer Bestand (0); es wurde kein Startgoldbonus implementiert. Nachfolgende Buchungen addieren auf den aktuellen Bestand. Kein separates Zurücksetzen des Gildengolds bei Manager-Neuerzeugung.

## API und Integration

```csharp
var rewards = new RewardApplicationManager(adventurers, ItemCatalog.CreateV01());
var view = rewards.GetPanelModel(questInstanceId); // keine Mutation
var result = rewards.TryApply(questInstanceId);
if (result.HasNewApplication)
{
    var receipt = result.Receipt; // Änderungen sind bereits übernommen, nicht erneut verbuchen.
}
```

Economy, Storage und Ledger sind als unveränderliche Snapshots lesbar. Das Panel verwendet denselben reinen Vorbereitungsweg zur Validierung. CanApply/IsPreview kennzeichnen eine Vorschau; deren Receipt ist noch nicht verbucht. Bei IsApplied wird der gespeicherte Receipt gezeigt. Lesen ruft weder Clock, Simulation noch Veröffentlichung auf. Die Validierungskennung Applied bedeutet im Preview ausschließlich erfolgreiche Vorbereitung; maßgeblich für die Darstellung sind CanApply, IsPreview und IsApplied.

Die neuen Standard-Items ändern keine vorhandenen Quest-Droptabellen. Vorhandene Test-IDs wie test.loot sind im Produktionskatalog absichtlich nicht automatisch bekannt. Solche Rewards liefern UnknownItemDefinition, bis eine gültige Definition explizit bereitgestellt wird. Keine stillschweigende Substitution oder Löschung von Loot.

Alle Operationen synchron auf dem besitzenden Game-Thread. Keine allgemeine Mehrthread-Transaktion. Bei extrem großen Equipment-Mengen bleibt der reale Speicherbedarf eine technische Grenze; es wird keine spielerische Kapazität erfunden. Preview berechnet ebenfalls die vorbereiteten Zugänge und sollte nicht pro Frame abgefragt werden.

## Extern offene Integration

Keine Unity-Szenen/ScriptableObject-Assets erzeugt. Keine Save-, Equipment-, Combat-, Memorial- oder Wiederbelebungsintegration. C#-Compiler, Unity Test Runner und iOS/Xcode nicht ausgeführt. Interne Sichtbarkeit der Testassemblies muss im tatsächlichen Unity-Projekt korrekt eingerichtet sein. Python-Prüfungen sind keine Laufzeitprüfung dieses C#-Codes.

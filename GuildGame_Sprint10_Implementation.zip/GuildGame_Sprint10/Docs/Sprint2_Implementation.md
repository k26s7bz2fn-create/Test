# Sprint 2 – Implementierung

Status: **technisch vorbereitet, Unity/iOS-Abnahme ausstehend**.

Implementiert wurden ausschließlich die im Sprint-2-Plan vorgesehenen Abenteurerbausteine: datengetriebene vier Grundklassen, reiner Runtime-Katalog, immutable F1-Zustände, seedbare Zufallsquelle, Generator, 12-Mitglieder-Manager, Editor-Datensetup und EditMode-Tests.

Die fünf `.asset`-Dateien sind absichtlich nicht enthalten, weil kein Unity-Editor ausgeführt wurde. `Guild Game > Sprint 2 > Create Adventurer Placeholder Data` erzeugt sie später bewusst und überschreibt vorhandene gültige Daten nicht.

Keine Sprint-1-Datei wurde für diese Lieferung verändert. Save-/GameState-Anbindung bleibt Gate I2 und ist nicht implementiert.

# Sprint 3 – Prüfergebnisse

## Tatsächlich ausgeführt

`Tools/verify_sprint3.py` wurde in der verfügbaren Python-/Dateiumgebung gegen die Sprint-2-Basis und die Sprint-3-Quellen ausgeführt.

**Ergebnis: 83/83 Prüfungen bestanden.**

Die Prüfungen decken unter anderem ab:

- Sprint-2-Klassen- und Rollenvertrag
- F1-Vertrag
- Kapazität 12
- Existenz der Sprint-3-Dateien
- Kandidatenanzahl 5
- Auswahlanzahl 3
- seedbare Zufallsquelle
- deterministische Session-IDs
- Front-/Healing-/Damage-Rollengarantie
- vier kanonische Klassen
- F1-Validierung
- keine unbeabsichtigte Neugenerierung
- erneute Kapazitätsprüfung beim Commit
- atomare Batch-Aufnahme
- Panel ohne Zufalls-/State-Mutation
- kein Save-Zugriff im Recruitment-Scope
- keine out-of-scope Managerreferenzen
- Vorhandensein der geplanten Unity-Testfälle
- einfache strukturelle C#-Quellprüfung
- Sprint-2-Baseline: nur `AdventurerManager.cs` wurde absichtlich geändert
- unabhängige Vertragsprüfung 9+3=12 und 10+3>12

Die vollständige Ausgabe liegt in `Docs/Sprint3_Verification.txt`.

## Angelegt, aber NICHT ausgeführt

Unity EditMode/NUnit-Tests für Sprint 3 wurden als C#-Testquellen angelegt, konnten hier aber nicht ausgeführt werden, weil kein Unity-Editor und kein C#-Compiler vorhanden ist.

Daher wird ausdrücklich NICHT behauptet, dass diese Tests kompiliert oder in Unity bestanden haben.

## Nicht ausgeführt

- Unity C#-Kompilierung
- Unity EditMode Test Runner
- ScriptableObject-Produktionserzeugung
- Xcode/iOS-Build
- Signierung
- Test auf iPhone 16 Pro

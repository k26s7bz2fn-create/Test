# Sprint 7 – tatsächlich ausgeführte Prüfungen

Stand 2026-09-21. Externe Python-Ausführung und begrenzte C#-Quellprüfung. Keine C#-Ausführung.

| Prüfung | Ergebnis | Aussagegrenze |
|---|---:|---|
| Fest erwartete Rechenbeispiele A–I | 9/9 bestanden | Python-Referenzmodell gegen feste Erwartungen |
| Seed-/Invarianten-Szenarien | 576/576 bestanden | 9 Szenarien × 64 Seeds; nicht 576 C#-Tests |
| Weitere Referenzprüfungen | 12/12 bestanden | Domänentrennung, Leiter/Persönlichkeit, Wipe, abstrakte Commit-/Genesungsregeln |
| Vorhandene Party-Referenzfälle | 63/63 bestanden | Unverändertes Python-Modell und Fixtures aus Sprint 5 |
| Vorhandene Quest-Referenzfälle | 54/54 bestanden | Unverändertes Python-Modell und Fixtures aus Sprint 6 |
| Recruitment-Regressionsprüfungen | 81/81 bestanden | Vorhandenes Sprint-3-Prüfwerkzeug; Referenz-/Quellprüfungen |
| Begrenzte Struktur-/Integrationsprüfungen | 34/34 bestanden | Text-/Strukturassertionen, kein Compiler |
| Konstanten-Quellprüfungen | 42/42 bestanden | Literale Defaults, keine Ausführung der C#-Formeln |
| Lexikalische Klammerprüfung | 77/77 C#-Dateien bestanden | Keine Typ-, API-, Assembly- oder Kompilierungsprüfung |
| Sprint-6-Baselinevergleich | 172 bytegleich, 10 erlaubte Änderungen | Alle 182 alten Dateien vorhanden; exakte Änderungspfadliste geprüft |
| Unity-Metadaten | 88 eindeutige GUIDs | Bestandteil der 34 Strukturprüfungen |
| Neue NUnit-Testinstanzen | 38 vorbereitet, **0 ausgeführt** | 9 Beispiele, 4 SHA-Vektoren, 25 weitere Tests |
| C#-Kompilierung | **nicht ausgeführt** | dotnet/csc/mcs/mono/Unity nicht im PATH |
| Unity EditMode / PlayMode | **nicht ausgeführt** | Extern offen |
| Xcode / iPhone | **nicht ausgeführt** | Extern offen |

Keine Addition dieser heterogenen Prüfungen zu einer angeblichen Zahl ausgeführter C#-Tests. Die historischen Komplettprüfer für Sprint 5/6 wurden nicht als unveränderte Gesamtregression deklariert: Sie enthalten inzwischen absichtlich überholte Quell-/Baseline-Gates (unter anderem „keine Simulation“). Ihre unveränderten Referenzfall-Funktionen wurden durch den neuen Runner ausgeführt. Das vollständige Sprint-3-Prüfwerkzeug wurde separat ausgeführt.

## Reproduktion

Aus dem Paketwurzelverzeichnis, mit unverändertem Sprint-6-ZIP:

```bash
python Tools/verify_sprint7.py --baseline /pfad/GuildGame_Sprint6_Implementation.zip
python Tools/verify_sprint3.py
```

Logs: Sprint7_Verification.txt und Sprint7_RecruitmentRegression.txt. Der neue Runner prüft alle vorhandenen C#-Dateien lexikalisch, nicht nur neue Dateien. Er verändert keine Projektdateien.

Im ersten Lauf schlug ein zu breit formulierter Quellcheck fehl: Die Suche nach einem veränderlichen List-Feld traf auch den Text einer IReadOnlyList-Property. Die Prüfung wurde auf eine tatsächliche private List-Felddeklaration begrenzt. Der abschließende vollständige Lauf bestand. Bei der manuellen Quellprüfung wurden neue Fehlercodes ans Enum-Ende verschoben, damit alte numerische Werte unverändert bleiben; dies wird jetzt ebenfalls geprüft.

## Vorbereitete C#-Tests

QuestSimulationTests prüft feste Beispielergebnisse, Seed-Reproduzierbarkeit, Eingabereihenfolge, unterschiedliche Seeds, Verletzungsgrenzen, Rules-Kopie, Sicherheitsgrenzen, Persönlichkeit, Stabilisierung, einen Versuch pro Heiler/Ziel, Rollenbonus ohne Stapelung und vier SHA-Golden-Vektoren.

QuestResolutionTests prüft Zustandsschranken, unbekannte IDs, gemeinsame Resultat-/Health-/Statusveröffentlichung, idempotente Wiederholung, geworfene Simulationsfehler, reentrantes Resolve, Sperren während der Auswertung, Snapshot-Konflikte, tote Mitglieder, Genesungsgrenze, verzögerte Auswertung, Wipe, read-only Panels, ungültige Regeln/Draws, Zeitüberlauf und Freigabe genau eines von drei Aktivplätzen.

Diese Tests müssen in einer korrekt konfigurierten Unity-Testumgebung tatsächlich kompiliert und ausgeführt werden. Vorhandene historische NUnit-/PlayMode-Tests bleiben ebenfalls offen; die Python-Ergebnisse ersetzen sie nicht.

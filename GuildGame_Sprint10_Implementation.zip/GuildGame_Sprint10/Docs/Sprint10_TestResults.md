# Sprint 10 – tatsächliche Prüfungen

Am 2026-09-25 ausgeführt, jeweils Exitcode0:

```sh
python3 GuildGame_Sprint10/Tools/verify_sprint10.py --baseline GuildGame_Sprint9_Implementation.zip --vectors
python3 GuildGame_Sprint10/Tools/verify_sprint9.py --baseline GuildGame_Sprint8_Implementation.zip
python3 GuildGame_Sprint10/Tools/verify_sprint3.py
```

## Neu ausgeführt

- Sprint10: 41 Python-Referenzfälle +128 deterministische Eigenschaftsszenarien =169 bestanden.
- Sprint10: 35 begrenzte statische Quell-/Metadatenprüfungen bestanden.
- Lexikalische Prüfung: 121 C#-Dateien bestanden (keine semantische Kompilierung).
- Vollständige Sprint9-Basis: 305/305 Dateien bytegleich, keine Änderung/Entfernung.
- Sprint9-Runner erneut: 38+128 Equipment-Referenzszenarien, 19 Progressions-,40 Skill-,24 Reward-,63 Party-,54 Quest-,9 Simulationsbeispiele+576 Seed-Szenarien bestanden; außerdem **34** begrenzte Quellprüfungen aus. Einzelwerte im unveränderten Protokoll.
- Recruitment-Runner erneut: 81/81 bestanden (gemischte Referenz-/Quellprüfungen).
- Sprint9-Runner prüfte zusätzlich seinen historischen Sprint8-Bezug: 262 bytegleich und10 bereits aus Sprint9 bekannte Änderungen. Das sind keine neuen Bestandsänderungen in Sprint10.

Die überlappenden Referenzprüfungen werden nicht als unabhängiger Gesamtscore addiert. Historische Statusdateien sind unverändert; nur die oben neu ausgeführten Befehle gelten als aktuelle Nachweise. 597 alte Sprint7-Prüfungen werden hier nicht pauschal behauptet.

## Nicht ausgeführt

C#-Kompilierung: nicht ausgeführt. dotnet/csc/mcs/mono/Unity im PATH nicht vorhanden; auch im zugänglichen /opt/codex kein entsprechendes Compilerprogramm gefunden.

57 gemeinsame tatsächliche C#-Testfälle vorbereitet, darunter vier Cross-Language-Golden-Vektoren; zusätzlich8 Unity-Adapter-Testinstanzen. Insgesamt65 neue NUnit-Testinstanzen vorbereitet, **0 ausgeführt**. Der Standalone-Runner führt57 davon aus, wurde aber hier nicht ausgeführt. Keine C#-Prüfung durch Python ersetzt.

Extern ausführbar aus dem Paket:

```sh
dotnet run --project Tools/CombatCore.Tests/CombatCore.Tests.csproj
```

Unity EditMode/PlayMode, Xcode/IL2CPP/iPhone: nicht ausgeführt. Save-Integration: nicht implementiert.

## Aussagekraft

Python ist ein eigenständiges Referenzmodell. Der Golden-Abgleich mit C# bleibt bis zur tatsächlichen C#-Ausführung offen. Statische Prüfungen prüfen ausgewählte Quellstellen und Lexik; sie beweisen weder Typkorrektheit noch vollständige Laufzeitsemantik. Tests mit injiziertem internem Zustand und Fehlern sind ausschließlich Testcode; Produktions-API bietet keine Zustandsmutation oder RNG-Manipulation an.

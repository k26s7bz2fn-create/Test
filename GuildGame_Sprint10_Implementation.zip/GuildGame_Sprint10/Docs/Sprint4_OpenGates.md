# Sprint 4 Open Gates

1. Open the project in Unity.
2. Run `GuildGame > Sprint 4 > Create Placeholder Guild Hall`.
3. Wire the private serialized references in the Inspector as indicated by the generated hierarchy.
4. Resolve any Unity compilation errors.
5. Run EditMode and PlayMode test suites.
6. Manually validate all six destinations, camera motion, UI priority, occlusion and panel switching.
7. Validate both Landscape orientations and Safe Area on an actual iPhone 16 Pro.
8. Xcode/iOS build remains external.

Full Save integration remains outside Sprint 4.

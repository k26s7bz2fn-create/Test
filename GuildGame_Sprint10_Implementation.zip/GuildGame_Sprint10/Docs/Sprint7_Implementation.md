# Sprint 7 – Implementierungsvertrag

Stand: 2026-09-21. Basis: GuildGame_Sprint6_Implementation.zip. Ausschließlich Quest-Auswertung; kein Sprint 8.

## Autorität und Transaktion

AdventurerManager bleibt der einzige Besitzer des Abenteurerbestands, PartyManager der Besitzer der Gruppenzugehörigkeit. QuestActivityRegistry bleibt die einzige Quest-Registry und Party-Edit-Policy. Es gibt keinen zweiten HealthManager, keine separate Teilnehmerliste neben den vorhandenen Quest-Snapshots und keine zweite Gruppenverwaltung.

Der interne GuildRuntimeStore hält **einen gemeinsamen Veröffentlichungszustand** aus Abenteurern, Quests und beobachtetem Zeitstempel. AdventurerManager liest seinen Bestand daraus; QuestActivityRegistry liest daraus Quests und leitet Sperren/Aktivplätze ab. Alle veröffentlichten AdventurerState- und QuestRuntimeState-Objekte bleiben unveränderliche Snapshots.

TryResolveQuest läuft synchron auf dem besitzenden Game-Thread:

1. ID und Zustand prüfen. Nur CompletedPendingResolution zulässig. Resolved liefert den gespeicherten Beleg mit AlreadyResolved und HasNewResult=false.
2. Gemeinsamen Zustand erfassen, bestehende Gruppe und autoritative Teilnehmer/Klassen auflösen.
3. Eingaben validieren und unveränderlich kopieren; Simulation ohne Zustandsänderung ausführen.
4. Prüfen, dass gemeinsamer Zustand und Gruppe nicht zwischenzeitlich ausgetauscht wurden.
5. Neue Abenteurerzustände, Resultat und Resolved-Quest vollständig vorbereiten.
6. Genau eine Referenzveröffentlichung übernimmt alles zusammen. Erst der veröffentlichte Resolved-Zustand belegt keinen Aktivplatz mehr und liefert keine Gruppen-/Mitgliedersperren mehr.

Bei Fehlern vor Veröffentlichung bleibt der eigene bisherige Zustand erhalten. Bei konkurrierender Änderung durch einen Test-Callback wird StaleState geliefert; fremde Änderungen werden nicht überschrieben. Rekursiver Resolve wird als Busy abgewiesen. Es gibt keine Benutzer-Callbacks zwischen abgeschlossener Vorbereitung und Veröffentlichung. Keine allgemeine Mehrthread-Transaktion: Aufrufe müssen wie bisher auf dem besitzenden Game-Thread erfolgen.

## Öffentliche Nutzung

Bestehende QuestManager-Konstruktoraufrufe bleiben gültig. Optionaler letzter Parameter: QuestSimulationService. Der Dienst kopiert und validiert QuestSimulationRules bei seiner Konstruktion und hält den Seed fest.

```csharp
var rules = new QuestSimulationRules();
var simulation = new QuestSimulationService(rules, seed: 12345);
var quests = new QuestManager(adventurers, parties, catalog, registry, clock, simulation);
// parties muss dieselben adventurers und dieselbe registry verwenden.
// Start und RefreshTime erfolgen wie in Sprint 6.
var attempt = quests.TryResolveQuest(questInstanceId);
if (attempt.HasNewResult)
{
    var receipt = attempt.Result; // Ergebnisdaten; NICHT XP/Gold/Inventar anwenden.
}
```

Ein gespeicherter Beleg ist über QuestRuntimeState.SimulationResult lesbar. Reine Simulate-Aufrufe können für Tests wiederholt werden; sie übernehmen keinen Zustand und sind keine erneute Reward-Ausgabe. Nur ein erfolgreicher TryResolveQuest-Aufruf meldet HasNewResult. Wiederholungen geben denselben gespeicherten Beleg zurück. ResolutionId sowie einzelne XP-/Gold-/Loot-OutputIds dienen späteren Konsumenten als stabile Identitäten, ersetzen aber keine persistente Exactly-once-Verarbeitung. Save/Neustart-Persistenz bleibt offen.

## Freigegebene Rechenregeln im Code

Alle Balanceparameter liegen in QuestSimulationRules. Dezimalrechnung vermeidet plattformabhängige Float-Rechenpfade. F hat Rangindex 0. Die vorhandene AdventurerState-Basis liefert weiterhin F1. Weitere Rangkennungen können explizit im Regelkatalog auf Indizes abgebildet werden; es werden keine neuen Rangnamen oder Progressionsregeln eingeführt. Die Testkennung TEST.R1 testet ausschließlich Rangindex 1.

- Einzelstärke: `10 × (1 + 0,10 × (Level − 1)) × 1,5^Rangindex`.
- PartyPower: Summe × `(1 + 0,08 bei Tank + 0,08 bei Healing + 0,04 bei Damage)`. Jede Abdeckung zählt einmal. SupportControl gibt keinen zusätzlichen Bonus.
- Schwierigkeit: `10 × empfohlene Gruppengröße × 1,5^Quest-Rangindex × Gefahrfaktor`. Niedrig=0,8; Normal=1; Hoch=1,25. Entfernung erzeugt keinen weiteren Faktor.
- Verhältnis R: `PartyPower / Schwierigkeit × (1 + 0,05 × (2u − 1))`.
- Überforderung H: `clamp((1 − R)/0,5, 0, 1)`.
- Rückzugschance: `clamp(H × (0,45 + 0,40q − 0,03B), 0, 0,90)`. q=Leiterqualität in [0,1], vorhandener Leiter standardmäßig 0,5; ohne Leiter 0. B=mittlere Persönlichkeitskühnheit in [−1,1], standardmäßig neutral 0. Es werden keine Persönlichkeitsnamen erfunden.
- Ohne Rückzug Zielerfolg mit `clamp(0,10 + 0,80R, 0,05, 0,98)`.
- Kampfunfähigkeit je Mitglied: `clamp(0,45 × (1 − R), 0, 0,45)`, bei Rückzug ×0,35.
- Verletzungsprüfung für nicht kampfunfähige Überlebende: `clamp(0,10 + 0,30 × (1 − R), 0, 0,40)`, bei Rückzug ×0,60.
- Alle Kampfunfähigkeiten werden zuerst bestimmt. Kampfunfähigkeit bezeichnet abstrakt 0 HP; kein HP-/Combat-System wird hinzugefügt.
- Nur nicht kampfunfähige Healing-Mitglieder stabilisieren. Je Heiler ein Versuch, je Ziel höchstens ein Versuch, kanonische ID-Reihenfolge. Chance 0,65; ein fehlgeschlagener Versuch verbraucht beide Plätze.
- Nicht stabilisierte Kampfunfähige sterben mit `clamp(0,15 + 0,50H + 0,20 bei vollständiger Kampfunfähigkeit, 0, 0,90)`.
- Stabilisierte sterben in dieser Auswertung nicht. Überlebende Kampfunfähige sind verletzt.
- Wipe bedeutet ausschließlich: alle Teilnehmer tot. Vollständige Kampfunfähigkeit allein ist kein Wipe.
- Verletzungsdauer: `ceil(clamp(60 + 180H + 60 bei Kampfunfähigkeit, 60, 300))` Sekunden. Tote erhalten keine Genesungszeit.
- RecoveryUntil: `CompletionTimestamp + Dauer × 1000`. Eine verspätete Auswertung verlängert die Erholung nicht. Bei `now >= RecoveryUntil` ist der Überlebende wieder einsatzfähig; dafür ist kein Schreibvorgang erforderlich.

Alle Zufallsvergleiche verwenden strikt `u < Chance`. Der Zufallswert liegt in [0,1).

## Rewards ausschließlich als Result-Daten

Die GoldReward-/XpReward-Werte der bestehenden QuestDefinition sind autoritativ. Keine unbemerkte Überschreibung vorhandener Definitionen. Die freigegebenen Autoren-Richtwerte lauten `floor(30 × empfohlene Größe × Rangfaktor × Gefahrfaktor)` für Basis-XP und entsprechend 20 für Gold; diese Koeffizienten liegen zentral vor, erzeugen jedoch keine neuen Quests/Assets.

- XP-Poolfaktor: Erfolg 1; Rückzug 0,35; sonst 0,20; Wipe 0.
- Je Überlebendem `floor(Definition.XpReward × Faktor / Teilnehmerzahl beim Start)`; Tote erhalten 0. Keine Umverteilung ihrer Anteile.
- Gold: volle Definition.GoldReward nur bei Zielerfolg und mindestens einem Überlebenden, sonst 0.
- Loot: nur bei Erfolg ohne Wipe. Je vorhandener Loot-Vertragszeile Dropchance 0,35. Menge gleichverteilt ganzzahlig von max(1, MinimumQuantity) bis MaximumQuantity. MaximumQuantity=0 ergibt keinen Drop. Einträge werden kanonisch sortiert; identische Zeilen erhalten getrennte stabile Vorkommensnummern.
- Resultat enthält getrennte Zielerfolgs-, Rückzugs- und Wipe-Flags, Mitgliederfolgen, XP-Anteile, Gold und Loot. Erfolg kann gleichzeitig Verletzung und Tod enthalten. Es gibt kein exklusives Outcome-Enum.

## Determinismus

SHA-256 über UTF-8-Strings mit jeweils vier Byte langer Big-Endian-Längenpräfixierung. Eingaben: Seed als invarianter Integerstring, Questinstanz-ID, Regelversion und Zufallsdomäne. Die ersten 53 Bits ergeben `Integer / 2^53`. Domänen trennen Power, Rückzug, Zielerfolg, Kampfunfähigkeit/Verletzung/Tod pro ID, Heiler-Ziel-Paar und Loot-Zeile/Menge.

Teilnehmer und Loot werden kanonisch sortiert. InputFingerprint und RulesFingerprint dokumentieren den verwendeten Vertrag. Gleiche unveränderte Eingaben, gleiche Regeln und gleicher Seed ergeben gleiche Ergebnisse. Regeländerungen ändern den Belegfingerprint. Tests injizieren ausschließlich intern einen Draw-Lieferanten; produktiv ist SHA-256 fest eingebaut.

## Autoritativer Lebensstatus und Verfügbarkeit

AdventurerState trägt IsDead und RecoveryUntil. Todesstatus bleibt bei jeder Folgenübernahme erhalten und hat keine öffentliche Rücksetzfunktion. Bestehende ID, Klasse, Name und Erscheinung bleiben unverändert. LeadershipQuality/PersonalityBoldness sind validierte Eingabeskalare; die bisherige Factory bleibt mit neutralen Defaults verwendbar.

Tote sind für neue Gruppenaufnahme, Transfer, Gruppen-Neubesetzung und Leiterzuweisung gesperrt. Bestehende tote Gruppenmitglieder werden nicht automatisch entfernt; manuelles Entfernen oder Auflösen bleibt möglich. Der letzte Einzelplatz wird weiterhin über Gruppenauflösung entfernt. Entfernen des Leiters leert weiterhin dessen Slot. Noch Verletzte dürfen in inaktiven Gruppen verwaltet werden, aber keinen neuen Queststart mitmachen. Jeder Queststart prüft den aktuellen autoritativen Bestand und die Genesungszeit.

Gruppen-/Panel-Snapshots bleiben read-only. PartyPanel zeigt Tod und Genesungszeit; seine IsAvailable-Angabe bezeichnet freie Gruppenzuordnung, nicht Einsatzfähigkeit. QuestPanel validiert Einsatzfähigkeit anhand der zuletzt explizit beobachteten Zeit. Zum Aktualisieren der Uhr ist RefreshTime erforderlich; Lesen hat keine Nebenwirkungen.

## Grenzen und Integration

Unbekannte Rang-/Gefahrbezeichnungen führen beim Resolve zu InvalidInputOrRules und lassen Sperren erhalten. Sprint 6 erlaubte freie beschreibende Bezeichnungen; vor Nutzung müssen tatsächliche Questdaten auf die konfigurierten Kennungen abgestimmt werden. Testbezeichnung TEST ONLY aus Sprint 6 wird ausdrücklich nicht als Produktions-Balancewert interpretiert. Es wurden keine ScriptableObject-Assets erzeugt.

Ein QuestManager/Registry-Paar bindet den gemeinsamen Bestand genau einmal. Bestehende externe Referenzen auf AdventurerState sind historische Snapshots und müssen bei Anzeige aktueller Gesundheit neu über AdventurerManager gelesen werden. Uhr-Rücksprünge werden wie in Sprint 6 nicht durch ein neues Offline-/Anti-Cheat-System korrigiert.

Keine Progression-, Inventory-, Equipment-, Save-, SoulStone-, Memorial-, Combat- oder Dungeon-Anwendung. Keine Szenen-/3D-Erweiterung. Unity-Assembly-/Test-Integration und IL2CPP-Verfügbarkeit der SHA-/Reflection-Nutzung bleiben Teil der externen Unity/iOS-Prüfung.

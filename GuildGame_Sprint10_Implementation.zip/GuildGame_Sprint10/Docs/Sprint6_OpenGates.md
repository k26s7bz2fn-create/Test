# Sprint 6 – Offene Gates

- C6/U6: C#-Compiler und Unity nicht verfügbar (`dotnet`, `csc`, `mcs`, `mono`, `Unity` nicht im PATH). Keine Kompilierung behauptet.
- T6: 90 neue vorbereitete NUnit-Testinstanzen NICHT ausgeführt. Bestehende NUnit-/Unity-Tests ebenfalls nicht ausgeführt.
- Unity-EditMode/PlayMode, Skriptimport, Test-Assembly-Konfiguration und Composition-Root-Integration offen.
- Produktive Quest-ScriptableObjects nicht erzeugt. Testwerte sind kein freigegebenes Balancing.
- Sprint-4-Szene/Prefab/Verdrahtung und ältere Produktionsassets weiterhin offen; keine nachträgliche Hallenimplementierung.
- Xcode, iOS-Signierung, iPhone-16-Pro-Abnahme und Performance offen.
- Vollständige Save-/GameState-Integration offen. Keine Wiederherstellung nach Prozessende.
- CompletedPendingResolution bleibt in Sprint 6 absichtlich dauerhaft gesperrt und belegt Plätze. Kein Resolve-/Freigabeweg, bis ein späterer Sprint den QuestSimulationService implementiert.
- Keine allgemeine Thread-Sicherheit oder Absicherung gegen Geräteuhr-Manipulation. Betrieb auf dem besitzenden Spielthread, Clock-Abfragen ohne Seiteneffekte.

Sprint 7 wurde nicht begonnen.

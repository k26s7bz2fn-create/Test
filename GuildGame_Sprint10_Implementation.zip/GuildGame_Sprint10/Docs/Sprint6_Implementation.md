# Sprint 6 – Quest-System ohne Ergebnisberechnung

Stand: 15.09.2026. Quellimplementierung; C#-/Unity-Ausführung noch offen.

## Verbindliches Verhalten

`Available -> Active -> CompletedPendingResolution -> Resolved`

Sprint 6 implementiert ausschließlich die ersten beiden Übergänge. `Resolved` ist als Enumwert für die spätere Auswertung vorgesehen. Es gibt keine Resolve-, Release-, Ergebnis-, Loot- oder Reward-Operation. Eine Pending-Quest bleibt unbegrenzt gebunden, bis ein späterer Sprint die tatsächliche Auswertung implementiert. Kein automatischer oder versteckter Reset nach drei Quests.

`Active` und `CompletedPendingResolution` belegen jeweils einen der maximal drei Plätze, sperren die Gruppe und alle Teilnehmer einschließlich des Leiters. Gruppenumbau, Auflösung, Transfer in beide Richtungen und Leiteränderung werden durch die vorhandenen PartyManager-Operationen abgelehnt.

Quests verwenden genau eine existierende Gruppe mit 1–6 gültigen Mitgliedern. Gruppengröße-Empfehlung, Rang, Gefahr und Entfernung sind Beschreibungsdaten, keine neuen Startverbote oder Modifikatoren. Kein Rollenminimum. Die gesamte Gilde darf weiterhin mehr als drei Gruppen besitzen.

## Daten

- `QuestDefinition`: ScriptableObject-Autorenschnittstelle, noch keine produktiven Assets erzeugt.
- `QuestDefinitionData`: validierter unveränderlicher Runtime-Snapshot mit ID, Name, Typ, Rang, Entfernung, Dauer, Empfehlung, Gefahrenlabel, Gold/XP und möglicher Beute.
- `QuestCatalog`: kopierter Definitionskatalog; keine Runtime-Aktualisierung laufender Definitionen.
- Vier Typen: Gathering/Sammeln, Delivery/Lieferung, MonsterHunt/Monsterjagd, Rescue/Rettung.
- Drei Entfernungen: Near/Nah, Medium/Mittel, Far/Weit.
- Rang bleibt ein erforderlicher beschreibender String; keine erfundene Rangliste oder Freischaltprüfung.
- `QuestLootContract`: Itemdefinitions-ID, optionaler Anzeigename, Minimum/Maximum. Keine Iteminstanz, Dropwahrscheinlichkeit oder Inventarzuweisung.
- IDs konkreter Questinstanzen sind nicht leere GUIDs mit kanonischer D-Darstellung; Definitionen haben stabile Text-IDs.
- Gold und XP sind nicht negative Anzeigewerte. Sie werden weder verbucht noch unter Teilnehmern aufgeteilt.

Es wurden keine produktiven Quests oder Balancingwerte erfunden. Alle konkreten Zahlen in Tests sind als TEST ONLY markiert. Ein aufrufender Ablauf registriert ausdrücklich bereitgestellte Angebote mit `TryRegisterOffer`; es gibt weder prozedurale Angebotserzeugung noch Auffrischung, Rerolls oder automatische Wiederholung.

## Gemeinsame Zustandsquelle

`QuestActivityRegistry` ist die eine autoritative Quelle für Questzustand und davon abgeleitete Sperren. Kein zweiter Gruppenbestand und kein zweites veränderbares Sperrregister. Registry-Snapshots und QuestRuntimeState sind nach außen unveränderlich.

Ein Start validiert zunächst alles und veröffentlicht dann den vollständigen neuen Registry-Snapshot. Status, Gruppen-ID, Teilnehmer, Leiter und Zeitstempel werden gemeinsam sichtbar. Rejected Starts publizieren keine Reservierung. Die vorgeschaltete explizite Zeitfortschreibung darf bereits laufende Quests nach Pending überführen; diese unabhängige Fortschreibung wird bei einem abgewiesenen neuen Start nicht zurückgerollt.

Alle Befehle gehören synchron auf den besitzenden Spielthread. Zeitquelle ist eine seiteneffektfreie Abhängigkeit; keine reentranten Spielbefehle aus Clock-Callbacks. Keine Behauptung beliebiger Thread-Sicherheit.

## Minimale notwendige Änderung an Sprint 5

Datei: `Assets/_Project/Scripts/Party/PartyManager.cs`.

Einzige Ergänzung:

```csharp
// Sprint 6: reject mismatched quest/party composition roots; no gameplay mutation.
internal bool UsesDependencies(AdventurerManager members, IPartyEditPolicy policy) =>
    ReferenceEquals(adventurers, members) && ReferenceEquals(editPolicy, policy);
```

Grund: Die bisher private readonly EditPolicy war nicht verifizierbar. Ohne Identitätsprüfung könnte ein QuestManager eine andere Registry verwenden, während PartyManager weiterhin die inaktive Standardpolitik benutzt. Auch ein abweichender AdventurerManager muss ausgeschlossen werden. Die Ergänzung liest nur Identitäten und verändert keine bisherige Gruppenregel.

QuestManager lehnt falsche Verdrahtung beim Konstruktoraufruf ab. Eine Registry kann nur an einen autoritativen QuestManager gebunden werden. Andere bestehende Dateien bleiben unverändert.

## Initialisierung im späteren Composition Root

1. Bestehenden AdventurerManager und AdventurerCatalog verwenden.
2. Eine QuestActivityRegistry erstellen.
3. Die reguläre PartyManager-Instanz von Anfang an mit dieser Registry als EditPolicy erstellen.
4. QuestCatalog aus validierten Definitionen bereitstellen.
5. QuestManager mit demselben AdventurerManager, demselben PartyManager, Katalog, Registry und IQuestClock erstellen.
6. Explizite Questangebote registrieren.
7. Vor UI-Darstellung bzw. bei Wiederaufnahme `RefreshTime()` aufrufen und danach Datenmodelle lesen.

Keinen zusätzlichen PartyManager neben einem bestehenden befüllten Manager erzeugen. Ein schon mit der Standardpolitik erstellter Manager wird kontrolliert abgelehnt; eine Migration laufender Sessions oder Save-Daten gehört nicht zu diesem Sprint. Der tatsächliche Unity-Bootstrap bleibt extern anzubinden/zu prüfen, da das gelieferte Quellpaket kein vollständiges ausgeführtes Unity-Projekt ist.

## Zeitmodell

`IQuestClock.UtcNowMilliseconds`: UTC-Unix-Millisekunden als long, nicht negativ. Produktionsadapter `SystemQuestClock` verwendet die UTC-Systemuhr; Tests FakeClock.

`CompletionTimestamp = checked(StartTimestamp + checked(ExpectedDurationSeconds * 1000L))`.

- Dauer positiv, Überlauf abgewiesen.
- Start liest die Uhr einmal, vor den Gruppen-/Belegungsprüfungen.
- RefreshTime überführt ausschließlich Active bei `now >= CompletionTimestamp` nach CompletedPendingResolution.
- Wiederholte Refresh-Aufrufe erzeugen keine Mehrfachauswertung.
- Zeitrücksprung setzt erreichte Zustände nicht zurück. Verbleibende Dauer wird auf null bis ursprüngliche Dauer begrenzt.
- Kein Frame-/Tick-Aufholen; ein großer Zeitsprung reicht für den zeitlichen Statuswechsel.
- Keine Serverzeit oder Manipulationssicherheit.

Offline-Fortschritt ist für einen erhaltenen Laufzeitstand über Zeitstempel vorbereitet und per FakeClock testbar. Nach Prozessende fehlt ohne Save-Integration die Wiederherstellung. Keine Persistenz oder automatische Unity-Serialisierung der Runtime-Objekte behauptet.

## Panelvertrag

`GetBoardModel` und `GetPanelModel` lesen ausschließlich den zuletzt explizit beobachteten Zeitstand (`AsOfTimestamp`). Sie lesen nicht die Uhr und verändern keinen Status. Vor dem ersten Refresh ist AsOfTimestamp null und eine Startvorschau meldet InvalidTimestamp. `TryStartQuest` selbst liest/validiert die Uhr und funktioniert unabhängig von einer vorherigen Panelabfrage.

Die Modelle enthalten immutable Quest-/Definitions-Snapshots, vorhandene Gruppen/Leiter, Startfähigkeit mit Fehlercode, Belegungszahl, Restzeit und Pending-Anzeige. Die Vorschau ist unverbindlich; Start prüft erneut. Keine Belohnungsabholung, Abbruchaktion oder neue 3D-UI.

## Definitionsergebnisse und Fehler

Definitionen folgen dem bestehenden Muster `TryBuildData`/`TryCreate` mit bool und Fehlertext; Runtime-Befehle liefern QuestResult mit QuestResultCode. Konfigurationsfehler im Composition Root werfen gezielte Argument-/InvalidOperation-Ausnahmen. Fehlende Gruppenmitglieder führen über die bestehende Composition-Validierung zu InvalidPartyComposition; der QuestManager prüft Teilnehmer zusätzlich direkt.

## Reproduzierbare Prüfung

Vom Paketwurzelverzeichnis:

    python Tools/verify_sprint6.py --baseline /pfad/GuildGame_Sprint5_Implementation.zip
    python Tools/verify_sprint5.py --baseline /pfad/GuildGame_Sprint4_Implementation.zip
    python Tools/verify_sprint3.py

Python führt unabhängige Referenzszenarien und begrenzte Quellprüfungen aus, NICHT C#.

Die 54 gemeinsamen JSON-Szenarien werden ebenfalls von NUnit auf dem tatsächlichen C#-QuestManager und PartyManager ausgeführt, sobald Unity verfügbar ist. Weitere 36 NUnit-Testinstanzen prüfen Definitionen, Verdrahtung, Schutz gegen fehlerhafte Zustände, read-only Daten, Zeitgrenzen und GUIDs. Fault-Injection ist ausschließlich in Tests enthalten, nicht in der Produktions-API.

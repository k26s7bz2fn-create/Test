# Sprint 3 – Implementierung

Status: **implementiert und unabhängig statisch/vertraglich geprüft; Unity/iOS-Abnahme ausstehend**.

## Quellenabgleich

Die zuvor offene Rollenfrage ist durch die tatsächlichen Sprint-2-Quellen beantwortet:

- `class.warrior` = Tank + Damage
- `class.rogue` = Damage
- `class.mage` = Damage + SupportControl
- `class.priest` = Healing + SupportControl

Der F1-Vertrag ist ebenfalls eindeutig in Sprint 2 definiert:

- Rang `F`
- Level `1`

Damit blockiert keine offene Produktentscheidung Sprint 3.

## Implementiert

Neu unter `Assets/_Project/Scripts/Recruitment/`:

- `RecruitmentManager.cs`
- `RecruitmentCandidate.cs`
- `RecruitmentSession.cs`
- `RecruitmentState.cs`
- `RecruitmentResult.cs`
- `StartCandidateGenerator.cs`
- `RecruitmentPanelModel.cs`

Neu unter `Assets/_Project/Tests/EditMode/Recruitment/`:

- `StartCandidateGeneratorTests.cs`
- `RecruitmentManagerTests.cs`
- `RecruitmentPanelModelTests.cs`

Neu:

- `Assets/_Project/Tests/Fixtures/recruitment_v01_cases.json`
- `Tools/verify_sprint3.py`

## Bewusst geänderte Sprint-2-Datei

`Assets/_Project/Scripts/Adventurers/AdventurerManager.cs`

Grund: Für die geforderte atomare Übernahme genau dreier Kandidaten war eine kleine Batch-Aufnahme erforderlich. `TryAddBatch` validiert den vollständigen Satz vor der ersten Mutation. Damit entsteht bei Duplicate-ID, ungültigem Zustand oder Kapazitätsfehler keine Teilaufnahme.

Keine zweite Mitgliederverwaltung wurde eingeführt.

## Kandidatengenerierung

- exakt 5 Kandidaten
- ausschließlich die vier Sprint-2-Grundklassen
- F1 gemäß bestehendem Sprint-2-Vertrag
- seedbar und reproduzierbar
- Kandidaten-IDs deterministisch aus Session-ID + Position
- gleiche Session + gleicher Seed + gleiche Definitionen -> gleicher Satz
- gleiche Seeds in unterschiedlichen Sessions -> unterschiedliche IDs

Die ersten drei konstruktiven Rollenplätze garantieren drei verschiedene Kandidaten für:

1. Frontkampf: Tank, aktuell Krieger
2. Heilung: Healing, aktuell Priester
3. primären Schaden: Damage, aber nicht derselbe Front-/Heilkandidat, aktuell Schurke anhand der kanonischen Reihenfolge

Die zwei weiteren Kandidaten werden seedbasiert aus den vier kanonischen Klassen ergänzt.

## Rekrutierungsablauf

`Created -> Selecting -> Committed`

- höchstens 3 Kandidaten gleichzeitig ausgewählt
- Commit nur bei exakt 3
- Sessionfremde Kandidaten werden abgelehnt
- erneute Auswahl derselben ID wird abgelehnt
- Abwahl vor Commit möglich
- 12-Mitglieder-Limit wird beim Commit erneut geprüft
- bei 9 bestehenden Mitgliedern sind 3 zulässig
- ab 10 bestehenden Mitgliedern wird der Commit blockiert
- Commit ist atomar
- nach `Committed` keine zweite Aufnahme oder Auswahländerung
- erneutes Initialisieren würfelt nicht neu

## UI-Vertrag

`RecruitmentPanelModel` ist eine schreibgeschützte Projektion. Panel-Lesen erzeugt keine Kandidaten, verbraucht keinen Zufall und verändert keinen Zustand.

Eine 3D-Ansicht wurde nicht implementiert.

## Ausgeschlossener Scope eingehalten

Nicht hinzugefügt wurden Party, Quests, Combat, Dungeon, Inventory, Equipment, Buildings, Relationships, 3D-Gildenhalle oder Save-Integration.

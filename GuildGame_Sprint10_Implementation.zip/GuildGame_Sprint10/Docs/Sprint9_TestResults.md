# Sprint 9 – tatsächliche Prüfungen

Stand: 2026-09-24. Befehle aus dem Verzeichnis oberhalb des Projektordners:

```sh
python3 GuildGame_Sprint9/Tools/verify_sprint9.py --baseline GuildGame_Sprint8_Implementation.zip
python3 GuildGame_Sprint9/Tools/verify_sprint3.py
```

Beide Befehle beendet mit Exitcode 0. Die beigefügten Textprotokolle enthalten die einzelnen tatsächlich ausgeführten Prüfungen.

- baseline_documented_change: 10 bestanden.
- baseline_unchanged: 262 bestanden.
- bounded_source_checks: 34 bestanden.
- equipment_property_scenarios: 128 bestanden.
- equipment_reference: 38 bestanden.
- formula_files_unchanged: 9 bestanden.
- lexical_source_files: 109 bestanden.
- regression_party_reference_regression: 63 bestanden.
- regression_progression_reference: 19 bestanden.
- regression_quest_reference_regression: 54 bestanden.
- regression_reward_reference: 24 bestanden.
- regression_simulation_reference_examples: 9 bestanden.
- regression_simulation_seed_scenarios: 576 bestanden.
- regression_skill_reference: 40 bestanden.
- Recruitment-Runner: 81/81 bestanden (gemischte Referenz-/Quellprüfungen).

**Keine dieser Prüfungen kompiliert oder führt C# aus.** Python-Referenzen sind separate Modelle; statische Prüfungen sind begrenzte Text-/Lexikalprüfungen, keine semantische C#-Analyse.

37 neue NUnit-Testinstanzen vorbereitet, 0 ausgeführt. Zwei vorhandene Testdateien an die fachlich neue Nachverarbeitung angepasst. Alle übrigen NUnit-/PlayMode-Tests ebenfalls nicht ausgeführt.

Historische Python-Modelle für Sprint 5, 6, 7 und 8 wurden über den Referenzteil des unveränderten Sprint-8-Werkzeugs neu ausgeführt. Die früheren Quelltext- und Baseline-Gates sind versionsgebunden und wurden dabei ausdrücklich nicht ausgeführt. Der Sprint-9-Runner liest diesen abgegrenzten Referenzabschnitt in-memory; keine historischen Werkzeuge geändert. Für Sprint 7 sind hier 585 Simulationsfälle neu ausgeführt, nicht der frühere vollständige 597er-Runner. Historische Statusberichte bleiben unverändert und gelten nicht als aktuelle Testergebnisse.

Compilerprüfung: `command -v dotnet csc mcs mono Unity python3` lieferte ausschließlich Python. C#-Kompilierung, NUnit/Unity, Xcode/iPhone und Save-Integration bleiben offen.

# Sprint 2 – Testergebnisse

Status: **technisch vorbereitet, Unity/iOS-Abnahme ausstehend**.

## Tatsächlich ausgeführt

- Drei bereitgestellte ZIP-Pakete konnten vollständig geöffnet und per ZIP-CRC geprüft werden.
- `GuildGame_Sprint1_Implementation(2).zip`: PASS, 68 Archiveinträge.
- `Guild_Game_Work_Package(3).zip`: PASS, 9 Archiveinträge.
- `GuildGame_Sprint2_Plan_und_Codex_Auftrag(2).zip`: PASS, 5 Archiveinträge.
- Sprint-1-Hashbaseline: PASS. Alle 68 im Planungspaket erfassten Sprint-1-Dateien stimmen per SHA-256 unverändert überein.
- Sprint-2-Python-Referenz-/Scopeprüfung: **16/16 bestanden**. Diese Prüfung validiert Datenvertrag, erwartete Quellstruktur, verbotene Sprint-1-Dateien und Hashbaseline. Sie kompiliert oder führt C# nicht aus.
- Sprint-2-Quellumfang: exakt 13 C#-Dateien gemäß Plan/Tests/Editor-Setup.

## Statisch geprüft

- Vier stabile Klassen-IDs und Rollenmetadaten sind im Katalogvertrag abgebildet.
- Namenpool enthält 8 Platzhalter; Lookpool enthält 3 Adult-Human-Platzhalter.
- Generator trennt ID-Fabrik und seedbare Zufallsquelle und fügt nicht automatisch zum Manager hinzu.
- Managergrenze ist 12; DuplicateId wird vor CapacityReached geprüft.
- Snapshot wird über eine ReadOnlyCollection auf einer Array-Kopie zurückgegeben.
- Sprint-2-Paket enthält keine Kopien oder Änderungen von GameState, GameManager, SaveDataV1, SaveCodec, SaveManager, BootEntryPoint oder DebugStartPanel.
- Die fünf `.asset`-Dateien wurden nicht vorgetäuscht; nur der Editor-Erzeugungscode ist enthalten.

## Nicht ausgeführt / nicht nachgewiesen

- Kein C#-Compiler ist in dieser Umgebung verfügbar. Daher kein echter C#-Compile-Nachweis.
- Unity wurde nicht ausgeführt; EditMode-Tests sind geschrieben, aber nicht ausgeführt.
- ScriptableObject-Assets wurden nicht im Unity-Editor erzeugt.
- Save-Integration I2 bleibt offen.
- Xcode-Build, Signierung und iPhone-16-Pro-Abnahme bleiben offen.

Python-Referenztests sind ausdrücklich **kein** C#-/Unity-Nachweis.

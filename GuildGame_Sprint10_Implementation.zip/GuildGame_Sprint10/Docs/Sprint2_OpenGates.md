# Sprint 2 – Offene Gates

- **B1/U1:** Sprint-1 Unity-Kompilierung und echte Unity-Tests weiterhin offen.
- **C2:** C# wurde hier nicht mit einem C#-/Unity-Compiler kompiliert.
- **T2:** EditMode-Tests sind geschrieben, aber nicht in Unity ausgeführt.
- **U2:** Unity-Import, Asseterzeugung und tatsächliche ScriptableObject-Serialisierung offen.
- **I2:** AdventurerState/Manager sind noch nicht an GameState/SaveData angebunden. Keine Save-Version geändert.
- **X1/D1:** Xcode-Build, Signierung und iPhone-16-Pro-Abnahme weiterhin offen.

Unity/iOS-Abnahme ausstehend.

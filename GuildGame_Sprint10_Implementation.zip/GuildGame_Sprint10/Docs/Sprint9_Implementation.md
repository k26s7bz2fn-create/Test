# Sprint 9 – Implementierung und freigegebene Regeln

Verbindlich sind die Nutzerfreigabe R9-01 bis R9-09 und deren endgültige Änderungen an R9-02/R9-06/R9-07/R9-08/R9-09. Keine neue Combat-, Simulations- oder Progressionswirkung.

## R9-01: Auswahlwerte

| Bestehende Definition | Tank | Damage | Healing | SupportControl |
|---|---:|---:|---:|---:|
| item.weapon.training_sword.common | 2 | 2 | 0 | 0 |
| item.weapon.training_dagger.common | 0 | 2 | 0 | 0 |
| item.weapon.training_staff.common | 0 | 2 | 0 | 0 |
| item.weapon.training_mace.common | 0 | 0 | 2 | 2 |
| item.armor.training_upper.common | 1 | 1 | 1 | 1 |
| item.armor.training_legs.common | 1 | 1 | 1 | 1 |

Eignung ist die Summe der Werte für die bestehenden Rollenflags der Klasse. Keine neue Rollenarchitektur; insbesondere werden vorhandene SupportControl-Flags nicht entfernt. Summe in long, keine int-Überläufe. Itemkatalog und erlaubte Klassen aus Sprint 8 bleiben erhalten. Tränke haben keine Equipmentbewertung.

## R9-02/R9-03: Vergleich

Zuerst Slot/Klasse zulässig. Höhere Rolleneignung entscheidet; ausschließlich bei gleicher Eignung höhere Rarity. Bei beidem Gleichstand bleibt das angelegte Item. Lagerkandidaten bei sonstigem Gleichstand DefinitionId ordinal, dann InstanceId ordinal. Keine ältere Einzelrollen-Veto-Regel. AdventurerId ordinal, Slots Weapon → UpperBody → Legs.

## R9-04/R9-05: Verteilung und Sperren

Nur freie Lagerinstanzen werden berücksichtigt; keine Wegnahme bei lebenden anderen Trägern. Ersetzte Instanz wird im selben vorbereiteten Zustand zurückgelegt. Deterministische Durchläufe bis kein Upgrade mehr möglich ist. Strikte Qualitätserhöhung je Slot und endlicher Itembestand verhindern endloses Tauschen. Nur einmalige Veröffentlichung des fertigen Durchlaufs.

Tote werden nicht neu ausgerüstet. Lebende verletzte, aber nicht questgebundene Mitglieder dürfen Equipment erhalten. Active und CompletedPendingResolution sperren Neubewertung und explizite Rückgaben. Manuelle Service-Aufrufe: EquipmentManager.TryReevaluateAll/TryReevaluate/TryReturnEquipment/TryReturnPotions. Keine UI-/3D-Erweiterung.

## R9-06: Tränke

Vor Start maximal ein vorhandener basic HealingPotion pro einsatzfähigem Zielmitglied. Heilrollen zuerst (ordinal), danach Leader, sofern nicht bereits Heilrolle, danach übrige IDs ordinal. Bereits ein zugewiesener Trank wird nicht verdoppelt. Fehlbestand ist informativ, blockiert nicht. Keine Kampfverwendung.

## R9-07: Resolve

Simulation bleibt unverändert. Staging umfasst Lebensfolgen, Resultat, Resolved, alle ungenutzten Tränke und Equipment toter Teilnehmer. Danach genau ein autoritatives Publish. Lebende behalten ihr Equipment. Rückführungsfehler/Überlauf lassen Pending, Leben, Items und alle Sperren unverändert. Wipe gibt das Equipment aller nun toten Teilnehmer zurück. Gilt nur für normalen Questpfad; keine künftige Dungeon-Regel.

## R9-08: Reward-Nachlauf

RewardApplicationManager veröffentlicht zuerst den vollständigen alten Reward-Commit. Danach genau ein getrennter Auto-Equip-Versuch für alle lebenden ungesperrten Mitglieder einschließlich Verletzter. EquipmentPostProcessing zeigt Fehler getrennt; Reward bleibt Applied. Bereits im Ledger vorhandene Rewards gehen vor dem Nachlauf zurück. Ein Retry löst keinen zweiten Nachlauf aus. Nach fehlgeschlagenem Nachlauf ist ein expliziter EquipmentManager-Aufruf möglich, ohne Rewards zu wiederholen.

## R9-09: Queststart

Nach bestehender Gruppen-/Lebens-/Slotlimitprüfung: nur Zielgruppe ausrüsten, Tränke zuteilen, Zeitübergänge und Active-Zustand vorbereiten. Alles zusammen mit Sperren im gemeinsamen Snapshot veröffentlichen. Fehlende Ausrüstung/Tränke sind erlaubt. Inkonsistente Identitäten/Definitionen/Standorte scheitern ohne Teilzustand. Ein fehlgeschlagener Start führt nicht mehr nebenbei RefreshTime aus; RefreshTime bleibt separat verfügbar.

## Autoritative Standorte und Atomarität

Es gibt keine zweite Itemdatenbank. GuildStorageState.Equipment enthält nur freie Instanzen; AdventurerState.Equipment enthält zugewiesene Instanzen. Globale Konsistenz prüft die Vereinigung: jede ID genau einmal, Schlüssel/Instanzidentität, Slot/Klasse, Definitionskonsistenz. Transfers behalten dieselbe EquipmentInstance-Objektreferenz. GuildRuntimeSnapshot.WithEquipment erhält Economy, Ledger, Quests und Zeit. Potions liegen entweder im gemeinsamen Stapel oder in einer autoritativen Mitgliederzuweisung. Conservation prüft Mengenerhaltung; Summierung verwendet decimal, einzelne Bestände weiterhin long mit checked-Arithmetik.

Owning-Game-Thread-Modell aus Sprint 7/8 bleibt verbindlich. Vorbereitete Kopien plus erwarteter Rootreferenz und ein Publish sind die Atomaritätsgrenze; keine neue allgemeine Mehrthread-Garantie.

## Panel und Integration

EquipmentPanelModel liefert unveränderlichen Adventurer-Snapshot mit Slots/Definitionen, freie Storage-Sicht, Sperrstatus, expliziten Zeitbezug sowie CanReevaluate/CanReturnEquipment/CanReturnPotions. Lesen verändert nichts. Keine Heilung beim Lesen. Rollen kommen weiterhin aus dem vorhandenen Klassenkatalog; keine duplizierten Rollenwerte.

## Grenzen

Keine Save-Integration; Idempotenz gilt im laufenden autoritativen Bestand. Keine automatische Ausrüstung von anderswo getöteten Mitgliedern; deren Rückgabe ist explizit möglich, automatische Rückgabe nur normaler Questresolve. Ein ungültiges globales Inventar blockiert Equipmentoperationen fail-closed, auch wenn das fehlerhafte Item außerhalb der Zielgruppe liegt. Große Lager können mehrere Sortier-/Vergleichsdurchläufe kosten; keine Geräteperformance behauptet. Runtime-Quellpaket, keine in Unity erzeugten Assets. Skill-/Itemwerte haben weiterhin keine neue Simulationseinwirkung.

# Sprint 5 – Gruppenverwaltung

Stand: 15.09.2026. Quellimplementierung erstellt; C#-/Unity-Ausführung nicht nachgewiesen.

## Verbindliche Regeln und Auflösung der Formulierungen

- Mehrere gleichzeitig bestehende Gruppen, je 1–6 registrierte Gildenmitglieder.
- Ein Abenteurer gehört höchstens einer Gruppe an; nicht zugeordnete Mitglieder bleiben verfügbar. „Nur genau einer“ bedeutet keine parallele Mitgliedschaft, keine Zwangszuordnung des gesamten Rosters.
- Höchstens ein optionaler Leiter. Die explizite Regel zum leeren Leader-Slot hat Vorrang vor der verkürzten Scope-Zeile „genau ein Gruppenleiter“.
- Entfernen, Ersetzen oder Transfer des Leiters leert dessen ursprünglichen Slot. Keine automatische Nachbesetzung oder Ernennung im Ziel.
- Transfer nur zwischen zwei bearbeitbaren Gruppen; Quelle bleibt mindestens ein Mitglied stark, Ziel höchstens sechs.
- Das letzte Mitglied wird gemäß freigegebener Ergänzungsplanung nicht einzeln entfernt/verschoben. Explizites Auflösen einer nicht aktiven Gruppe gibt sämtliche Mitglieder frei. Leere Gruppen können über die öffentliche API nicht entstehen und benötigen keine gesonderte Bereinigung.
- Kein Gesamtlimit von drei Gruppen. Die spätere Grenze von drei gleichzeitig laufenden Quests ist ausdrücklich NICHT implementiert.

## Architektur

Namespace `GuildGame`, reines C# ohne Unity-Abhängigkeit in den fünf neuen Produktionsdateien.

`PartyManager(AdventurerManager, AdventurerCatalog, IPartyEditPolicy = null)` nutzt die bereits existierenden Abenteurer und Klassenmetadaten. Keine neue Abenteurerverwaltung, keine Kopie des Gildenrosters. Die interne Registry speichert ausschließlich immutable Gruppen-Snapshots und IDs. Besitzabfragen werden aus dieser Registry abgeleitet, ohne zweiten veränderbaren Besitzindex.

Die API wird synchron auf dem besitzenden Spielthread verwendet. Keine Behauptung allgemeiner Thread-Sicherheit. Jede Mutation erstellt einen neuen Registerstand und veröffentlicht ihn mit einer Referenzzuweisung. Beim Transfer wird zuerst die Quellliste im temporären Zustand verkleinert, dann die Zielliste erweitert; erst danach werden beide gemeinsam sichtbar. Fehlerpfade veröffentlichen nichts.

`IPartyEditPolicy` ist die einzige neue Systemgrenze. Sie ist technisch nötig, um die freigegebene Sperrregel für später aktive Gruppen bereits jetzt prüfen zu können, ohne ein Quest-System einzuführen. Die Standardimplementierung bezeichnet alle Gruppen als bearbeitbar, weil noch kein Missionseigentümer existiert. Ein später injizierter Anbieter kann Gruppen sperren. Seine Abfragen müssen synchron und seiteneffektfrei sein. Exceptions führen zu `PolicyUnavailable` und sperren die Änderung; kein stilles Entsperren.

Kein eigenes dupliziertes Missionsstatusfeld, kein Start-/Stop-Quest-API. Das Panel zeigt den aktuellen Bearbeitbarkeitsstatus. Feste Teams/Autofill können später die stabilen Gruppen-IDs und validierten Befehle nutzen; Teamvorlagen, Boni oder Regeln werden nicht vorweggenommen.

## Öffentliche Operationen

- `TryCreateParty(partyId, memberIds)` – GUID-ID und 1–6 freie Mitglieder, initial kein Leiter.
- `TryDissolveParty(partyId)` – explizit auflösen; Mitglieder bleiben im AdventurerManager.
- `TryAddMember`, `TryRemoveMember` – Grenzen und Besitz prüfen.
- `TrySetMembers` – vollständiger atomarer Ersatz, keine Entnahme aus fremden Gruppen.
- `TryTransferMember(sourcePartyId, targetPartyId, memberId)` – gemeinsamer Registerwechsel.
- `TrySetLeader`, `TryClearLeader` – eigener Teilnehmer bzw. optionaler leerer Slot.
- `ValidateComposition` – strukturelle Gültigkeit, keine Questbereitschaft.
- `TryGetParty`, `GetPartiesSnapshot`, `GetAssignedPartyId`, `GetPanelModel` – Lesezugriff.

Gruppen- und Mitglieds-IDs werden über `Guid.TryParse` validiert und in `D`-Form normalisiert. Gruppen-IDs werden vom aufrufenden Ablauf geliefert; der Manager benötigt keinen Zufall. Die Gruppenliste wird stabil nach ID sortiert. Mitgliederreihenfolge ist reine Anzeige, keine Formation.

## Panelvertrag

Read-only Snapshots von Gruppen, Leiter, bestehendem Profil, Klasse/Rollen, Zuordnung und zulässigen Aktionen. Auswahl einer unbekannten Gruppe liefert `SelectionStatus`, ohne den Managerzustand zu verändern. Fehler der Befehle stehen im jeweiligen `PartyResult`; der Presenter kann diese anzeigen, ohne eine zweite fachliche Zustandsquelle einzuführen.

Kein MonoBehaviour-Presenter und kein neues Hallenziel: nur das freigegebene Panel-Datenmodell. Die vorhandenen sechs Sprint-4-Ziele bleiben unverändert.

## Bestehende Dateien

Keine geändert oder gelöscht. Alle 106 Dateien des gelieferten Sprint-4-Archivs wurden bytegleich übernommen, einschließlich seines historischen `PACKAGE_SHA256.json`. Das neue Gesamtmanifest heißt `PACKAGE_SPRINT5_SHA256.json`; das alte Manifest bleibt der historische Nachweis seines damaligen Umfangs.

Das Lieferpaket enthält die bereitgestellte Sprint-4-Basis plus Sprint 5. Es ersetzt kein vollständiges ursprüngliches Unity-Projekt, dessen Projektsettings/ältere nicht mitgelieferte Dateien hier nicht vorliegen.

## Wiederholbare Prüfungen

Vom Paketwurzelverzeichnis:

    python Tools/verify_sprint5.py --baseline /pfad/GuildGame_Sprint4_Implementation.zip
    python Tools/verify_sprint3.py

Erster Befehl: 63 Referenzmodellfälle, begrenzte Quellprüfungen und Dateibaseline. Zweiter Befehl: vorhandener Recruitment-Prüfer ohne optionalen Sprint-2-Basisvergleich. Beide kompilieren C# NICHT.

Unity: Neue Testdateien in die vorhandene EditMode-Testanordnung integrieren. `PartyManagerTests` lädt dieselben 63 JSON-Vertragsfälle über `Application.dataPath`; sieben weitere NUnit-Tests prüfen C#-spezifische Snapshots, Panelaktionen und Freigabe. Vorhandene Testquellen benutzen interne Katalogtypen ebenfalls; eine tatsächlich funktionsfähige Assembly-/Test-Runner-Konfiguration muss in Unity verifiziert werden.

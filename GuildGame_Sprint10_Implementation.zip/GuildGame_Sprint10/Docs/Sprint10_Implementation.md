# Sprint 10 – isolierter Combat Core

Stand 2026-09-25. Grundlage ist die ausdrückliche Freigabe R10-01 bis R10-18 samt endgültigen Konfliktauflösungen. Der Core ist Quellimplementierung; C# wurde in dieser Umgebung nicht ausgeführt.

## Architektur und Grenze

Namespace GuildGame.Combat. CombatSession besitzt genau einen veröffentlichten CombatState. Ein Tick arbeitet ausschließlich auf Kopien: Combatants, Ressourcen, Cooldowns, Status, Zufallszähler und Ergebnis. Erst nach vollständiger Vorbereitung ersetzt eine Zuweisung den aktuellen Zustand. Fehler lassen den vorherigen Zustand einschließlich RNG-Zähler erhalten. Die Session ist für einen besitzenden Thread ausgelegt, nicht für parallele Befehle. Reentranz wird abgewiesen.

CombatInput, CombatantInput, CombatProfile, Fähigkeiten, veröffentlichte Zustände, Ereignisse und Ergebnisse sind unveränderlich; Sammlungen sind read-only Kopien. WorkingCombatant ist ausschließlich internes Tick-Staging. Keine GameObjects, Unity-API, Frames, Systemzeit oder UnityEngine.Random im Core.

AdventurerCombatAdapter liest vorhandene Party-/Adventurer-/Klassen-/Equipmentdaten und Questbindungen. StartHP ist MaxHP, StartMana Klassenmaximum. Tote, Verletzte und Questgebundene werden abgewiesen. Der tatsächliche Questbestand des Rosters wird zusätzlich zur übergebenen Registry geprüft. Keine Reservierung, Veröffentlichung oder GuildRuntimeStore-Mutation. Der Adapter ist ausdrücklich kein produktiver Dungeonstart. Fremde oder veraltete Party-Snapshots werden nicht in eine laufende Dungeonreservation umgewandelt.

## Umsetzung der Freigaben

| Regel | Umsetzung |
|---|---|
| R10-01 | Isolierte Session, Ergebnis nur Folgenvertrag, keine Gilden-/Quest-/Reward-/Itembuchung |
| R10-02 | Initial Tick 0, erster Tick 1 bei 250 ms; feste kanonische ID-Liste, Linksrotation (T−1) modulo ursprünglicher Anzahl; Ausgeschiedene bleiben in Liste; ReadyAt=T+C; Aktionssperre 4 Ticks |
| R10-03 | Krieger HP60/Mana0/ATK8/DEF3/Krit1000bp; Schurke 40/0/10/1/2000; Magier 36/24/9/1/1000; Priester 42/24/5/1/1000. Alive-StartHP 1..MaxHP. Level/Skills neutral |
| R10-04 | Sechs bekannte Equipmentdefinitionen neutral; Slot-/Klassenidentität geprüft; keine Eignungswerte als Combatstats |
| R10-05 | Alle freigegebenen Ability-IDs/Kosten/CDs; Mage Staff Strike genereller Fallback; kein statusbedingter Zielwechsel; Priester Stabilize > Heal > Strike |
| R10-06 | max(1,Raw−Defense), anschließend bei Krit ×2; Heal12 bis MaxHP bei HP≤50%; kein Dodge, keine Streuung |
| R10-07 | Magier/Priester Max-/Startmana24, Alive +1/Tick, auch bei Stun; kein Mana für physische Klassen |
| R10-08 | Alive-Gegner, Front vor hinten, Tank innerhalb Abenteuerfront, bestehendes höchstprioritäres Ziel erhalten, sonst ID ordinal |
| R10-09 | Nur Standard, kein Leaderbonus |
| R10-10 | Exakter freigegebener SHA-256-Feldvertrag, Versionen, UInt64-Seed x16, uint32 Big-Endian, globaler Drawzähler und drei Purpose-Werte |
| R10-11 | Poison1/Bleed2/Burn2 je 4 Ticks über 16 Ticks, letzter Puls inklusive; Stun4; Reihenfolge Poison/Bleed/Burn; erneuern ohne Stack/Quellenwechsel/Verlust des nächsten Pulses |
| R10-12 | 0HP → Incapacitated, Frist T+32; Priester sicher stabilisiert, 6 Mana/CD16, 1HP, kein Wiedereintritt; Gegner bei 0HP direkt Dead |
| R10-13 | Nach Aktionsphase Zusammenbruch zuerst: kein Alive → je Incapacitated genau 60%-Wurf; sonst fällige 25%-Würfe. Nie beide für denselben Vorfall. Wipe nur alle ursprünglichen Abenteurer Dead |
| R10-14 | Defeat bei keinem Alive, auch beidseitigem Ausfall; Stun kein Defeat. Vorläufiger Victory darf Aftermath starten. Dort nur Priester Mana/Stabilisierung, kein Magiermana/Angriff/Heal |
| R10-15 | Überlebte Kampfunfähigkeit RecoveryDuration120s als Resultdaten. Bei endgültigem fachlichem Ende alle Statusinstanzen gelöscht, History erhalten. Keine Buchung |
| R10-16 | Kein Potion-Befehl/Verbrauch, leere ConsumedPotions |
| R10-17 | Vier Goblinprofile: HP24/18/48/96, Angriff6/5/9/11, Defense1/0/2/3, Krit1000bp, Basis-CD8/8/12/12 Ticks. Ranged PoisonShot24 vor Basic; Brute StunningBlow24 vor Basic. Boss nur Basic |
| R10-18 | 1–6 je Fraktion. Tick480 vollständig, danach ohne vorläufiges/finales Ende TechnicalAbort/SimulationLimitReached; terminal, kein Resume und kein fachliches Resultat. Begonnene Aftermath läuft weiter |

## Fähigkeiten

| Definition | Priorisierte IDs | Cooldown-Ticks | Manakosten | Wirkung |
|---|---|---|---|---|
| Krieger | combat.warrior.shield_bash; combat.warrior.strike | 24;8 | 0;0 | Angriff, Bash plus Stun |
| Schurke | combat.rogue.bleeding_cut; combat.rogue.strike | 24;8 | 0;0 | Angriff, Cut plus Bleed |
| Magier | combat.mage.burning_bolt; combat.mage.bolt; combat.mage.staff_strike | 24;8;8 | 6;4;0 | Angriff+Burn; Angriff; Rohschaden3 |
| Priester | combat.priest.stabilize; combat.priest.heal; combat.priest.strike | 16;8;8 | 6;6;0 | Stabilized1HP; Heal12; Angriff |
| Goblin-Fernkämpfer | combat.goblin.poison_shot; combat.enemy.basic_attack | 24;8 | 0;0 | Angriff+Poison; Angriff |
| Goblin-Brutalo | combat.goblin.stunning_blow; combat.enemy.basic_attack | 24;12 | 0;0 | Angriff+Stun; Angriff |
| Goblin-Nahkämpfer/Boss | combat.enemy.basic_attack | 8 / 12 | 0 | Angriff |

Bereitheit der Spezialaktion wird auf dem bereits ausgewählten Ziel geprüft; vorhandener Status führt zum Fallback, nicht zum Zielwechsel. Ein Angriff erzeugt genau einen critical-Draw. Heal/Stabilize erzeugen keinen Draw. Kein Mana-/Cooldownverbrauch ohne Aktion.

## RNG und Bytevertrag

RulesVersion combat.rules.v1; RngVersion combat.rng.sha256.v1; InputSchema combat.input.v1. Jedes Feld wird als 4-Byte unsigned Big-Endian UTF-8-Bytelänge plus UTF-8-Bytes kodiert. Keine Separatoren. Ganzzahlen invariant dezimal, Seed UInt64 als 16-stelliges lowercase Hex. Faction wird stabil als Adventurer bzw. Enemy kodiert; das ist die konkrete technische Darstellung dieses Feldes. Gegner haben ohne zusätzliche fachliche Rollenvergabe Rollenbitmaske 0; Klassen verwenden vorhandene kanonische Masken 3/2/10/12.

Inputfelder: InputSchema, RulesVersion, Anzahl; danach Teilnehmer ordinal nach CombatantId mit ID, Faction, SourceAdventurerId/leer, DefinitionId, Rollenmaske, StartHP, StartMana, Weapon Definition/Instanz, UpperBody Definition/Instanz, Legs Definition/Instanz; zuletzt Seed. Fingerprint lowercase SHA-256 Hex.

Drawfelder: RngVersion, RulesVersion, Seed, InputFingerprint, TickIndex, ActorId, globaler ActionSequence-Zähler, Purpose. Purpose nur critical/death.normal/death.collapse. Actor ist Angreifer bzw. betroffener Abenteurer. Zähler startet0 und steigt genau nach einem angeforderten Draw. UInt32 aus ersten4 Hashbytes Big-Endian; Vergleich mit UInt64: draw*10000 < basisPoints*4294967296. Normal-/Collapse-Todesprüfungen erfolgen in kanonischer Teilnehmerreihenfolge.

Vier gemeinsame Golden-Vektoren für Seeds 0,1,7,UInt64.MaxValue wurden aus dem separaten Pythonmodell erzeugt und in den vorbereiteten C#-Tests festgehalten. C#-Übereinstimmung noch nicht ausgeführt. Die genehmigte Fingerprintstruktur enthält Equipment-IDs: Equipment verändert keine Stats, kann aber durch eine veränderte Startkonfiguration den RNG-Fingerprint ändern. Daher wird keine identische Zufallsfolge bei geändertem Equipment behauptet.

## Ablauf / Veröffentlichung

Statuspulse kanonisch je Ziel, dann Poison/Bleed/Burn. Kampfunfähigkeit beendet alle weiteren Pulse des Ziels. Ablaufentfernung erfolgt nach letztem fälligem Puls. Mana, rotierte Aktionen, Zusammenbruchsvorrang, normale Todesfristen, Endprüfung. Danach einziger Publish. Bei neuem Aftermath Statusbereinigung; dort nur Alive-Priester aktiv. Bei Endresultat erneute vollständige Statusbereinigung.

TechnicalAbort erhält den zuletzt vollständig verarbeiteten Tick480 einschließlich bereits real entstandener Folgen. Es erzeugt keine zusätzlichen Todes-/Verletzungsfolgen, kein CombatResult und keine Gildenmutation. Weitere Befehle liefern Terminal.

CombatTimeController nimmt ganzzahlige verstrichene Millisekunden, multipliziert mit 0/1/2/4 und hält Restzeit zurück. Pause verwirft zugeführte Pausenzeit, lässt vorherige Restzeit unverändert. Fehler eines Ticks erhält dessen ausstehende Zeit, aber keinen partiellen Combatzustand. Atomaritätsgrenze ist ein Tick; bei einem mehrtickigen Advance bleiben bereits erfolgreich veröffentlichte Ticks gültig.

## Ergebnis und Darstellung

CombatResult enthält InputFingerprint, deterministische ResultId, Seed, RulesVersion, Outcome, IsWipe, Gefechts-/Nachsorge-/Gesamtdauer und unveränderliche Teilnehmerfolgen mit HP/Mana, Leben, Stabilisierung, Todeszeitpunkt und relativer Erholungsdauer. EncounteredStatuses ist Verlauf, Statuses ist beim fachlichen Endzustand leer. ConsumedPotions leer. Keine XP/Gold/Loot-Felder.

ResultId wird technisch aus einer separaten Ergebnisdomäne und InputFingerprint abgeleitet; es ist kein Gilden-Commit-Ledger. CombatPanelModel zeigt unveränderlichen State, Speed und CanAdvance. Keine Hallen-/Sceneintegration.

## Technische Zusammenfassung gegenüber der Planung

Neun Produktionsdateien statt der vorläufigen siebzehn: Typen/Resolver sind zu kleinen zusammenhängenden Dateien zusammengefasst. Profile und Regeln sind für v1 zentral und unveränderlich; keine unversionierte freie Balanceänderung während einer Session. Der Core verwendet CombatSession statt eines zusätzlichen CombatManager. Kein produktiver Session-Registry-/SessionId-Vertrag erforderlich, da kein externer Commit stattfindet; Resultatidentität ist deterministisch über InputFingerprint.

Ein eigenständiges .NET-8-Konsolentestprojekt verlinkt den tatsächlichen Core plus vorhandenes AdventurerRole. Keine Unity-/NuGet-Testframework-Abhängigkeit dafür. Derselbe C#-Fallkatalog wird zusätzlich durch NUnit in Unity aufgerufen. Adapterfälle sind separat für die vorhandene Unity-Testumgebung vorbereitet. Diese Testprojektwahl ändert nicht die Unity-Zielarchitektur.

## Grenzen / Risiken

Keine C#-Kompilierung in dieser Umgebung. Keine ausgeführten NUnit- oder Unity-Tests. Kein IL2CPP-/iPhone-Profiling. Die Snapshotkopien, Ereignislisten und SHA-Puffer erzeugen Allokationen; 60-FPS- oder GC-Freiheit wird nicht behauptet. Die kleine Teilnehmerzahl und maximal480 Kampfticks begrenzen Arbeit, ersetzen aber kein Profiling. Atomare Zuweisung gilt im besitzenden Thread, nicht als allgemeine Mehrthreadtransaktion. Der Adapter reserviert nichts und darf nicht als produktive Dungeonintegration verwendet werden. Keine Save-/Restart-Idempotenz. Kein Sprint11.
